package com.bst;

public class BinarySearchTree<T> {
	private TreeNode<T> root;
	
	public void insert(int data) {
		insert(root, data);
	}
	
	public void search(int key) {
		search(root, key);
	}

	
	public TreeNode<T> insert(TreeNode<T> root ,int data){
		if(root==null) {
			return new TreeNode<>(data);
		}
		
		if(data <root.data) {
			root.left=insert(root.left, data);
		}else {
			root.left=insert(root.right, data);
		}
		
		return root;
	}
	
	
	public TreeNode<T> search(TreeNode<T> root,int key){
		if(root == null || root.data ==key) {
			return root;
		}
		
		if(key<root.data) {
			return search(root.left, key);
		}else {
			return search(root.right, key);
		}
	}
}
