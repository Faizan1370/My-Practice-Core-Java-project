package com.bst;

public class TreeNode<T> {
	
	public int data;
	public TreeNode<T> left;
	public TreeNode<T> right;
	public TreeNode<T> parent;
	
	
	public TreeNode(int data) {
		this.data=data;
	}
	

}
