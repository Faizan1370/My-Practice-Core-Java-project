package com.java8.concept.reduce;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import com.java8.concept.streamApi.sortList.Employee;

public class MapReduceEx {
	static List<Employee> list =new ArrayList<>();
	 static{
		 Employee emp= new Employee(100, "Faizan", "QA",500000);
		 Employee emp1= new Employee(700, "dfg", "QA",600000);
		 Employee emp2= new Employee(400, "Minhaz", "C++ developer",400000);
		 Employee emp3= new Employee(300, "Kamlesh", "Senior Software Engineer",800000);
		 list.add(emp);
		 list.add(emp1);
		 list.add(emp2);
		 list.add(emp3);
		
	}
	
	public static void main(String[] args) {
		List<Integer> numbers = Arrays.asList(3,5,7,6,9);
		List<String> words = Arrays.asList("Sahil","ameer","Khan");
		
		//old way to find sum of numbers in the array
		int sum=0;
		for(int i:numbers) {
			sum+=i;
		}
		System.out.println(sum);
		
		int sum2 = numbers.stream().mapToInt(i->i).sum();
		System.out.println(sum2);
		
		Integer sum3 = numbers.stream().reduce(0,(a,b)->a+b);
		System.out.println(sum3);
		
		Optional<Integer> sum4 = numbers.stream().reduce(Integer::sum);// we can find max and min etc.
		System.out.println(sum4.get());
		 Integer maxValue = numbers.stream().reduce(0,(a,b) ->a>b?a:b);
		 System.out.println(maxValue);
		 
		 String longestString = words.stream().reduce((word1,word2)->word1.length()>word2.length() ?word1:word2).get();
		 System.out.println(longestString);
		 
		 double avarageSal = list.stream().filter(t->t.getDesignation().equalsIgnoreCase("QA")).map(emp->emp.getSalary()).mapToDouble(i->i).average().getAsDouble();// we can sum same way using sum() instead of average
		 System.out.println(avarageSal);
	}

}
