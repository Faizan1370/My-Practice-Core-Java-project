package com.java8.concept.questionsPract;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.BinaryOperator;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.java8.concept.streamApi.sortList.Employee;

public class QuestionsPract {
  
	
	static ArrayList<Employee> list = new ArrayList<>();
	
	 static{
		 Employee emp= new Employee(100, "Faizan", "Software Engineer",500000);
		 Employee emp1= new Employee(700, "Arun", "QA tester",600000);
		 Employee emp2= new Employee(400, "Minhaz", "C++ developer",400000);
		 Employee emp3= new Employee(300, "Kamlesh", "Senior Software Engineer",800000);
		 list.add(emp);
		 list.add(emp1);
		 list.add(emp2);
		 list.add(emp3);
		
	}
	
	public static void main(String[] args) {
	//findEvenNumbers();	
    //startingWithAnyNumber();
    //duplicateElement();
    //findFirstElement();
    //totalElements();
   //maxElement();
		//firstNonRepeatingChar();
		//firstReapeatingChar();
		//sortElement();
		//sortElementReverse();
		//valueFoundIfLeastOneTwice();
		//currentDataAndTime();
		//mergerTwoStream();
		//cubeElemenetGreaterThanValue();
		//sortArrayConvertStream();
		//convertUpperCase();
		//countWordListString();
		//findOnlyDuplicateElementsWithCount();
		//countEachCharacterInString();
		heigestPainEmployee();
		
	}
	
	public static void findEvenNumbers() {
		List<Integer> list =Arrays.asList(4,7,3,7,10,19);
		
		list.stream().filter(value->value%2==0).forEach(System.out::println);
		
		// we have array not list
		int[] arr = {4,6,2,8,9,3};
		Arrays.stream(arr).boxed().filter(value->value%2==0).forEach(System.out::println);
		
	}
	
   public static void startingWithAnyNumber() {
	   List<Integer> list =Arrays.asList(4,7,3,7,10,19);
	   list.stream().map(s->s+"").filter(s->s.startsWith("1")).forEach(System.out::println);
	   
	   int[] arr = {4,6,2,8,9,13};
	   Arrays.stream(arr).boxed().map(s->s+"").filter(s->s.startsWith("1")).forEach(System.out::println);
   }
   
   public static void duplicateElement() {
	   List<Integer> list =Arrays.asList(4,7,3,7,10,19);
	   list.stream().distinct().forEach(System.out::println); // unique
	   
	   //2 app
	   HashSet<Integer> set = new HashSet<>();
	   list.stream().filter(num->!set.add(num)).forEach(System.out::println);// duplicate data onlu
   }
   
   public static void findFirstElement() {
	   List<Integer> list =Arrays.asList(4,7,3,7,10,19);
	   list.stream().findFirst().ifPresent(t->System.out.println(t));
   }
   public static void totalElements() {
	   List<Integer> list =Arrays.asList(4,7,3,7,10,19);
	  System.out.println( list.stream().count());
   }
   
   public static void maxElement() {
	   List<Integer> list =Arrays.asList(4,7,3,7,10,19);
	   System.out.println(list.stream().max(Integer::compare).get());
	   
	   int[] arr = {4,6,2,8,9,13};
	  System.out.println(Arrays.stream(arr).boxed().max(Comparator.naturalOrder()).get());
	   
   }
   
   public static void firstNonRepeatingChar() {
	   String str = "Java articles";
	   Character character = str.chars()
	   .mapToObj(s->Character.toLowerCase(Character.valueOf((char)s)))
	   .collect(Collectors.groupingBy(Function.identity(),LinkedHashMap::new,Collectors.counting()))
	   .entrySet()
	   .stream()
	   .filter(entry->entry.getValue()==1L)
	   .map(entry->entry.getKey())
	   .findFirst()
	   .get();
	   
	   System.out.println(character);
	   
	   Character orElse = str.chars().mapToObj(c->(char)c)
	   .filter(ch->str.indexOf(ch)==str.lastIndexOf(ch))
	   .findFirst().orElse(null);
	   System.out.println(orElse);
   }
   
   public static void firstReapeatingChar() {
	   String str= "Hello Faizan";
	   Long long1 = str.chars()
	   .mapToObj(s->Character.toLowerCase(Character.valueOf((char)s)))
	   .collect(Collectors.groupingBy(Function.identity(),LinkedHashMap::new,Collectors.counting()))
	   .entrySet()
	   .stream()
	   .filter(entry->entry.getValue()>1L)
	   .map(entry->entry.getValue())
	   .findFirst()
	   .get();
   }
   
   public static void sortElement() {
	   List<Integer> list =Arrays.asList(4,7,2,8,5,10,20,40);
	   List<Integer> collect = list.stream().sorted().collect(Collectors.toList());
	   System.out.println(collect.toString());
	   
   }
   public static void sortElementReverse() {
	   List<Integer> list =Arrays.asList(4,7,2,8,5,10,20,40);
	   List<Integer> collect = list.stream().sorted(Collections.reverseOrder()).collect(Collectors.toList());
	   System.out.println(collect.toString());
   }
   public static void valueFoundIfLeastOneTwice() {
	   List<Integer> list =Arrays.asList(4,7,2,10,8,5,10,20,40);
	   Set<Integer> set = new HashSet<>(list);
	   if(list.size()==set.size()) {
		   System.out.println(false);
	   }else {
		   System.out.println(true);
	   }
   }
   
   public static void currentDataAndTime() {
	   System.out.println("date :"+java.time.LocalDate.now());
	   System.out.println("time :"+java.time.LocalTime.now());
	   System.out.println("Date and time :"+java.time.LocalDateTime.now());
   }
   public static void mergerTwoStream() {
	   List<Integer> list1 =Arrays.asList(4,7,2,10,8,5,10,20,40);
	   List<Integer> list2 =Arrays.asList(23,56,45,90);
	   Stream<Integer> concat = Stream.concat(list1.stream(), list2.stream());
	   concat.forEach(st->System.out.print(st +" "));
	   
   }
   
   public static void cubeElemenetGreaterThanValue() {
	   List<Integer> list =Arrays.asList(1,7,8,2);
	   list.stream().map(val->val*val*val).filter(val->val>50).forEach(t->System.out.println(t));
   }
   
   public static void sortArrayConvertStream() {
	   int[] arr = {4,6,3,7,9};
	  // Stream<Integer> sorted = Arrays.stream(arr).boxed().sorted();
	   Arrays.parallelSort(arr);
	   Arrays.stream(arr).forEach(n->System.out.print(n +" "));
	
}
   public static void convertUpperCase() {
	   List<String> nameList = Arrays.asList("faizan","farhan");
	   nameList.stream().map(t->t.toUpperCase()).forEach(t->System.out.println(t));
	   
   }
   
   public static void countWordListString() {
	   
	   List<String> list =Arrays.asList("AA","BB","CC","AA");
	   Map<String, Long> collect = list.stream().collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
	   collect.forEach((key,value)->System.out.println(key +" "+ value));
   }
   
	/*
	 * public static void coundWordsInString() { String str="Hello Faizan"; char[]
	 * charArray = str.toCharArray(); charArray. Map<char[], Long> collect =
	 * Arrays.asList(charArray).stream().collect(Collectors.groupingBy(Function.
	 * identity(),Collectors.counting()));
	 * 
	 * }
	 */
   
   public static void findOnlyDuplicateElementsWithCount() {
	   List<String> list =Arrays.asList("AA","BB","CC","AA");
	   Map<String, Long> collect = list.stream().
	   filter(t->Collections.frequency(list, t)>1)
	   .collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
	   collect.entrySet().stream().forEach(entry->System.out.println(entry.getKey() + " "+entry.getValue()));
   }
   
   public static void countEachCharacterInString() {
	   String str="Hello Sir";
	   Arrays.stream(str.split(""))
	   .map(String::toLowerCase) // or use s->s.toLowerCase
	   .collect(Collectors.groupingBy(Function.identity(),Collectors.counting())).entrySet().stream().forEach(enry->System.out.println(enry.getKey() +" "+enry.getValue()));
   }
   
   // Program to find heigest paid employee from each dept
   public static void heigestPainEmployee() {
	   //Stream<Employee> sorted = list.stream().sorted(Comparator.comparing(Employee::getSalary));
	   Comparator<Employee> comparing = Comparator.comparing(Employee::getSalary); /// second way to sort
	   Map<String, Optional<Employee>> collect = list.stream().collect(Collectors.groupingBy(Employee::getDesignation,Collectors.reducing(BinaryOperator.maxBy(comparing))));
	   System.out.println(collect);
	   //approah 2 to find hiegest sal
	   //list.stream().collect(groupingBy(Employee::getDesignation,
		//	   collectingAndThen(maxBy(Comparator.comparingDouble(Employee::getSalary)),Optional::get)));
   }
   
   
}
