package com.java8.concept.streamApi.sortList;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class SortExStream {
	static List<Employee> list =new ArrayList<>();
	 static{
		 Employee emp= new Employee(100, "Faizan", "Software Engineer",500000);
		 Employee emp1= new Employee(700, "Arun", "QA tester",600000);
		 Employee emp2= new Employee(400, "Minhaz", "C++ developer",400000);
		 Employee emp3= new Employee(300, "Kamlesh", "Senior Software Engineer",800000);
		 list.add(emp);
		 list.add(emp1);
		 list.add(emp2);
		 list.add(emp3);
		
	}
	 
	 public static void main(String[] args) {
		 
		// Collections.sort(list,(o1,o2)->(int)(o1.getSalary()-o2.getSalary()));
		// System.out.println(list);
		list.stream().sorted((o1,o2)->(int)(o1.getSalary()-o2.getSalary())).forEach(System.out::println);
		list.stream().sorted(Comparator.comparing(emp ->emp.getSalary())).forEach(System.out::println);
		 Employee employee = list.stream().sorted(Comparator.comparing(Employee::getSalary).reversed()).collect(Collectors.toList()).get(1);
	System.out.println(employee.getSalary());
	
	list.stream().map(e->e.getName().toUpperCase()).forEach(e->System.out.println(e));

	
	 }

}
