package com.java8.concept.streamApi.sortList.pract;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.java8.concept.streamApi.sortList.Employee;

public class SortList {
	
	public static List<Employee> getEmployees(){
		return Stream.of(
				new Employee(4, "Zayan", "Developer", 100),
				new Employee(4, "faizan", "Developer", 700),
				new Employee(4, "Farhan", "Developer",500)
				).collect(Collectors.toList());
		
	}

	public static void main(String[] args) {
		List<Integer> lis = Arrays.asList(3,6,8,2);
		List<Employee> employees = getEmployees();
		
		Collections.sort(lis);
		//System.out.println(lis);
		//Collections.sort(employees,(o1,  o2)-> o1.getSalary()-o2.getSalary());
		employees.stream().sorted((o1,  o2)-> o1.getSalary()-o2.getSalary());
		System.out.println(employees);
		employees.stream().sorted(Comparator.comparing(emp->emp.getSalary())).forEach(emp->System.err.println(emp));
		employees.stream().sorted(Comparator.comparing(Employee::getSalary)).forEach(emp->System.out.println(emp));
		
		employees.stream().map(e->e.getName().toUpperCase()).forEach(e->System.out.println(e));
		
		

	}

}

/*
 * class MyComparator implements Comparator<Employee>{
 * 
 * @Override public int compare(Employee o1, Employee o2) {
 * 
 * return o1.getSalary()-o2.getSalary(); }
 * 
 * }
 */
