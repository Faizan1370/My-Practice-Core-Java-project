package com.java8.concept.streamApi;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.java8.concept.streamApi.sortList.Employee;


public class StreamEx {
	static List<Employee> list =new ArrayList<>();
	 static{
		 Employee emp= new Employee(100, "Faizan", "Software Engineer",500000);
		 Employee emp1= new Employee(700, "Arun", "QA tester",600000);
		 Employee emp2= new Employee(400, "Minhaz", "C++ developer",400000);
		 Employee emp3= new Employee(300, "Kamlesh", "Senior Software Engineer",800000);
		 list.add(emp);
		 list.add(emp1);
		 list.add(emp2);
		 list.add(emp3);
		
	}
	 
	 public static void main(String[] args) {
		 List<Integer> asList = Arrays.asList(1,4,6,2,1,6,4);
		 asList.stream().distinct().toList().stream().forEach(o->System.out.println(o)) ;
		 
		 //forEach
		 list.stream().forEach(t ->System.out.println(t));
		 // filter
		 list.stream().filter(t->t.getName().startsWith("M")).forEach(t->System.out.println("Starts with M :"+t));
		 list.stream().filter(emp->emp.getSalary()>500000).forEach(t->System.out.println("tax payer employess :"+t));
		 //list.stream().filter(emp->emp.getSalary()>500000).collect(Collectors.toList());
		 
		Map<Integer,String> map = new HashMap<>();
		map.put(1, "a");
		 map.put(5, "g");
		 map.put(7, "gf");
		 map.put(8, "h");
		 
		// map.forEach((key,value)->System.out.println(key +" "+value));
		// map.entrySet().stream().forEach(obj->System.out.println(obj));
		 map.entrySet().stream().filter(k->k.getKey()%2==0).forEach(obj->System.out.println(obj));
		 
		
		
	}

}
