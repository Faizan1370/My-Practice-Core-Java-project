package com.java8.concept.streamApi.SortHashMap;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import com.java8.concept.streamApi.sortList.Employee;

public class SortHashMapEx {
	
	public static void main(String[] args) {
		oldApproach();
	Map<Employee,Integer> employeeMap = new TreeMap<>((o1,o2)->(int)(o1.getSalary()-o2.getSalary()));
	//Map<Employee,Integer> employeeMap = new TreeMap<>();
	employeeMap.put(new Employee(12, "Arun", "IT desk", 7000000), 60);
	employeeMap.put(new Employee(65, "Akhil", "Support", 800000), 67);
	employeeMap.put(new Employee(77, "Sahil", "Developer", 9000000), 88);
	employeeMap.put(new Employee(44, "Nasir", "Support", 6000000), 90);
	
	//System.out.println(employeeMap);
	
	//employeeMap.entrySet().stream().sorted(Map.Entry.comparingByValue()).forEach(System.out::println);// not correct because here is object in the key.
	employeeMap.entrySet().stream().sorted(Map.Entry.comparingByValue()).forEach(System.out::println);
	employeeMap.entrySet().stream().sorted(Map.Entry.comparingByKey(Comparator.comparing(Employee::getName))).forEach(t->System.out.println(t));
	
	employeeMap.entrySet().stream().sorted(Map.Entry.comparingByKey(Comparator.comparing(emp -> emp.getName()))).forEach(System.out::println);
	
	}
	public static void oldApproach() {
		Map<String,Integer> map = new HashMap<>();
		map.put("Azlan", 12);
		map.put("Arish", 56);
		map.put("Aqsa",45);
		map.put("Azqa",98);
		map.put("Aman",89);
		
		List<Entry<String, Integer>> list = new ArrayList<>(map.entrySet());
		Collections.sort(list,(o1,o2)->o1.getKey().compareTo(o2.getKey()));// using lamda
		//Collections.sort(list,new Comparator<Entry<String, Integer>>() {

			//@Override
			//public int compare(Entry<String, Integer> o1, Entry<String, Integer> o2) {
				//return o1.getKey().compareTo(o2.getKey());
			//}
		//});
		
		list.stream().forEach(t->System.out.println(t)); // using lamda
		for(Entry<String, Integer> entry:list) {
			System.out.println(entry.getKey() + " "+entry.getValue());
		}
	}
		
	}


