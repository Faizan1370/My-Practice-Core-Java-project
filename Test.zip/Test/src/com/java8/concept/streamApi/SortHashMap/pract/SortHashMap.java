package com.java8.concept.streamApi.SortHashMap.pract;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.Map.Entry;

import com.java8.concept.streamApi.sortList.Employee;

public class SortHashMap {
	
	public static void main(String[] args) {
		Map<Integer,String> map= new HashMap<>();
		map.put(4, "Faizan");
		map.put(8, "Faizan");
		map.put(3, "Faizan");
		map.put(9, "Faizan");
		
		//List<Entry<Integer,String>> listMap = new ArrayList<>(map.entrySet());
		
		//Collections.sort(listMap,(o1, o2)->  o1.getKey()-o2.getKey());
		
		

			
	
		
		//listMap.stream().forEach(t->System.out.println(t));
		
		//map.entrySet().stream().sorted(Map.Entry.comparingByKey()).forEach(entry->System.out.println(entry.getKey()));
		Map<Employee,Integer> employeeMap = new HashMap<Employee,Integer>();
		//Map<Employee,Integer> employeeMap = new TreeMap<>();
		employeeMap.put(new Employee(12, "Arun", "IT desk", 7000000), 60);
		employeeMap.put(new Employee(65, "Akhil", "Support", 800000), 67);
		employeeMap.put(new Employee(77, "Sahil", "Developer", 9000000), 88);
		employeeMap.put(new Employee(44, "Nasir", "Support", 6000000), 90);
		
		employeeMap.entrySet().stream().sorted(Map.Entry.comparingByKey(Comparator.comparing(emp->emp.getName()))).forEach(t->System.out.println(t));
		employeeMap.entrySet().stream().sorted(Map.Entry.comparingByKey(Comparator.comparing(Employee::getName))).forEach(System.out::println);
	}
	
	public static void sortMap(Map<Employee,Integer> map) {
		List<Entry<Employee, Integer>> list = new ArrayList<>(map.entrySet());
		Collections.sort(list, new Comparator<Entry<Employee, Integer>>() {

			@Override
			public int compare(Entry<Employee, Integer> o1, Entry<Employee, Integer> o2) {
				// TODO Auto-generated method stub
				return o1.getKey().getName().compareTo(o2.getKey().getName());
			}
		});
	}

}
