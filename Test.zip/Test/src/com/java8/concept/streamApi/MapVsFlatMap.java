package com.java8.concept.streamApi;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;


public class MapVsFlatMap {
	
 public static List<Customer> getCustomer(){
	 return Stream.of(
			 new Customer(54, "abc@abc.com", "abc", Arrays.asList(916123456,896745230)),
			 new Customer(87, "harsih@abc.com", "harish", Arrays.asList(916123690,89645230)),
			 new Customer(77, "jameel@abc.com", "jameel", Arrays.asList(875123456,763745654))).collect(Collectors.toList());
}
 public static void main(String[] args) {
	List<Customer> customers = getCustomer();
	List<String> collect = customers.stream().map(c->c.getEmail()).collect(Collectors.toList());
	//List<String> numbers = customers.stream().map(c->c.getNumbers()).collect(Collectors.toList());//compile time error here one to many means many number use flatmap for this
	System.out.println(collect);
	List<Integer> numbers = customers.stream().flatMap(c->c.getNumbers().stream()).collect(Collectors.toList());
	System.out.println(numbers);
	customers.stream().flatMap(c->c.getNumbers().stream()).forEach(System.out::println);
}
 
}
