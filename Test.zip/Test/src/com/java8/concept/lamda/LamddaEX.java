package com.java8.concept.lamda;

public class LamddaEX {
	public static void main(String[] args) {
		//Calculator cal = ()-> {
			//System.out.println("Switch On");
		//};
		//Calculator cal = ()->System.out.println("Switch On"); //2nd way for single print statement
		//cal.switchOn();
		
		Calculator cal=(int input)->System.out.println(input);//we can remove int like (input)
		cal.sum(10);
		
		Calculator cal1 = (input)->System.out.println(input);
		cal1.sum(60);
		
	
		Thread th =	new Thread (()-> {
				System.out.println("");
			});
		th.start();
		
	}

}
