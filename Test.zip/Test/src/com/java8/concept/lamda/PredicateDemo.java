package com.java8.concept.lamda;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

public class PredicateDemo{

	/*
	 * @Override public boolean test(Integer t) { if(t%2==0) { return true; }else {
	 * return false; } }
	 */
	public static void main(String[] args) {
		//PredicateDemo demo = new PredicateDemo();
	  // System.out.println(demo.test(7));	
	  // Predicate<Integer> demo1= (t)->{
		  // if(t%2==0) {
				//return true;
			//}else {
			//return false;
			//}  
	  // };
		Predicate<Integer> demo1= t-> t%2==0;
	   System.out.println(demo1.test(8));
	   List<Integer> asList = Arrays.asList(1,5,7,8);
	   asList.stream().filter(demo1).forEach(t->System.out.println(t));
	   asList.stream().filter( t-> t%2==0).forEach(t->System.out.println(t));
	}

}
