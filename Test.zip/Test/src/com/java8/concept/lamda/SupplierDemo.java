package com.java8.concept.lamda;

import java.util.Arrays;
import java.util.List;
import java.util.function.Supplier;

public class SupplierDemo implements Supplier<String>{

	@Override
	public String get() {
		return "hello Buddy";
	}
	
	public static void main(String[] args) {
		//SupplierDemo dm= new SupplierDemo();
		//System.out.println(dm.get());
	Supplier<String> supp=	() ->"Hellob";
	//{
			//return "Hello Buddy";
		//};
		//System.out.println(supp.get());
		 List<String> list = Arrays.asList("hh");
		System.out.println(list.stream().findAny().orElseGet(supp)); 
	}
	
	

}
