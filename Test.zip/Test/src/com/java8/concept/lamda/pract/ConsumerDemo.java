package com.java8.concept.lamda.pract;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

public class ConsumerDemo {
	
	public static void main(String[] args) {
		Consumer<Integer> con =(t)->{
			
			System.out.println("Con value :"+t);
			
		};
		
		con.accept(5);
		
		List<Integer> list = Arrays.asList(1,5,4,6);
		list.stream().forEach(t->System.out.println("printing :"+t));
		
		
	}

}
