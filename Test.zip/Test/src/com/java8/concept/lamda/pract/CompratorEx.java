package com.java8.concept.lamda.pract;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class CompratorEx {
	
	public static void main(String[] args) {
		List<Integer> list =Arrays.asList(4,6,3);
		
		
		Collections.sort(list, ( o1,  o2) -> {
			// TODO Auto-generated method stub
			return o1.compareTo(o2);
		
		});
		list.stream().forEach(t->System.out.println(t));
	}

}
