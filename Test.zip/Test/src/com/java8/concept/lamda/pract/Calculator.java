package com.java8.concept.lamda.pract;

@FunctionalInterface
public interface Calculator {
	
	void sum(int a,int b);

}
