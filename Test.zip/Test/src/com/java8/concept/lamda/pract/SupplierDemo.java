package com.java8.concept.lamda.pract;

import java.util.Arrays;
import java.util.List;
import java.util.function.Supplier;

public class SupplierDemo {
	
	public static void main(String[] args) {
		Supplier<String> supp=()->"hello supp";
		System.out.println(supp.get());
		
		List<String> list = Arrays.asList("fian");
		 System.out.println(list.stream().findAny().orElseGet(supp));
	}

}
