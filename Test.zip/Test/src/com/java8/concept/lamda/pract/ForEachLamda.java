package com.java8.concept.lamda.pract;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ForEachLamda {

	public static void main(String[] args) {
		List<String> list = new ArrayList<>();
		list.add("buddy");
		list.add("sis");
		list.add("big bro");
		
		//list.forEach(t->System.out.println(t));
		list.stream().filter(t->t.startsWith("b")).forEach(t->System.out.println(t));
		
		Map<Integer,String> map = new HashMap<>();
		
		map.put(4, "a");
		map.put(6, "b");
		map.put(7, "d");
		map.put(2, "u");
		
		map.forEach((key,value)->System.out.println(key +" "+value));
		map.entrySet().stream().forEach(obj->System.out.println(obj));
	}

}
