package com.java8.concept.lamda.pract;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

public class PredicateDemo {
	
	public static void main(String[] args) {
		
		Predicate<Integer> predicate=(t)-> t>0;
		System.out.println(predicate.test(1));
		
		List<Integer> list =Arrays.asList(-4,5,6);
		
		list.stream().filter(predicate).forEach(t->System.out.println(t));
		list.stream().filter(t-> t>0).forEach(t->System.out.println(t));
	}

}
