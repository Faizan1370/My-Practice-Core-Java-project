package com.java8.concept.lamda.pract;

public class LamdaEx{
	
	public static void main(String[] args) {
		 Calculator cal= (a,b)->
			 System.out.println("Sum is :"+(a+b));
		 cal.sum(3,5);
		 
		 Thread t1 = new Thread(()-> {
					System.out.println("Hello run");
				
				
			});
			
			t1.start();

	}
	
	
	

	

}
