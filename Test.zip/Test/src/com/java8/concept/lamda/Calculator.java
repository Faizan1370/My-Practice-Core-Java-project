package com.java8.concept.lamda;

public interface Calculator {
 //void switchOn();
	void sum(int input);
}
