package com.java8.concept.lamda;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

public class ConsumerDemo{
	
	public static void main(String[] args) {
		Consumer<Integer> conD=(t)->//{
			System.out.println("printting :"+t);
		//};
		conD.accept(10);
		
		List<Integer> asList = Arrays.asList(1,5,7,8);
		//asList.stream().forEach(conD);
		asList.stream().forEach(t->System.out.println("printting :"+t));
	}
	



	

}
