package com.java8.concept.optional.pract;

import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import com.java8.concept.streamApi.sortList.Employee;

public class OptionalPract {
	
	public static void main(String[] args) {
		Optional<Employee> op = Optional.empty();
		System.out.println(op);
		getEmployess().forEach(t->{
			System.out.println(op.of(t.getName()));
			System.out.println(op.ofNullable(t.getName()));
			System.out.println(op.ofNullable(t.getName()).isPresent());
			System.out.println(op.ofNullable(t.getName()).orElse("amir"));
		});
		
	}
	
	public static Stream<Employee> getEmployess(){
		return Stream.of(
				new Employee(6, "zayan", "Manager", 700),
				new Employee(7, "Far", "Manager", 600),
				new Employee(9, "fai", "Manager", 1000)
				);
	}

}
