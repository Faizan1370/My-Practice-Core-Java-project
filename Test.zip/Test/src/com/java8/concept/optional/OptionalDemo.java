package com.java8.concept.optional;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.java8.concept.streamApi.sortList.Employee;

public class OptionalDemo {
	static List<Employee> list =new ArrayList<>();
	 static{
		 Employee emp= new Employee(100, "Faizan", "Software Engineer",500000);
		 Employee emp1= new Employee(700, null, "QA tester",600000);
		 Employee emp2= new Employee(400, "Minhaz", "C++ developer",400000);
		 Employee emp3= new Employee(300, "Kamlesh", "Senior Software Engineer",800000);
		 list.add(emp);
		 list.add(emp1);
		 list.add(emp2);
		 list.add(emp3);
		
	}
	
	public static void main(String[] args) {
		Optional<Object> optional = Optional.empty();
		System.out.println(optional);
		list.stream().forEach(t->{
			//System.out.println(Optional.of(t.getName())); // will thow null pointer exeption if any value is null
			//System.out.println(Optional.ofNullable(t.getName())); // this will return optional.empty if value  is null.
			
			//if(Optional.ofNullable(t.getName()).isPresent()) {
				//System.out.println(Optional.ofNullable(t.getName()));	// this will not return anything if value is not present
			//}
			//System.out.println(Optional.ofNullable(t.getName()).orElse("Ajay")); // it will return deafault name if value is null
			
			System.out.println(Optional.ofNullable(t.getName()).map(String::toUpperCase).orElseGet(()->"Default name"));//map transform lower to upper if value is presnet if not then optional will show default
			
			
		});
		
	}

}
