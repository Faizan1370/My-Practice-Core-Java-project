package com.interviewbit;

import java.util.Comparator;

public class NameComparator implements Comparator<Commite>{

	@Override
	public int compare(Commite o1, Commite o2) {
		
		return o1.getMemberName().compareTo(o2.getMemberName());
	}

}
