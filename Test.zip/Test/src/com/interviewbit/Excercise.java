package com.interviewbit;

import java.util.ArrayList;
import java.util.Collections;

public class Excercise {
	
	public static void main(String[] args) {
		ArrayList<Commite> al = new ArrayList<>();
		al.add(new Commite(12 ,"person1",150));
		al.add(new Commite(34 ,"person",33));
		al.add(new Commite(16 ,"person5",29));
		al.add(new Commite(66 ,"person8",56));
		
		//Collections.sort(al);
		
		Collections.sort(al, new NameComparator());
		
		System.out.println(al.toString());
	} 

}
