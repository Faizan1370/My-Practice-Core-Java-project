package com.interviewbit;

public class Commite implements Comparable<Commite>{
	
	private int id;
	private String memberName;
	private double amount;
	
	public Commite(int id,String memberName,double amount) {
		this.id=id;
		this.memberName=memberName;
		this.amount=amount;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getMemberName() {
		return memberName;
	}
	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	
	
	@Override
	public String toString() {
		return "Commite [id=" + id + ", memberName=" + memberName + ", amount=" + amount + "]";
	}
	@Override
	public int compareTo(Commite comtie) {
		if(id==comtie.id) {
			return 0;
		}else if(id>comtie.id) {
			return 1;
		}else {
		return -1;
		}
	}
	
	

}
