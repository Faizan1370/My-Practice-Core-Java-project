package com.pract.exercise;

public class Company {
	int n;
	
	synchronized void produce(int n) {
		this.n=n;
		System.out.println("Produce value :"+this.n);
	}
	
	synchronized void consume() {
		System.out.println("Consume Value :"+this.n);
	}
	

}
