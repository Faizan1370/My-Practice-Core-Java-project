package com.pract.exercise;

public class TrafficLightInfo {
	private static final int RED=0;
	private static final int YEALLOW =1;
	private static final int GREEN=2;
	
	private int currentCoulor;
	
	public TrafficLightInfo() {
		currentCoulor=RED;
	}
	
	public  void toggle() {
		switch(currentCoulor) {
		case RED:
			System.out.println("Current corlor is Red");
			currentCoulor=YEALLOW;
			try {
				Thread.sleep(20000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
			case YEALLOW:
				System.out.println("Current color is Yellow");
				currentCoulor=GREEN;
			try {
				Thread.sleep(20000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
			case GREEN:
				System.out.println("Current color is Green");
				currentCoulor=RED;
			try {
				Thread.sleep(20000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
