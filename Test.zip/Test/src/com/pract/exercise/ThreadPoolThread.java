package com.pract.exercise;

public class ThreadPoolThread implements Runnable {
	
	private String message;
	
	public ThreadPoolThread(String message) {
		this.message=message;
	}

	@Override
	public void run() {
		System.out.println("Current thread :"+Thread.currentThread().getId() +"message  :"+this.message);
		
		try {
			Thread.sleep(200);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 System.out.println("Current thread :"+Thread.currentThread().getId()+" (End)");
	}

}
