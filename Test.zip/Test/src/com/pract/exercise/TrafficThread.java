package com.pract.exercise;

import com.multitread.redlight.TrafficLight;

public class TrafficThread  implements Runnable{
   private	TrafficLightInfo info;
   
   public TrafficThread(TrafficLightInfo info) {
	this.info=info;
   }

	@Override
	public void run() {
		while(true) {
			info.toggle();
		}
		
		
	}
	
	public static void main(String[] args) {
		TrafficLightInfo info= new TrafficLightInfo();
		TrafficThread t1= new TrafficThread(info);
		Thread t2 = new Thread(t1);
		t2.start();
	}

}
