package com.pract.exercise;

public class BankAccount {
	private double balance=0.0;
	
	synchronized void deposit(double amount) {
		this.balance +=amount;
		System.out.println("Deposited amount :"+amount);
		System.out.println("balacne after desposit :"+this.balance);
		notify();
	}
	
	synchronized void withdraw(double amount) {
		while(this.balance<amount) {
			try {
				System.out.println("Insuffiaint balance "+this.balance);
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		this.balance -=amount;
		System.out.println("withdraw amount :"+amount);
		System.out.println("balacne after withdraw :"+this.balance);
	}

}
