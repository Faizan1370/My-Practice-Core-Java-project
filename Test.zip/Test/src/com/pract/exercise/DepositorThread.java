package com.pract.exercise;

public class DepositorThread extends Thread{
	
	private BankAccount account;
	
	public DepositorThread(BankAccount account) {
		this.account=account;
	}
	
	@Override
	public void run() {
		double amount=50;
		while(true) {
			//double amount=Math.random()*2;
			 amount +=50;
			account.deposit(amount);
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

}
