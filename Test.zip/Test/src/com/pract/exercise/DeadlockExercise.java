package com.pract.exercise;

public class DeadlockExercise  {
	public static void main(String[] args) {
		  final String resource1 ="resource1";
		  final String resource2="resource2";
		  
		  Thread t1 = new Thread() {
			   public void run() {
				synchronized (resource1) {
					System.out.println("resource1 locked by thread 1");
					
					synchronized (resource2) {
						System.out.println("resource1 locked by thread 1");
						
					}
				}   
			   }
		  };
		  
		  Thread t2 = new Thread() {
			 public void run() {
				 synchronized (resource2) {
					 
					 System.out.println("resource2 locked by thread 2");
					 
					 synchronized (resource1) {
						 System.out.println("resource1 locked by thread 2");
					}
					
				}
			 }
		  };
		  
		  t1.start();
		  t2.start();
	}
	

}
