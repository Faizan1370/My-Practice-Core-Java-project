package com.pract.exercise;

public class ConsumerThread implements Runnable {
	
	Company company;
	
	public ConsumerThread(Company company) {
		this.company=company;
	}

	@Override
	public void run() {
		while(true) {
		this.company.consume();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	}

}
