package com.pract.exercise;

public class PractNew {
	
	private int count=0;
	
	public synchronized  void increament() {
		count++;
		System.out.println("value :"+count);
	}
	
	public static void main(String[] args) {
		PractNew prac = new PractNew();
		Thread t1 = new Thread(()->prac.increament());
		Thread t2 = new Thread(()->prac.increament());
		t1.start();
		t2.start();
	}

}
