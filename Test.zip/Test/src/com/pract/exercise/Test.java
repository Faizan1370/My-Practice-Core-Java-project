package com.pract.exercise;

public class Test {
	
	public static void main(String[] args) {
		Company com= new Company();
		ProducerThread pro = new ProducerThread(com);
		ConsumerThread con=new ConsumerThread(com);
		
		Thread t1= new Thread(pro);
		Thread t2= new Thread(con);
		
		t1.start();
		t2.start();
		
	}

}
