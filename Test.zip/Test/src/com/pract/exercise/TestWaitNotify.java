package com.pract.exercise;

public class TestWaitNotify {
	
	public static void main(String[] args) {
		BankAccount account = new BankAccount();
		DepositorThread t1 = new DepositorThread(account);
		WithdrawThread t2 =new WithdrawThread(account);
		
		t1.start();
		t2.start();
	}

}
