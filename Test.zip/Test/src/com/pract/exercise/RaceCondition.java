package com.pract.exercise;

public class RaceCondition  implements Runnable{
	
	int counter;
	
	
	public void increment() {
		try {
			Thread.sleep(10);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		counter++;
	}
	 public void decreament() {
		 counter--;
	 }
	 
	 public int getValue() {
		 return counter;
	 }
	@Override
	public void run() {
		//synchronized (this) {
			
			this.increment();
			System.out.println("Value for Thread After increment " + Thread.currentThread().getName() + " value " + this.getValue());  
			//decrementing  
			this.decreament();  
			System.out.println("Value for Thread after decrement " + Thread.currentThread().getName() + "value " + this.getValue());  ;
			
		//}
		
	}


	public static void main(String[] args) {
		RaceCondition race = new RaceCondition();
		Thread t1= new Thread(race);
		Thread t2= new Thread(race);
		Thread t3= new Thread(race);
		
		t1.start();
		t2.start();
		t3.start();
		

	}

	
}
