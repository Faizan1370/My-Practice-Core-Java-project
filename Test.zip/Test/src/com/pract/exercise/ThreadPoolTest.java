package com.pract.exercise;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.multitread.threadpool.WorkerThread;

public class ThreadPoolTest {

	public static void main(String[] args) {
	  ExecutorService executorService = Executors.newFixedThreadPool(5);
	  
	  for(int i=0;i<10;i++) {
		  Runnable thread= new WorkerThread(""+i);
		  executorService.execute(thread);
	  }
	  executorService.shutdown();
	  while(!executorService.isTerminated()) {}
	  System.out.println("All thread terminated");

	}

}
