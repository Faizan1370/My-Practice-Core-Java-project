package com.pract.exercise;

import java.util.concurrent.locks.ReentrantLock;

public class ReentrantLockTst {
	
	private final ReentrantLock rlock = new ReentrantLock();
	
	public void show() {
		rlock.lock();
		try {
			System.out.println("show for current thread :"+Thread.currentThread().getName());
			
		} finally {
			rlock.unlock();
		}
	}
	
	
}
