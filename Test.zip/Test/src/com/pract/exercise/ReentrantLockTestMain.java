package com.pract.exercise;

public class ReentrantLockTestMain {
	
	public static void main(String[] args) {
		ReentrantLockTst lockTst = new ReentrantLockTst();
		Thread t1 = new Thread() {
			
			@Override
			public void run() {
				int i=0;
				while(i<3) {
					lockTst.show();	
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					i++;
				}
				
			}
			
		};
		
		Thread t2 = new Thread() {
			
			@Override
			public void run() {
				int i=0;
				while(i<3) {
					lockTst.show();	
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					i++;
				}
			}
			
		};
		
		t1.start();
		t2.start();
	}

}
