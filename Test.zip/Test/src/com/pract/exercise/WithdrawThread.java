package com.pract.exercise;

public class WithdrawThread  extends Thread{
   private BankAccount account;
   
  public WithdrawThread(BankAccount account) {
	   this.account=account;
   }
  @Override
  public void run() {
	 while(true) {
		 //double amount=Math.random()*50;
		 double amount = 100;
		 account.withdraw(amount);
		 
		 try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 }
  }
}
