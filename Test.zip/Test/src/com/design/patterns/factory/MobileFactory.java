package com.design.patterns.factory;

public class MobileFactory {
	
	public Mobile oderPhone(String keyword) {
		if(keyword==null || keyword.isBlank()) {
			return null;
		}else if(keyword.equalsIgnoreCase("IPHONE")) {
			return new Iphone();
		}else if(keyword.equalsIgnoreCase("REALME")) {
			return new RealMe();
		}else if(keyword.equalsIgnoreCase("ONEPLUS")) {
			return new Iphone();
		}else {
			return new OnePlus();
		}
	}

}
