package com.design.patterns.factory;

public class OnePlus implements Mobile{

	@Override
	public void createMobile() {
		System.out.println("Creating One Plus");
		
	}

}
