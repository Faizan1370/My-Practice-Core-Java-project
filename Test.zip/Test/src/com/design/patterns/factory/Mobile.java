package com.design.patterns.factory;

public interface Mobile {
	
	void createMobile();

}
