package com.design.patterns.factory;

public class TestFactory {
	
	public static void main(String[] args) {
		MobileFactory factory = new MobileFactory();
		System.out.println(factory.oderPhone("IPHONE"));
		Mobile oderPhone = factory.oderPhone("REALME");
		oderPhone.createMobile();
	}
}
