package com.design.patterns.factory;

public class RealMe implements Mobile{

	@Override
	public void createMobile() {
		System.out.println("Creating Real Me Mobile");
		
	}

}
