package com.design.patterns.singleton;

public class Singleton {
	private static Singleton obSingleton;
	//private static Singleton objClassLevel = new Singleton(); in this will create new object at the time of class loading and can directly return
	private Singleton() {}
	
	public static Singleton getSingletonInstance() { //this way is not thread safe may be create more than one object by multiple thread
		if(obSingleton== null) {
			obSingleton= new Singleton();
		}
		return obSingleton;
	}
	public static  synchronized Singleton getSingletonInstance1() { //this is thread safe but performance issue
		if(obSingleton== null) {
			obSingleton= new Singleton();
		}
		return obSingleton;
	}
	//public static  synchronized Singleton getSingletonInstance2() { //this is thread safe but performance issue
		
		//return objClassLevel;
	//}
	

}
