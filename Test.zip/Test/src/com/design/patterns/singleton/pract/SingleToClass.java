package com.design.patterns.singleton.pract;

public class SingleToClass {
	
	private static SingleToClass singleToClass =null;
	
	
	private SingleToClass() {
		// TODO Auto-generated constructor stub
	}
	
	public static SingleToClass getClassInstance() {
		if(singleToClass==null) {
			singleToClass=new SingleToClass();
		}
		
		return singleToClass;
		
	}

}
