package com.design.patterns.strategy;

public class CoupanDiscount implements DiscountStrategy {

	@Override
	public void giveDiscount() {

		System.out.println("This is coupan discount");
	}

}
