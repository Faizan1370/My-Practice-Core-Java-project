package com.design.patterns.strategy;

public class TestStrategy {
	public static void main(String[] args) {
		ApplyDiscount applyDiscount = new ApplyDiscount(new FlatDiscount());
		applyDiscount.getDiscount();
		applyDiscount.setDiscountStrategy(new CashbackDiscount());
		applyDiscount.getDiscount();
	}

}
