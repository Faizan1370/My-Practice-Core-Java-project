package com.design.patterns.strategy.sorting.algo;

public class QuickSort implements ArraySortingStrategy{

	@Override
	public void sortArray() {
       System.out.println("This is Quick Sort");		
	}

}
