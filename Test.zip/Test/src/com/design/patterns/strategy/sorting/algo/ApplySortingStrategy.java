package com.design.patterns.strategy.sorting.algo;

public class ApplySortingStrategy {
	private ArraySortingStrategy arraySortingStrategy;

	public ApplySortingStrategy(ArraySortingStrategy arraySortingStrategy) {
		super();
		this.arraySortingStrategy = arraySortingStrategy;
	}
	
	public void getSorting() {
		arraySortingStrategy.sortArray();
	}
	
	public void setArraySortingStrategy(ArraySortingStrategy arraySortingStrategy) {
		this.arraySortingStrategy=arraySortingStrategy;
	}

}
