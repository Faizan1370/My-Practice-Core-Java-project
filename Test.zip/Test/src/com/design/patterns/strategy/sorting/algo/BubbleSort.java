package com.design.patterns.strategy.sorting.algo;

import java.util.Arrays;

public class BubbleSort implements ArraySortingStrategy{

	@Override
	public void sortArray() {
        System.out.println("This is Bubble Sort");
        
        int[] a= {45,67,23,65,90,34};
        System.out.println("Before sort :"+Arrays.toString(a));
        int temp=0;
     // in this case for loop tp a.lenght-1 will always copmare till last elemtnt but we already moved the largest element in the last so we can ignore
        // so the new cas will be a.length-1-i;
        //if we have many elements in the array and we know no sorting or swapping need means already sorted.
        // we can use the flag or in flag this flag will save the time.
        for(int i=0;i<a.length;i++) {
        	int flag=0;
        	//for(int j=0;j<a.length-1;j++) { 
        		for(int j=0;j<a.length-1-i;j++) { 
        		if(a[j]>a[j+1]) {
        			temp=a[j];
        			a[j]=a[j+1];
        			a[j+1]=temp;
        			flag=1;
        		}
        	}
        		if(flag==0) {
        			break;
        		}
        }
        System.out.println("After sort :"+Arrays.toString(a));
	}

}
