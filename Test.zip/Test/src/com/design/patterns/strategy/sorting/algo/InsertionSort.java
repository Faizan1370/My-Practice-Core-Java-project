package com.design.patterns.strategy.sorting.algo;

import java.util.Arrays;

public class InsertionSort implements ArraySortingStrategy{

	@Override
	public void sortArray() {
		System.out.println("This is Insertion sort");
		int[] a= {45,67,23,65,90,34};
        System.out.println("Before sort :"+Arrays.toString(a));
        
        int j=0,temp=0;
        for(int i=1;i<a.length;i++) {
        	j=i;
        	temp=a[i];
        	while(j>0 && a[j-1]>temp) {
        		a[j]=a[j-1];
        		j--;
        	}
        	a[j]=temp;
        }
        
        System.out.println("After Sort :"+Arrays.toString(a));
	}

}
