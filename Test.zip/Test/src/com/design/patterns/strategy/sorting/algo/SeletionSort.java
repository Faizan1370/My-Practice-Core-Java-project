package com.design.patterns.strategy.sorting.algo;

import java.util.Arrays;

public class SeletionSort implements ArraySortingStrategy{

	@Override
	public void sortArray() {
		System.out.println("This is Selection sort");
		int[] a= {45,67,23,65,90,34};
        System.out.println("Before sort :"+Arrays.toString(a));
        int min=Integer.MAX_VALUE;
        int min_index=0;
        int temp=0;
        int j=0;
        for(int k=0;k<a.length;k++) {
        for(int i=k;i<a.length;i++) {
        	if(a[i]<min) {
        		min=a[i];
        		min_index=i;
        	}
        	
        }
        temp=a[j];
    	a[j]=a[min_index];
    	a[min_index]=temp;
    	j++;
    	min=Integer.MAX_VALUE;
    	//min_index=0;
        }
    	
    	System.out.println("After Sort :"+Arrays.toString(a));
	}

}
