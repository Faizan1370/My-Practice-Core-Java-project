package com.design.patterns.strategy.sorting.algo;

public class MergeSort implements ArraySortingStrategy {

	@Override
	public void sortArray() {

		System.out.println("This is Merge Sort");
	}

}
