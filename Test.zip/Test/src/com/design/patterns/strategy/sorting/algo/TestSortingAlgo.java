package com.design.patterns.strategy.sorting.algo;

public class TestSortingAlgo {
	
	public static void main(String[] args) {
		ApplySortingStrategy applySortingStrategy = new ApplySortingStrategy(new BubbleSort());
	    applySortingStrategy.getSorting();
		
		applySortingStrategy.setArraySortingStrategy(new SeletionSort());
		applySortingStrategy.getSorting();
		applySortingStrategy.setArraySortingStrategy(new InsertionSort());
		applySortingStrategy.getSorting();
	}

}
