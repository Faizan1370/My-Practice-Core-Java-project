package com.design.patterns.strategy.sorting.algo;

public interface ArraySortingStrategy {
	
	void sortArray();

}
