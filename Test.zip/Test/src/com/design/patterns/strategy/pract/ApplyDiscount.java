package com.design.patterns.strategy.pract;

public class ApplyDiscount {
	
	private DiscountStrategy discountStrategy;
	
	public ApplyDiscount(DiscountStrategy discountStrategy) {
		this.discountStrategy=discountStrategy;
	}
	
	public void getDiscount() {
		discountStrategy.giveDiscount();
	}
	
	public void setDiscount(DiscountStrategy discountStrategy) {
		this.discountStrategy=discountStrategy;
	}

}
