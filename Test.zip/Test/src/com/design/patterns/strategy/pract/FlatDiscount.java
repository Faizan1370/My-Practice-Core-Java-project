package com.design.patterns.strategy.pract;

public class FlatDiscount implements DiscountStrategy{

	@Override
	public void giveDiscount() {
		System.out.println("FLat Discount");
		
	}
}
