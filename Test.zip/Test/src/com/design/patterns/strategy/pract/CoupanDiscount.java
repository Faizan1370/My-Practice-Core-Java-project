package com.design.patterns.strategy.pract;

public class CoupanDiscount implements DiscountStrategy{

	@Override
	public void giveDiscount() {
		System.out.println("Coupan Discount");
		
	}

}
