package com.design.patterns.strategy.pract;

public interface DiscountStrategy {
	
	void giveDiscount();

}
