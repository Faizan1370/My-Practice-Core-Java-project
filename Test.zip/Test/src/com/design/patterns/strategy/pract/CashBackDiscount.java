package com.design.patterns.strategy.pract;

public class CashBackDiscount implements DiscountStrategy {

	@Override
	public void giveDiscount() {
		System.out.println("Cash Back Discount");
		
	}

}
