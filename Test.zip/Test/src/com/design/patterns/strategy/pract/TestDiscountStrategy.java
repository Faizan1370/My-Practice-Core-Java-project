package com.design.patterns.strategy.pract;

public class TestDiscountStrategy {
	
	public static void main(String[] args) {
		ApplyDiscount applyDiscount = new ApplyDiscount(new FlatDiscount());
		applyDiscount.getDiscount();
		applyDiscount.setDiscount(new CashBackDiscount());
		applyDiscount.getDiscount();
	}

}
