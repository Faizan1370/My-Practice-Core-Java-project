package com.design.patterns.strategy;

public class CashbackDiscount implements DiscountStrategy{

	@Override
	public void giveDiscount() {
		System.out.println("This is coupan discount");
	}

}
