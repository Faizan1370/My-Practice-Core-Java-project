package com.design.patterns.strategy;

public interface DiscountStrategy {
	
	void giveDiscount();

}
