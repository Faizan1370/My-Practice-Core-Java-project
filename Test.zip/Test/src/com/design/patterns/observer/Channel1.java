package com.design.patterns.observer;

import java.util.ArrayList;
import java.util.List;

public class Channel1 implements Subject {
	ArrayList<Observer> observerList = new ArrayList<>();

	@Override
	public void registerObserver(Observer observer) {
       observerList.add(observer);
	}

	@Override
	public void unregisterObserver(Observer observer) {
      //int indexOf = observerList.indexOf(observer);
      //if(indexOf>0) {
    	  observerList.remove(observer);
    	  System.out.println("User has been removed :"+observer.getClass());
      //}
	}

	@Override
	public void notifyObserver(String msg) {
     observerList.stream().forEach(t->t.update(msg)); 
	}
	
	public void addNewVideo(String msg) {
		notifyObserver(msg);
	}

}
