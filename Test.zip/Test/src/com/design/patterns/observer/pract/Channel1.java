package com.design.patterns.observer.pract;

import java.util.ArrayList;
import java.util.Arrays;

public class Channel1 implements Subject{
	
	ArrayList<Observer> observerList = new ArrayList<>();

	@Override
	public void regiterObserver(Observer observer) {
		observerList.add(observer);
		
	}

	@Override
	public void unregisterObeserver(Observer observer) {
		if(observerList.size()>0) {
			observerList.remove(observer);
			System.out.println("User removed :"+observer.getClass());
		}
	}

	@Override
	public void notifyObserver(String message) {
		observerList.stream().forEach(t->t.update(message));
		
	}
	
	public void addNewVideo(String message) {
		notifyObserver(message);
	}

}
