package com.design.patterns.observer.pract;

public interface Observer {
	
	void update(String message);

}
