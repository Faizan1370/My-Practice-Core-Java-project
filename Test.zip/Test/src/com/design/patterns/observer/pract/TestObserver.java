package com.design.patterns.observer.pract;

public class TestObserver {
	
	public static void main(String[] args) {
		Channel1 channnel1 = new Channel1();
		User1 user1 = new User1();
		channnel1.regiterObserver(user1);
		channnel1.regiterObserver(new User2());
		channnel1.unregisterObeserver(user1);
		channnel1.addNewVideo("Added new Video");
	}

}
