package com.design.patterns.observer.pract;

public interface Subject {
	void regiterObserver(Observer observer);
	void unregisterObeserver(Observer observer);
	void notifyObserver(String message);

}
