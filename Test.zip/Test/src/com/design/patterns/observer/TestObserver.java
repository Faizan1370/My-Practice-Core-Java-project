package com.design.patterns.observer;

public class TestObserver {
	public static void main(String[] args) {
		User1 user1= new User1();
		Channel1 channel1 = new Channel1();
		channel1.registerObserver(user1);
		channel1.registerObserver(new User2());
		channel1.unregisterObserver(user1);
		channel1.registerObserver(user1);
		channel1.addNewVideo("new video Added");
		
	}

}
