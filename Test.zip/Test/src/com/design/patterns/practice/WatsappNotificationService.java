package com.design.patterns.practice;

public class WatsappNotificationService implements NotificationService {
	
	@Override
	public void sendNotification(String message) {
		 System.out.println("Sending notification using watsapp :"+message);
		
	}

}
