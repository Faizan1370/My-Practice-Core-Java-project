package com.design.patterns.practice;

public class MobileNotificationService implements NotificationService{

	@Override
	public void sendNotification(String message) {
		 System.out.println("Sending notification using Mobile :"+message);
		
	}

}
