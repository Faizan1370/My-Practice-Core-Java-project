package com.design.patterns.practice;

public interface NotificationService {
	
	void sendNotification(String message);

}
