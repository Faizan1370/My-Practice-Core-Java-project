package com.design.patterns.practice;

public class SendNotifications {
	
	private NotificationService notificationService;
	
	public SendNotifications(NotificationService notificationService) {
		this.notificationService=notificationService;
	}
	//Use Factory Design Pattern
	public SendNotifications(String type) {
		this.notificationService=NotificationFactory.getNotiFiNotificationService(type);
	}
	
	public void sendNoiticationToUser(String messgae) {
		notificationService.sendNotification(messgae);
	}
	
	public static void main(String[] args) {
		//NotificationService notificationService = new EmailNotificationService(); // if we are not using factory will use this line
		SendNotifications notifications = new SendNotifications("Email");
		notifications.sendNoiticationToUser("80");
	}

}
