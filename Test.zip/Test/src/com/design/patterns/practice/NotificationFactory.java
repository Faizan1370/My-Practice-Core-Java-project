package com.design.patterns.practice;

public class NotificationFactory {
	
	public static NotificationService getNotiFiNotificationService(String type) {
		if(type.equalsIgnoreCase("Mobile")) {
			 return new MobileNotificationService();
		}else if(type.equalsIgnoreCase("Watssapp")) {
			 return new WatsappNotificationService();
		}else if(type.equalsIgnoreCase("Email")) {
			 return new EmailNotificationService();
		}else {
			throw new IllegalArgumentException("Illgeal Arugement type :"+type);
		}
	}

}
