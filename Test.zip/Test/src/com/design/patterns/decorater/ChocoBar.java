package com.design.patterns.decorater;

public class ChocoBar extends Icecream {
	
	@Override
	public String getDescription() {
		 return "Chochobar";	
	}
		

	@Override
	int getCost() {
		return 70;
	}

}
