package com.design.patterns.decorater;

public class Cone  extends Icecream{
	
	@Override
	public String getDescription() {
		 return "Cone";
	}
		

	@Override
	int getCost() {
		// TODO Auto-generated method stub
		return 80;
	}

}
