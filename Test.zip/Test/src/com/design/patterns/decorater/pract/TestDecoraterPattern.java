package com.design.patterns.decorater.pract;

public class TestDecoraterPattern {
	
	public static void main(String[] args) {
		Icecream icecream = new Chocobar();
		
	     icecream= new ChocoSyrupDecorater(icecream);
	    System.out.println(icecream.getCost());
	     System.out.println(icecream.getDescription());
	}

}
