package com.design.patterns.decorater.pract;

public class ChocoSyrupDecorater extends IcecreamDecorater{
 
	private Icecream icecream;
	
	public ChocoSyrupDecorater(Icecream icecream) {
		this.icecream=icecream;
	}
	
	
	@Override
	int getCost() {
		
		return icecream.getCost() +20;
	}
	
	@Override
	public String getDescription() {
		return icecream.getDescription()+ " with chocho syrup";
		
	}


}
