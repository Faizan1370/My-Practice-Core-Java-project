package com.design.patterns.decorater.pract;

public abstract class ChochoChipsDecorater  extends IcecreamDecorater{
	
private Icecream icecream;
	
	@Override
	int getCost() {
		
		return icecream.getCost() +30;
	}
	
	public String getDescripion() {
		return icecream.getDescription()+" "+"With Choco Chips";
	}


}
