package com.design.patterns.decorater.pract;

public class Vanila  extends Icecream{
	
	

	@Override
	int getCost() {
		
		return 50;
		
	}
	
	@Override
	public String getDescription() {
		return "Vanila";
		
	}

}
