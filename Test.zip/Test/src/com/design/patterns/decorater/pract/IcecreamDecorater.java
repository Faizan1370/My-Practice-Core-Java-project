package com.design.patterns.decorater.pract;

public abstract class IcecreamDecorater extends Icecream {

	abstract int getCost();
}
