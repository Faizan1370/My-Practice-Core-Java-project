package com.design.patterns.decorater.pract;

public class Chocobar extends Icecream{

	@Override
	int getCost() {
		// TODO Auto-generated method stub
		return 70;
	}
	
	public String getDescription() {
		return "Chocobar";
		
	}

}
