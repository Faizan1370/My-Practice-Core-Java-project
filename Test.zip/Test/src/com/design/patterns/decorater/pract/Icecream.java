package com.design.patterns.decorater.pract;

public abstract class Icecream {
	
   private String description;
	
	public String getDescription() {
	 return description;	
	}
	abstract int getCost();
    
	

}
