package com.design.patterns.decorater;

public class ChochoCheeseDecorater extends IcecreamDecorater{
	private Icecream icecream;
	
	public ChochoCheeseDecorater(Icecream icecream) {
		this.icecream = icecream;
	}

	
	@Override
	int getCost() {
		// TODO Auto-generated method stub
		return icecream.getCost()+30;
	}
	
	@Override
	public String getDescription() {
		return icecream.getDescription()+ " with chocho Cheese";
		
	}

}
