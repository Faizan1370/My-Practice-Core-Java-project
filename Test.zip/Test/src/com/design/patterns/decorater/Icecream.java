package com.design.patterns.decorater;

public abstract class Icecream {
	private String description;
	
	public String getDescription() {
	 return description;	
	}
	
	abstract int getCost();

}
