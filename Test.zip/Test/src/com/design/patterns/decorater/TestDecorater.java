package com.design.patterns.decorater;

import java.util.Arrays;

public class TestDecorater {
	public static void main(String[] args) {
		Icecream icecream = new ChocoBar();
		icecream = new ChochoSyrupDecorater(new ChochoCheeseDecorater(icecream));
		System.out.println(icecream.getCost()); 
		System.out.println(icecream.getDescription()); 
		findOccurence();
		insertionSort();
		selectionSort();
	}
	
	public static void findOccurence() {
		String str="Welcome to home";
		int[] counter = new int[256];
		
		for(int i=0;i<str.length();i++) {
			counter[(int)str.charAt(i)]++;
		}
		
		for(int i=0;i<256;i++) {
			if(counter[i]!=0 && !Character.isWhitespace((char)i)) {
				System.out.println((char)i+" ->"+ counter[i]);
			}
		}
	}
	
	public static void insertionSort() {
		int[] array = {5,3,6,4,9,1};
		//Arrays.stream(array).sorted().forEach(t->System.out.print(t +" "));
		int j=0,temp=0;
		for(int i=1;i<array.length;i++) {
			j=i;
			temp=array[i];
			
			while(j>0 && array[j-1]>temp) {
				array[j]=array[j-1];
				j--;
			}
			array[j]=temp;
		}
		System.out.println(Arrays.toString(array));
	}
	
	public static void selectionSort() {
		int[] array = {5,3,6,4,9,1};
		int min=Integer.MAX_VALUE;
		int mid_index=0;
		int temp=0;
		for(int i=0;i<array.length;i++) {
			for(int j=i;j<array.length;j++) {
				if(min>array[j]) {
					min=array[j];
					mid_index=j;
				}
			}
			temp=array[i];
			array[i]=array[mid_index];
			array[mid_index]=temp;
			min=Integer.MAX_VALUE;
		}
		
		System.out.println(Arrays.toString(array));
	}

}
