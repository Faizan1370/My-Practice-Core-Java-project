package com.design.patterns.decorater;

public class ChochoSyrupDecorater extends IcecreamDecorater{
	private Icecream icecream;
	
	public ChochoSyrupDecorater(Icecream icecream) {
		this.icecream = icecream;
	}


	@Override
	int getCost() {
		return icecream.getCost()+20;
	}
	
	@Override
	public String getDescription() {
		return icecream.getDescription()+ " with chocho syrup";
		
	}

}
