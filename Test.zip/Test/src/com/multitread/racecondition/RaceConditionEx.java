package com.multitread.racecondition;

public class RaceConditionEx implements Runnable{
	
	private static int counter=0;
	
	public  void increament() {
		try {
			Thread.sleep(10);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		counter++;
	}
	
	public void decreament() {
		counter--;
		
	}
	public int getValue()   
	{  
	return counter;  
	} 
	@Override  
	public void run()   
	{  
	synchronized(this)  
	{  
	// incrementing  
	this.increament();  
	System.out.println("Value for Thread After increment " + Thread.currentThread().getName() + " " + this.getValue());  
	//decrementing  
	this.decreament();  
	System.out.println("Value for Thread at last " + Thread.currentThread().getName() + " " + this.getValue());  
	}          
	}  
	
	public static  void main(String[] args) {
		RaceConditionEx runn= new RaceConditionEx();
		Thread t1= new Thread(runn);
		Thread t2= new Thread(runn);
		Thread t3= new Thread(runn);
		t1.start();
		t2.start();
		t3.start();
		
		
	}

	

}
