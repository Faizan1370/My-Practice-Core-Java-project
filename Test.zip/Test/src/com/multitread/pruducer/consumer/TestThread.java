package com.multitread.pruducer.consumer;

public class TestThread {
	public static void main(String[] args) {
		Company com= new Company();
		ProducerThread t1= new ProducerThread(com);
		ConsumerThread t2= new ConsumerThread(com);
		
		Thread t3 = new Thread(t1);
		Thread t4 = new Thread(t2);
		
		t3.start();
		t4.start();
		
	}

}
