package com.multitread.pruducer.consumer;

public class Company {
	int n;
	
	synchronized public void produesNumber(int n) {
		this.n=n;
		System.out.println("Producer Number :"+this.n);
	}
	
	
	synchronized public void cunsumesNumber() {
		System.out.println("Consumes Number :"+this.n);
	}

}
