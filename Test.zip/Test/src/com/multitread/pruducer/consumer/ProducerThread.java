package com.multitread.pruducer.consumer;

public class ProducerThread implements Runnable{
	Company company;
	
	public ProducerThread(Company company) {
		this.company=company;
	}

	@Override
	public void run() {
		int i=1;
		while(true) {
			this.company.produesNumber(i);
			i++;
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

}
