package com.multitread;

public class ThreadGroupEx implements Runnable{

	@Override
	public void run() {
		System.out.println(Thread.currentThread().getName());
	}
	
	public static void main(String[] args) {
		ThreadGroupEx runnable = new ThreadGroupEx();
		ThreadGroup thGroup = new ThreadGroup("Parent ThreadGroup");
		
		Thread t1= new Thread(thGroup,runnable,"one");
		t1.start();
		
		Thread t2= new Thread(thGroup,runnable,"two");
		t2.start();
		
		Thread t3= new Thread(thGroup,runnable,"three");
		t3.start();
		
		System.out.println("Group Name :"+thGroup.getName());
		thGroup.list();
		
	}
	

}
