package com.multitread.callable;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class InvokeAllExample {

	public static void main(String[] args) {
		ExecutorService executorService = Executors.newFixedThreadPool(3);
		
		List<Callable<String>> list = Arrays.asList(
				 () -> {
				 Thread.sleep(2000);
				 return "Task 1 done";	
				},
				 () -> {
					 Thread.sleep(2000);
					 return "Task 2 done";	
					},
				 () -> {
					 Thread.sleep(2000);
					 return "Task 3 done";	
					}
				);
		
		try {
			List<Future<String>> invokeAll = executorService.invokeAll(list);
			 for (Future<String> future : invokeAll) {
				 try {
					System.out.println(future.get());
				} catch (ExecutionException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} // Get results sequentially
			 }
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		executorService.shutdown();

	}

}
