package com.multitread.callable;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class CallablePrac {
	public static void main(String[] args) {
		
		ExecutorService executorService = Executors.newFixedThreadPool(1);
		
		Callable<String> task = () ->{
			Thread.sleep(2000);
			return "Task Completed";
			
		};
		
		Future<String> futures = executorService.submit(task);
		
		
			System.out.println("Waiting for result");
			String string;
			try {
				string = futures.get();
				System.out.println("Result :"+string);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ExecutionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
            
      
		executorService.shutdown();
	}
	

}
