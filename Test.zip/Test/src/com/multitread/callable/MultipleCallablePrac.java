package com.multitread.callable;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class MultipleCallablePrac {

	public static void main(String[] args) {
		 ExecutorService executorService = Executors.newFixedThreadPool(4);
		 
		 Callable<Integer> task1 = ()->{
			Thread.sleep(4000);
			return 10; 
		 };
		 Callable<Integer> task2 = ()->{
				Thread.sleep(4000);
				return 30; 
			 };
			 Callable<Integer> task3 = ()->{
					Thread.sleep(4000);
					return 50; 
				 };
				// Callable<Integer> faultyTask = () -> {
			      //      throw new Exception("Something went wrong!");
			        //};
				 
				 Future<Integer> future1 = executorService.submit(task1);
				 Future<Integer> future2 = executorService.submit(task2);
				 Future<Integer> future3 = executorService.submit(task3);
				 //Future<Integer> future4 = executorService.submit(faultyTask);
				 
				 
				 try {
					System.out.println("Taks 1 Result :"+future1.get());
					System.out.println("Taks 2 Result :"+future2.get());
					System.out.println("Taks 3 Result :"+future3.get());
					//System.out.println("Taks 3 Result :"+future4.get());
					
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ExecutionException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			executorService.shutdown();
	}

}
