package com.multitread.dealock;

public class Thread1Lock extends Thread{
	
	private SharedResource resource;
	
	public Thread1Lock(SharedResource resource) {
		this.resource=resource;
	}
	
	@Override
	public void run() {
		resource.method1();
		
	}

}
