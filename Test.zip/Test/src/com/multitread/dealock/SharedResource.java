package com.multitread.dealock;

public class SharedResource {
	 private final String lock1 = "lock1";
	    private final String lock2 = "lock2";

	    public void method1() {
	    	synchronized (lock1) {
	            System.out.println("Thread 1: Locked resource1: " + lock1);
	            try {
	                Thread.sleep(100);
	            } catch (InterruptedException e) {
	                e.printStackTrace();
	            }

	            synchronized (lock2) {
	                System.out.println("Thread 1: Locked Resource 2: " + lock2);
	            }
	        }
	    }

	    public void method2() {
	    	synchronized (lock2) {
	            System.out.println("Thread 2: Locked resource2: " + lock2);
	            try {
	                Thread.sleep(100);
	            } catch (InterruptedException e) {
	                e.printStackTrace();
	            }

	            synchronized (lock1) {
	                System.out.println("Thread 2: Locked Resource 1: " + lock1);
	            }
	        }
	    }
}
