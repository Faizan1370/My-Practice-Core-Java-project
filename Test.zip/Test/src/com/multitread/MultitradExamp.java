package com.multitread;

public class MultitradExamp {
	
	class TrafficLight {
		  private static final int RED = 0;
		  private static final int YELLOW = 1;
		  private static final int GREEN = 2;

		  private int currentColor;

		  public TrafficLight() {
		    currentColor = RED;
		  }

		  public void toggle() {
		    switch (currentColor) {
		      case RED:
		        System.out.println("Red");
		        currentColor = YELLOW;
		        try {
		          Thread.sleep(3000);
		        } catch (InterruptedException e) {
		          e.printStackTrace();
		        }
		        break;
		      case YELLOW:
		        System.out.println("Yellow");
		        currentColor = GREEN;
		        try {
		          Thread.sleep(1000);
		        } catch (InterruptedException e) {
		          e.printStackTrace();
		        }
		        break;
		      case GREEN:
		        System.out.println("Green");
		        currentColor = RED;
		        try {
		          Thread.sleep(2000);
		        } catch (InterruptedException e) {
		          e.printStackTrace();
		        }
		        break;
		    }
		  }
		}

		class TrafficLightThread implements Runnable {
		  private TrafficLight light;

		  public TrafficLightThread(TrafficLight light) {
		    this.light = light;
		  }

		  public void run() {
		    while (true) {
		      light.toggle();
		    }
		  }
		}

		public class Main {
		  public static void main(String[] args) {
		    TrafficLight light = new TrafficLight();
		    Thread t = new Thread(new TrafficLightThread(light));
		    t.start();
		  }
		}
		
		
		class TrafficLight {
			  private static final int RED = 0;
			  private static final int YELLOW = 1;
			  private static final int GREEN = 2;

			  private int currentColor;
			  private int redDuration;
			  private int yellowDuration;
			  private int greenDuration;

			  public TrafficLight(int redDuration, int yellowDuration, int greenDuration) {
			    currentColor = RED;
			    this.redDuration = redDuration;
			    this.yellowDuration = yellowDuration;
			    this.greenDuration = greenDuration;
			  }

			  public void toggle() {
			    switch (currentColor) {
			      case RED:
			        System.out.println("Red");
			        currentColor = YELLOW;
			        break;
			      case YELLOW:
			        System.out.println("Yellow");
			        currentColor = GREEN;
			        break;
			      case GREEN:
			        System.out.println("Green");
			        currentColor = RED;
			        break;
			    }
			  }

			  public int getDuration() {
			    switch (currentColor) {
			      case RED:
			        return redDuration;
			      case YELLOW:
			        return yellowDuration;
			      case GREEN:
			        return greenDuration;
			      default:
			        return 0;
			    }
			  }
			}

			class TrafficLightThread implements Runnable {
			  private TrafficLight light;

			  public TrafficLightThread(TrafficLight light) {
			    this.light = light;
			  }

			  public void run() {
			    while (true) {
			      light.toggle();
			      try {
			        Thread.sleep(light.getDuration());
			      } catch (InterruptedException e) {
			        e.printStackTrace();
			      }
			    }
			  }
			}

			public class Main {
			  public static void main(String[] args) {
			    TrafficLight light = new TrafficLight(3000, 1000, 2000);
			    Thread t = new Thread(new TrafficLightThread(light));
			    t.start();
			  }
			}



}
