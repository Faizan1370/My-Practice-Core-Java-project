package com.multitread.redlight;

public class TrafficLight {
	private static final int RED = 0;
	  private static final int YELLOW = 1;
	  private static final int GREEN = 2;
	  
	  private int currentColor;
	  
	  public TrafficLight() {
		currentColor=RED;
	}
	  
	public void toggle() {
		switch(currentColor) {
		case RED:
			System.out.println("Curent color Red");
			currentColor=YELLOW;
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
			
		case YELLOW:
			System.out.println("Courrent color Yellow");
			currentColor=GREEN;
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case GREEN:
			System.out.println("Courrent color Green");
			currentColor=RED;
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		}
	}

}
