package com.multitread.redlight;

public class TrafficLightThread implements Runnable {
	
	private TrafficLight light;
	
	public TrafficLightThread(TrafficLight light) {
		this.light=light;
	}

	@Override
	public void run() {
		while(true) {
		light.toggle();
		}
		
	}
	
	

}
