package com.multitread.redlight;

public class TrafficLightTest {
	public static void main(String[] args) {
		TrafficLight light = new TrafficLight();
		Thread t1= new Thread(new TrafficLightThread(light));
		t1.start();
	}

}
