package com.multitread.waitnotify;

public class WithdrawerThread extends Thread{
private BankAccount account;
	
	public WithdrawerThread( BankAccount account) {
		this.account=account;
	}
	
	@Override
	public void run() {
		while(true) {
			double amount=Math.random()*50;
			account.withdraw(amount);
			 try {
	                Thread.sleep(100);
	            } catch (InterruptedException e) {
	                e.printStackTrace();
	            }
		}
		
	}

}
