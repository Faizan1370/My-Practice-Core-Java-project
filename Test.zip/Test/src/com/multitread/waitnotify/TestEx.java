package com.multitread.waitnotify;

public class TestEx {
	public static void main(String[] args) {
		 BankAccount account = new BankAccount();
		 DepositorThread deposit= new DepositorThread(account);
		 WithdrawerThread withdrwa= new WithdrawerThread(account);
		 deposit.start();
		 withdrwa.start();
		 
			/*
			 * try { deposit.join(); withdrwa.join(); } catch (InterruptedException e) { //
			 * TODO Auto-generated catch block e.printStackTrace(); }
			 */		
	}

}
