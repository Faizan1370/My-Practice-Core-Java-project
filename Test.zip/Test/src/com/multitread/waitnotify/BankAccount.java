package com.multitread.waitnotify;

public class BankAccount {
	private double balance=0.0;
	
	
	public synchronized void deposit(double amount) {
		this.balance+=amount;
		System.out.println("Deposited amount :"+amount);
		notify();
		
	}
	
	public synchronized void withdraw(double amount) {
		while(amount>this.balance) {
			try {
				System.out.println("Insufficiant Balance");
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		balance-=amount;
		System.out.println("Withdraw Amount :"+amount);
	}

}

