package com.multitread.printevenodd;

public class Printer {
	
	private int num=1;
	private int limit;
	
	public Printer(int limit) {
		this.limit=limit;
	}
	
	public synchronized void printOdd() {
		while(num<this.limit) {
			if(num%2==0) { // wait if number is even
				try {
					wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			System.out.println(Thread.currentThread().getName() +": "+num);
			num++;
			notify();
		}
	}
	
	public synchronized void printEven() {
		while(num<=this.limit) {
			if(num%2!=0) { // wait if number is odd
				try {
					wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			System.out.println(Thread.currentThread().getName() +" : "+num);
			num++;
			notify();
		}
		
	}
	
	public static void main(String[] args) {
		Printer printer = new Printer(10);
		Thread t1 = new Thread() {
			@Override
			public void run() {
				printer.printOdd();
			}
			
		};
		//Thread t3 = new Thread(()->printer.printOdd(),"OddThread");
		//Thread t4 = new Thread(()->printer.printEven(),"EvenThread");
		
		Thread t2 = new Thread() {
			@Override
			public void run() {
				printer.printEven();
			}
			
		};
		
		t1.start();
		t2.start();
	}

}
