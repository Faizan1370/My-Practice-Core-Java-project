package com.multitread.printevenodd;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

public class UsingRetrantLock {
	
	private int num=1;
	private int limit;
	
	public UsingRetrantLock(int limit) {
		this.limit=  limit;
	}
	
	
	private ReentrantLock lock = new ReentrantLock();
	private final Condition oddCondition = lock.newCondition();
	private final Condition evenCondition = lock.newCondition();
	
	public void printOddd() {
		lock.lock();
		while(num<this.limit) {
			if(num%2==0) {
				try {
					oddCondition.await();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			System.out.println(Thread.currentThread().getName() +" :"+num);
			num++;
			evenCondition.signal();
		}
		
		lock.unlock();
	}
	public void printEven() {
		lock.lock();
		while(num<=limit) {
			if(num%2!=0) {
				try {
					evenCondition.await();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			System.out.println(Thread.currentThread().getName()+" :"+num);
			num++;
			oddCondition.signal();
		}
		
		lock.unlock();
	}
	
	public static void main(String[] args) {
		UsingRetrantLock retrantLock = new UsingRetrantLock(10);
		ExecutorService executorService = Executors.newFixedThreadPool(2);
		executorService.execute(()->retrantLock.printOddd());
		executorService.execute(()->retrantLock.printEven());
		//Thread t1 = new Thread(()->retrantLock.printOddd(),"OddThread");
		//Thread t2 = new Thread(()->retrantLock.printEven(),"EvenTread");
		//t1.start();
		//t2.start();
		executorService.shutdown();
	}

}
