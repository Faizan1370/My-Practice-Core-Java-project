package com.multitread.join;

public class ThreadJJoinEx {
	
	public static void print() {
		for(int i=0;i<10;i++) {
			try {
				System.out.println(Thread.currentThread().getName() +" :"+i);
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}
	
	public static void checkYieldMethod() {
		for(int i=0;i<10;i++) {
			
				System.out.println(Thread.currentThread().getName() +" :"+i);
				Thread.yield();
			
		}
	}
	
	//The yield() method temporarily pauses the execution of the current thread and allows other threads of the same priority to execute
	
	public static void main(String[] args) {
		Thread t1 = new Thread() {
			@Override
			public void run() {
				ThreadJJoinEx.print();
			}
			
		};
		
		Thread t2 = new Thread() {
			@Override
			public void run() {
				ThreadJJoinEx.print();
			}
			
		};
		t1.start();
		
		//try {
			//t1.join();  // Main thread waits until t1 finishes
		//} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		//}
		
		t2.start(); // Starts after t1 completes
	}
	
	//The join() method allows one thread to wait for the completion of another thread.
	//It is useful when you need to ensure that a thread finishes before continuing with the execution of the main thread

}
