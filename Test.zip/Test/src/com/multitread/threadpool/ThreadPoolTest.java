package com.multitread.threadpool;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ThreadPoolTest {
	
	public static void main(String[] args) {
		ExecutorService excutor = Executors.newFixedThreadPool(5);//creates 5 thread
		for(int i=0;i<10;i++) {
			Runnable workerThread = new WorkerThread(""+i);
			excutor.execute(workerThread);
		}
		excutor.shutdown();
		while(!excutor.isTerminated()) {}
		System.out.println("finished all threads");
	}

}
