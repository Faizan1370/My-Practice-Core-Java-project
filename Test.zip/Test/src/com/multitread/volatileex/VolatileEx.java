package com.multitread.volatileex;

public class VolatileEx {
	private volatile static boolean running = true;
	
	 public static void stopThread() {
	        running = false; // This change will be visible to the running thread
	    }
	
	public static void main(String[] args) {
		Thread t1= new Thread() {
			@Override
			public void run() {
				while (running) {
		            System.out.println("Thread is running...");
		            try {
		                Thread.sleep(500);
		            } catch (InterruptedException e) {
		                e.printStackTrace();
		            }
		        }
		        System.out.println("Thread stopped.");
				
			}
		};
		t1.start();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		VolatileEx.stopThread();
		//t1.stop();// this deprecated whihc will stop thread immidaity
		//t1.interrupt(); //this will throw and exceptioon(java.lang.InterruptedException: sleep interrupted) but should not stop thread excution
		
		
	}

}
