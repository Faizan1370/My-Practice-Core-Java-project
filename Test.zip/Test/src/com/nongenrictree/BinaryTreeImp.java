package com.nongenrictree;

import java.util.Stack;

public class BinaryTreeImp {
	
	private TreeNode root;
	
	public static void main(String[] args) {
		BinaryTreeImp binaryTreeImp=new BinaryTreeImp()
				;
		binaryTreeImp.createBinaryTree();
		binaryTreeImp.preOrder(binaryTreeImp.root);
		System.out.println();
		//binaryTreeImp.itrativePreorder();
		binaryTreeImp.recurciveInorder(binaryTreeImp.root);
		System.out.println();
		binaryTreeImp.iterativeIndorder();
		System.out.println();
		binaryTreeImp.recurcivePostorder(binaryTreeImp.root);
	}
	
	
	public void createBinaryTree() {
		TreeNode first= new TreeNode(3); //2 6 63 13 5
		TreeNode second= new TreeNode(6);
		TreeNode third= new TreeNode(5);
		TreeNode fourth= new TreeNode(63);
		TreeNode fifth= new TreeNode(13);
		
		root=first;
		first.left=second;
		first.right=third;
		second.left=fourth;
		second.right=fifth;
		
		
	}
	
	public void preOrder(TreeNode root) {
		if(root==null) {
			return;
		}
		
		System.out.print(root.data +" ");{
		preOrder(root.left);
		preOrder(root.right);
		}
	}
	
	public void itrativePreorder() {
		if(root==null) {
			return;
		}
		
		Stack<TreeNode> stack = new Stack<>();
		stack.push(root);
		
		while(!stack.isEmpty()) {
			TreeNode temp = stack.pop();
			System.out.print(temp.data +" ");
			if(temp.right!=null) {
				stack.push(temp.right);
			}
			
			if(temp.left !=null) {
				stack.push(temp.left);
			}
		}
	}
	
	public void recurciveInorder(TreeNode root) {
		if(root==null) {
			return;
		}
		recurciveInorder(root.left);
		System.out.print(root.data +" ");
		recurciveInorder(root.right);
		
	}
	
	public void iterativeIndorder() {
		if(root==null) {
			return;
		}
		Stack<TreeNode> stack = new Stack<>();
		TreeNode temp=root;
		 while(!stack.isEmpty() || temp!=null) {
			if(temp!=null) {
				stack.push(temp);
				temp=temp.left;
			}else {
				temp=stack.pop();
				System.out.print(temp.data +" ");
				temp=temp.right;
			}
		 

		 }
	}
	
	public void recurcivePostorder(TreeNode root) {
		if(root==null) {
			return;
		}
		recurcivePostorder(root.left);
		recurcivePostorder(root.right);
		System.out.print(root.data +" ");
		
	}
	

}
