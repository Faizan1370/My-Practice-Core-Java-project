package com.overriding.pract;

public class OverridingEx {
	
	public void displayName() {
		System.out.println("Hello Suhail in perent class");
	}
	
	public static void main(String[] args) {
		//Child ex = new GrandChild();
		//OverridingEx c = (OverridingEx)ex;
		//c.displayName();
		//Child c= (Child) new OverridingEx();
		//c.displayName();
		OverridingEx ex = new OverridingEx();
		Child c =(Child) ex;
		c.childProperty();
	}
	
	

}
class Child extends OverridingEx{
	
	@Override
	public void displayName() {
		System.out.println("Hello Suhail in child class");
	}
	
	public void childProperty() {
		System.out.println("Child personal property");
	}
	
}

class GrandChild extends Child{
	
	@Override
	public void displayName() {
		System.out.println("Hello Suhail in Grand class");
	}
	
	@Override
	public void childProperty() {
		System.out.println("Child personal property");
	}
	
	public void grandProperty() {
		System.out.println("Child Grand property");
	}
}

