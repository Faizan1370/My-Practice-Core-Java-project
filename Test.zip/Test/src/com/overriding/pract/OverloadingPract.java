package com.overriding.pract;

public class OverloadingPract {
	
	public static void sum(int a,int b) {
		System.out.println("Sum of number :"+(a+b));
	}
	
	public static void sum(int a, int b,int c) {
		System.out.println("Sum of number :"+(a+b+c));
	}
	public static String sum(int a, int b,int c,String str) {
		System.out.println("Sum of number :"+(a+b+c));
		return str;
	}
	
	public static void main(String[] args) {
		//OverloadingPract.sum(5, 3, 5);
		String sum = OverloadingPract.sum(6, 5, 8, "Suhail");
		System.out.println(sum);
	}

}
