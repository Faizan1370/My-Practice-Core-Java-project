package com.overriding;

public class Child extends Parent {
	//if the methods in the child class and parent same it will call the child class method wheater the refrence of Parent class.
	//if diffrent then will call parent class method.
	//parent class refrence will not call the child class method.
	//It's important to note that if there are any methods or fields in the Child class that are not present in the Parent class and you want to access them through p, you will need to perform a cast to the Child
	//if we throw the exception in the parent class and no need to throw the exception or you can throw but you need to handle the exception when we call that method() in the main method class.
	// if we call that method in the other method need to throws or handle the execption and if throws then that method needs to handle the excetion where we call the method.
	// It means wherever we call the method we need to throws or handle the exception.
	
	public void n() {
		System.out.println("Child class method n");
	}
	
	@Override
	public void m() {
		System.out.println("Child class method m");
	}
	
	

}
