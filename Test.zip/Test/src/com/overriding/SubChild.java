package com.overriding;

public class SubChild extends Child{
	
	public void m1() {
		System.out.println("Subchild class method m1");
	}
	@Override
	public void m() {
		System.out.println("Subchild class method m");
	}

}
