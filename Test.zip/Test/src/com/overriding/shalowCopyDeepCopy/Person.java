package com.overriding.shalowCopyDeepCopy;

public class Person {
	
	private String name;
	
	private Address address;
	
	public Person(String name,Address address) {
		this.name=name;
		//this.address=address; //shallow copy
		this.address= new Address(address.getCity()); //deep copy
	}
	
	public void display() {
		System.out.println(this.name +" "+this.address);
	}
	
	public static void main(String[] args) {
		Address address = new Address("KHLD");
		Person person = new Person("Faizan", address);
		
		Person person2 = new Person(person.name, person.address);
		
		System.out.println(person.address.getCity());
		System.out.println(person2.address.getCity());
		
		person2.address.setCity("Dl");
		
		System.out.println(person.address.getCity());
		System.out.println(person2.address.getCity());
		
	}

}
