package com.overriding;

public class Parent {
	
	public void m() throws InterruptedException {
		System.out.println("Parent class method");
		Thread.sleep(100);
	}
	
	public void newTest() throws InterruptedException {
		m();
		System.out.println("test method");
	}
	public static void main(String[] args) {
		Parent p=new Child();
		Parent parent = new Parent();
		//((SubChild) p).m1(); //this will work
		//((SubChild) parent).m1();  //this will  not work
		try {
			p.newTest();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Parent p1= new SubChild();
		SubChild ch= new SubChild();
		System.out.println(p1.getClass());
		((SubChild) p1).m1();
		ch.m1();
		Child c= new Child();
		c.m();
		try {
			p1.m();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		c.n();
	}

}
