package com.interviewqusetionPrac;

public class Base {
	
	public void display() {
		System.out.println("Base class");
	}
	public static void main(String[] args) {
		
		/*
		 * // named loop loop1: for (int i1 = 0; i1 < 5; i1++) { for (int j = 0; j < 5;
		 * j++) { if (i1 == 3) { break loop1; } System.out.println(i1 + " " + j); } }
		 */
		
		//Base b=new Child();// upcasting
		//b.display();
	  //Child c	=(Child)b;// downcasting
		//c.print();;
		//Base b = new Child();
		//SubChild sb=(SubChild)b; // this will not exceute throw casting error at run time becoz subchild and child are unrelated classess.
		//b.display();
		 //Base b1= b;
		 //b1.display();
		//Child sb=(Child)b;
		//sb.print();
		
		
		        
		
		
	}
	
}

class Child extends Base{
	
	public void display() {
		System.out.println("Child class");
	}
	 public void print() {
		 System.out.println("Child class print()");
	 }
}

class SubChild extends Child{
	public void display() {
	 System.out.println("Subchild class");	
	}
	
	public void m1() {
		System.out.println("m1");
	}
}
