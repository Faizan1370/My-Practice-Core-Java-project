package com.interviewqusetionPrac;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.Set;
import java.util.stream.Collectors;

public class Question2Prac {
	
	public static void main(String[] args) {
		String str="java";
		String str1="java";
		System.out.println("check :"+(str==str1)); // check : true
		System.out.println("check :"+str==str1); //false becoz + opration excute before == so it would be like
		//check :java == java
		//System.out.println(isPrime());
		System.out.println(checkVowel());
		int number=10;
		for(int i=0;i<number;i++) {
			System.out.print(fibonacci(i)+" ");
		}
	System.out.println();	
	System.out.println(checkListContainsOddNumber());	
	System.out.println(checkStringPalindrpome());
	System.out.println(checkStringPalindrpome1());
	removeWhiteSpaceString();
	removeWhiteSpaceString1();
	removeSpaceLeadTrail();
	sortArray();
	System.out.println(fatorial());
	System.out.println(fatorial1(5));
	reverseLinkedList();
	System.out.println(binarySearch());
	System.out.println(checkArrayWithSameElement());
	System.out.println(checkArrayWithSameElement1());
	sumArrray();
	secondLarget();
	shuffleArray();
	sortHashMap();
	checkCharaterOcuurence();
	removeOccurenceCharacter();
	pyramidCharacter();
	textBlock();
	multiLabelSwitch();
	multiLabelSwitchUsingLamda();
	output();
	output2();
	output3();
	output4();
	}
	
	public static boolean isPrime() {
		int input=15;
		if(input==0 || input==1) {
			return false;
		}
		if(input==2) {
			return true;
		}
		
		for(int i=2;i<=input/2;i++) {
			if(input%i==0) {
				return false;
			}
		}
		return true;
		
	}
	
	public static boolean checkVowel() {
		String str="ff";
		if(str.toLowerCase().matches(".*[aeiouf].*")) {
		//if(str.toLowerCase().contains("a") ||str.toLowerCase().contains("e")||str.toLowerCase().contains("i")||str.toLowerCase().contains("o")||str.toLowerCase().contains("u")) {
			return true;
		}else {
			return false;
		}
		
		
	}
	
	public static int fibonacci(int number) {
		if(number<=1) {
			return number;
		}
		return fibonacci(number-1)+fibonacci(number-2);
		
	}
	
	public static boolean checkListContainsOddNumber() {
		List<Integer> list = Arrays.asList(1,4,7,3,7,8);
		return list.parallelStream().anyMatch(n->n%2!=0);
	}
	
	public static boolean checkStringPalindrpome() {
		String str="madam";
		boolean result=true;
		for(int i=0;i<str.length()/2;i++) {
			if(str.charAt(i)!=str.charAt(str.length()-i-1)) {
			result= false;
			break;
			}
			
		}
		return result;
		
	}
	public static boolean checkStringPalindrpome1() {
		String str="madam";
		StringBuilder builder = new StringBuilder(str);
		if(builder.reverse().toString().equals(str)) {
			return true;
		}else {
			return false;
		}
		
	}
	
	public static void removeWhiteSpaceString() {
		String str="hello Buddy how are you";
		StringBuilder builder = new StringBuilder();
		String[] split = str.split(" ");
		for(int i=0;i<split.length;i++) {
			builder.append(split[i]);
		}
		System.out.println(builder.toString());
	}
	
	public static void removeWhiteSpaceString1() {
		String str="hello Buddy how are you";
		char[] chars=str.toCharArray();
		StringBuilder builder = new StringBuilder();
		for(int i=0;i<chars.length;i++) {
			if(!Character.isWhitespace(chars[i])) {
				builder.append(chars[i]);
			}
			
		}
		System.out.println(builder.toString());
	}
	
	public static void removeSpaceLeadTrail() {
		String str=" abc xy\t";
		 System.out.println(str.trim());
		 System.out.println(str.strip());//this is unicode standard but result same mostly
	}
	
	public static void sortArray() {
		int[] array= {2,-1,5,-10,3,78};
		int min=Integer.MAX_VALUE;
		int temp=0;
		int min_index=0;
		int k=0;
		for(int j=0;j<array.length;j++) {
		for(int i=j;i<array.length;i++) {
			if(array[i]<min) {
				min=array[i];
				min_index=i;
			}
		}
		temp=array[k];
		array[k]=array[min_index];
		array[min_index]=temp;
		k++;
		min=Integer.MAX_VALUE;
	}
		System.out.println(Arrays.toString(array));
	}
	
	public static int fatorial() {
		int number=5;
		int fact=1;
		for(int i=1;i<=number;i++) {
			fact=fact*i;
		}
		return fact;
	}
	public static int fatorial1(int number) {
		if(number ==1) {
			return 1;
		}
		return (number*fatorial1(number-1));
	}
	
	public static void reverseLinkedList() {
		LinkedList<Integer> list = new LinkedList<>();
		
		list.add(5);
		list.add(7);
		list.add(3);
		list.add(4);
		
		System.out.println(list);
		
		list.descendingIterator().forEachRemaining(num->System.out.print(num +" "));
		//if you want to show in list representation
		LinkedList<Integer> resultList = new LinkedList<>();
		//list.descendingIterator().forEachRemaining(resultList::add);
		//System.out.println(resultList);
		list.descendingIterator().forEachRemaining(num->{
			resultList.add(num);
		});
		System.out.println(resultList);
	}
	
	
	public static int binarySearch() {
		int[] array= {2,-1,5,-10,3,78};
		int high=array.length;
		int low=0;
		int key=-80;
		int mid=(high+low)/2;
		while(low<=high) {
			if(array[mid]>key) {
				high=mid-1;
			}else if(array[mid]==key) {
				return array[mid];
			}else{
				low=mid+1;
			}
		   mid=(high+low)/2;
		}
		if(low>high) {
			return -1;
		}
		return mid;
	}
	
	public static boolean checkArrayWithSameElement() {
		Integer[] array= {1,2,3,2,1};
		Integer[] array1= {1,2,3};
		Integer[] array2= {1,2,3,4};
		
		Set<Object> unique1= new HashSet<>(Arrays.asList(array));
		Set<Object> unique2= new HashSet<>(Arrays.asList(array1));
		if(unique1.size()!=unique2.size()) {
			System.out.println("FDF");
			return false;
		}
		for(Object obj:unique1) {
			if(!unique2.contains(obj)) {
				System.out.println("sfsdg");
				return false;
			}
		}
		return true;
		
	}
	
	
	public static boolean checkArrayWithSameElement1() {
		int[] array= {1,2,3,2,1};
		int[] array1= {1,2,3};
		int[] array2= {1,2,3,4};
		
		Set<Integer> unique1= new HashSet<>();
		Set<Integer> unique2= new HashSet<>();
		for(int a:array) {
			unique1.add(a);
		}
		for(int a:array1) {
			unique2.add(a);
		}
		if(unique1.size()!=unique2.size()) {
			System.out.println("FDF");
			return false;
		}
		for(Object obj:unique1) {
			if(!unique2.contains(obj)) {
				System.out.println("sfsdg");
				return false;
			}
		}
		return true;
		
	}
	
	public static void sumArrray() {
		int[] array= {2,-1,5,-2,3,6};
		int sum=0;
		for(int a:array) {
			sum +=a;
		}
		System.out.println(sum);
		
	}
	
	public static void secondLarget() {
		int[] array= {2,-1,5,-2,3,6,7};
		int largest=Integer.MIN_VALUE;
		int secondLarget=0;
		for(int element:array) {
			if(element>largest) {
				secondLarget=largest;
				largest=element;
			}else if(element>secondLarget) {
				secondLarget=element;
			}
		}
		System.out.println(secondLarget);
	}
	
	public static void shuffleArray() {
		//Integer[] array= {2,-1,5,-2,3,6};
		
		//Collections.shuffle(Arrays.asList(array));
		//System.out.println(Arrays.toString(array));
		int[] array= {2,-1,5,-2,3,6};
		
		Random random = new Random();
		
		for(int i=0;i<array.length;i++) {
			int swapIndex = random.nextInt(array.length);
			int temp = array[swapIndex];
			array[swapIndex]=array[i];
			array[i]=temp;
		}
		System.out.println(Arrays.toString(array));
	}
	
	public static void sortHashMap() {
		Map<String,Integer> map = new HashMap<>();
		map.put("Azlan", 12);
		map.put("Arish", 56);
		map.put("Aqsa",45);
		map.put("Azqa",98);
		map.put("Aman",89);
		
		List<Entry<String, Integer>> list = new ArrayList<>(map.entrySet());
		//Collections.sort(list,(o1,o2)->o1.getKey().compareTo(o2.getKey())); 
		list.sort((o1,o2)->o1.getKey().compareTo(o2.getKey()));
		
		list.stream().forEach(obj->System.out.println(obj));
	}
	
	public static void checkCharaterOcuurence() {
		String str="faizan";
		Map<Character, Integer> map = new HashMap<>();
		
		for(int i=0;i<str.length();i++) {
			if(map.containsKey(str.charAt(i))) {
				map.put(str.charAt(i), map.get(str.charAt(i))+1);
			}else {
				map.put(str.charAt(i), 1);
			}
		}
		map.entrySet().stream().forEach(obj->System.out.println(obj));
		map.forEach((k,v)->System.out.println(k +" "+v));
	}
	
	public static void removeOccurenceCharacter() {
		String str="mumbai";
		str = str.replace("u","");
		System.out.println(str);
	}
	
	public static void pyramidCharacter() {
		int n=4;
		for(int i=0;i<n;i++) {
			for(int j=3;j>=i;j--) {
				System.out.print(" ");
			}
			for(int k=0;k<2*i+1;k++) {
			 System.out.print("*");
			}
			
			System.out.println();
		}
	}
	
	
	public static void textBlock() {
		String textBlock="""
				Hi
				Hello
				yes
				""";
		System.out.println(textBlock);
	}
	
	public static void multiLabelSwitch() {
		int choice=2;
		
		int x=switch(choice) {
		case 1,2,3:
			yield choice;
		default:
			yield -1;
		};
		System.out.println("x :"+x);
	}
	
	public static void multiLabelSwitchUsingLamda() {
		
		String day="TH";
		String result=switch (day) {
		case "M","W","F"->"MWF";
		case "T","TH","S"->"TTS";
		default->{
			System.out.println("not found");
			yield "Unknown";
		}
		};
		System.out.println("Result :"+result);
	}
	
	public static void output() {
		String s3 = "journalDev";
		int start = 0;
		char end = 5;

		System.out.println(s3.substring(start, end));
	}
	
	public static void output2() {
		HashSet shortset = new HashSet<>();
		for(short i=0;i<100;i++) {
			shortset.add(i);
			shortset.remove(i-1);
		}
		System.out.println(shortset.size()); //will not remove any data becoz it is short so it will convert into Short Wrapper after adding in set/
		//if it is int will show 1 we can subtract from int.
	}
	
	public static void output3() {
		try {
			if(false) {
				while(true) {
					
				}
			}else {
				//System.exit(1);
			}
		}finally {
			System.out.println("finally"); //output will infinit loop but if if condition is false will be like exit from the program
		}
		//here finally block will not execute
		//if we make false then rest of the code or methods will not execute
	}
	
	public static void output4(){
		String str = "";
		String str1="abc";

		System.out.println(str1.equals("abc") | str.equals(null));
		// this will throw null pointter becoz checking from null string means str is null
		//but str is not null then it will check str value is null or not
		
		
	}

}
