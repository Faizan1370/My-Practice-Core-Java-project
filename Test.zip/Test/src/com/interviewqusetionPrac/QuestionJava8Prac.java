package com.interviewqusetionPrac;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class QuestionJava8Prac {
	
	public static void main(String[] args) {
		findAllEvenNumber();
		findNumberStartsFrom1();
		findDuplicateElements();
		findFirstElement();
		findNumberOfElements();
		findMaxElement();
		sortElement();
		sortElementDecending();
		returnTrueFalseArrayContainsDuplicate();
		showCurrentDateTimeJava8();
		concatTwoStream();
		cubeElemeneGreaterThan50();
		sortElementConvertStream();
		convertElementsToUppercase();
		countWordsInArray();
		onlyDuplicateElementsCount();
		maxElementInArray();
		characterCountInString();
	}
	
	public static void findAllEvenNumber() {
		List<Integer> list = Arrays.asList(2,6,7,1,9,0,7);
		list.stream().filter(num ->num%2==0).forEach(e->System.out.println(e));
	}
	
	public static void findNumberStartsFrom1() {
		List<Integer> list = Arrays.asList(12,6,7,1,9,0,17);
		list.stream().map(num->num+"").filter(s->s.startsWith("1")).forEach(str->System.out.println(str));
	}
	
	public static void findDuplicateElements() {
		List<Integer> list = Arrays.asList(2,6,7,1,9,0,7);
		HashSet<Integer> set= new HashSet<>();
		list.stream().filter(num->!set.add(num)).forEach(e->System.out.println(e));
	}
	
	public static void findFirstElement() {
		List<Integer> list = Arrays.asList(2,6,7,1,9,0,7);
		list.stream().findFirst().ifPresent(e->System.out.println(e));
	}
	
	public static void findNumberOfElements() {
		List<Integer> list = Arrays.asList(2,6,7,1,9,0,7);
		System.out.println(list.stream().count());
	}
	
	public static void findMaxElement() {
		List<Integer> list = Arrays.asList(2,6,7,1,9,0,7);
		System.out.println(list.stream().max(Integer::compare).get());
	}
	
	public static void sortElement() {
		List<Integer> list = Arrays.asList(2,6,7,1,9,0,7);
		list.stream().sorted().forEach(e->System.out.print(e +" "));
	}
	public static void sortElementDecending() {
		List<Integer> list = Arrays.asList(2,6,7,1,9,0,7);
		list.stream().sorted(Collections.reverseOrder()).forEach(e->System.out.print(e+" "));
	}
	
	public static void returnTrueFalseArrayContainsDuplicate() {
		List<Integer> list = Arrays.asList(2,6,7,1,9,0);
		
		HashSet<Integer> set = new HashSet<>(list);
		if(list.size()==set.size()) {
			System.out.println("true");
		}else {
			System.out.println("false");
		}
	}
	
	public static void showCurrentDateTimeJava8() {
		System.out.println(java.time.LocalDate.now());
		System.out.println(java.time.LocalTime.now());
		System.out.println(java.time.LocalDateTime.now());
	}
	
	public static void concatTwoStream() {
		List<Integer> list = Arrays.asList(2,6,7,1,9,0);
		List<Integer> list1 = Arrays.asList(2,6,7,1,9,0);
		Stream<Integer> concat = Stream.concat(list.stream(), list1.stream());
		concat.forEach(s->System.out.print(s+" "));
		
	}
	
	public static void cubeElemeneGreaterThan50() {
		List<Integer> list = Arrays.asList(2,6,7,1,9,0);
		
		list.stream().map(n->n*n*n).filter(i->i>50).forEach(n->System.out.println(n));
	}
	
	public static void sortElementConvertStream() {
		List<Integer> list = Arrays.asList(2,6,7,1,9,0,7);
		list.stream().sorted().collect(Collectors.toList()).stream().forEach(e->System.out.print(e+" "));
	}
	
	public static void convertElementsToUppercase() {
		List<String> list = Arrays.asList("arish","faizan");
		list.stream().map(str->str.toUpperCase()).forEach(str->System.out.println(str+" "));
	}
	
	public static void countWordsInArray() {
		List<String> list = Arrays.asList("arish","faizan");
		Map<String, Long> collect = list.stream().collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
		collect.entrySet().stream().forEach(obj->System.out.println(obj));
	}
	
	public static void onlyDuplicateElementsCount() {
		List<String> list = Arrays.asList("aa","aa","cc","cc","bbb","aaa");
		Map<String, Long> collect = list.stream().filter(x->Collections.frequency(list, x)>1).collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
		collect.forEach((k,v)->System.out.println(k+" "+v));
	}
	
	/*
	 * public static void checkListEmptyIfNotNUllIterate() { List<String> list =
	 * Arrays.asList("arish","faizan");
	 * Optional.ofNullable(list).orElseGet(Collections::emptyList).stream().filter(
	 * Objects::nonNull).map(note->Notes::getTagName).forEach(System.out::println);
	 * }
	 */
	
	public static void maxElementInArray() {
		int[] array= {3,5,7,1,4,9,90};
		
		System.out.println(Arrays.stream(array).max().getAsInt());
	}
	
	public static void characterCountInString() {
		String str="faizan";
		Map<String, Long> collect = Arrays.stream(str.split("")).map(c->c.toLowerCase()).collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
		System.out.println(collect);
	}

}
