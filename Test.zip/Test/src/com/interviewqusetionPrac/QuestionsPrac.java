package com.interviewqusetionPrac;

import java.util.Arrays;

public class QuestionsPrac {
	
	
	
	
	public void print(Float i) {
		System.out.println("Float");
	}
	
	public void print(float i) {
		System.out.println("float");
	}
	public void print(Character i) {
		System.out.println("Charater");
	}
	
	public void print(char i) {
		System.out.println("char");
	}
	
	public void print(Short i) {
		System.out.println("Short");
	}
	
	public void print(short i ) {
		System.out.println("Byte");
	}
	
	public void print(byte i) {
		System.out.println("byte");
	}

	public void print(Byte i) {
		System.out.println("Byte");
	}
	  public void print(int i) {
		  System.out.println("int");
	 } 
	  public void print(long i) { 
		  System.out.println("long"); 
  }
	 
	  public void print(Integer i) {
			System.out.println("Integer");
	}
	  
	public void print(Long i) {
		System.out.println("Long");
	}
	public void print(Double i) {
		System.out.println("Double");
	}
	
	public void print(double i) {
		System.out.println("double");
	}
	
	public static void test() {
		try
		{
		 System.out.println("try catch");
		 double d = 4/0;
		 System.out.println(d);
		 return;
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			System.out.println("finally");
		}
	}
	
	public static void main(String[] args) {
	// String str="faizan";
	 //char[] ch=str.toCharArray();
	  //char c=ch[0];
		
		new QuestionsPrac().print((char)10.00);
		
		//test();
		
		//char[] chars = new char[] {'\u0097'};
		//String str2 = new String(chars);
		//byte[] bytes = str2.getBytes(); 
		//System.out.println(Arrays.toString(bytes));
		
		

		
		
		/*
		 * String s1="hello"; String s2= new String("hello"); s2=s1.intern();
		 * System.out.println(s1==s2);
		 * 
		 * String str="5"; System.out.println(1+6+str+7);
		 */
	}
	
	

}
