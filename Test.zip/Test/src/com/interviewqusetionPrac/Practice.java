package com.interviewqusetionPrac;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map.Entry;

public class Practice {

	public static void main(String[] args) {
		checkAnagram();
	}
	
	public static boolean test() {
		String str="azd";
		//if(str.toLowerCase().matches(".*[aeiou].*")) {
			if(str.toLowerCase().contains("a") || str.toLowerCase().contains("e") ||str.toLowerCase().contains("i") ||str.toLowerCase().contains("o") || str.toLowerCase().contains("u")) {
			return true;
			
		}
		return false;
		
	}
	
	public static List<Integer> odd(){
		List<Integer> list = Arrays.asList(1,4,7,3,7,8);
		List<Integer> newList= new ArrayList<>();
		for(Integer num :list) {
			if(num%2!=0) {
				newList.add(num);
			}
		}
		return newList;
	}
	
	public static void removeWhiteSpace() {
		String str="My name is Faizan";
		char[] charArray = str.toCharArray();
		StringBuilder builder= new StringBuilder();
		for(int i=0;i<charArray.length;i++) {
			if(!Character.isWhitespace(charArray[i])) {
				builder.append(charArray[i]);
			}
		}
		System.out.println(builder.toString());
		
	}
	public static void removeWhiteSpace1() {
		String str="My name is Faizan";
		StringBuilder builder = new StringBuilder();
		String[] split = str.split(" ");
		for(int i=0;i<split.length;i++) {
			builder.append(split[i]);
		}
		System.out.println(builder.toString());
	}
	
	public static void removeSpaceLeadTrail() {
		String str=" abc xy\t";
		System.out.println(str.trim());
		System.out.println(str.strip());
	}
	
	public static void fact() {
		int num=5;
		int fact=1;
		for(int i=1;i<=num;i++) {
			fact=fact*i;
		}
		System.out.println(fact);
	}
	
	public static void checkCharaterOcc() {
		String str="abca";
		HashMap<Character, Integer> map=new HashMap<>();
		for(int i=0;i<str.length();i++) {
			if(map.containsKey(str.charAt(i))) {
				map.put(str.charAt(i), map.get(str.charAt(i))+1);
			}else {
				map.put(str.charAt(i), 1);
			}
		}
		for(Entry<Character, Integer> obj :map.entrySet()) {
			System.out.println(obj.getKey() + " "+obj.getValue());
		}
	}
	
	public static void textBlock() {
		String textBlock="""
				Hi
				Hello
				yes
				""";
		System.out.println(textBlock);
	}
	
	public static void multilableSwitch() {
		int choice=2;
		int x=switch (choice) {
		case 1,2,3: {
			
			yield choice;
		}
		default:
			yield -1;
		};
		System.out.println("x :"+x);	}
	
	public static void output() {
		String s3 = "journalDev";
		int start = 1;
		char end = 5;

		System.out.println(s3.substring(start, end));
	}
	public static void shortTypeSetTest() {
		HashSet set= new HashSet<>();
		for(short i=0;i<10;i++) {
			set.add(i);
			set.remove(i-1);
		}
		System.out.println(set.size());
	}
	
	public static void countCharDigitSpace() {
		String str="Helo @ buddy ' 6";
		int digits=0,space=0,specialChar=0,characters=0;
		char[] charArray = str.toCharArray();
		for(int i=0;i<charArray.length;i++) {
			if(Character.isDigit(str.charAt(i))) {
				digits++;
			}else if(Character.isSpace(str.charAt(i))) {
				space++;
			}else if(Character.isLetter(str.charAt(i))) {
				characters++;
			}else {
				specialChar++;
			}
		}
		System.out.println(digits +" "+space+" "+specialChar+" "+characters);
	}
	
	public static void checkAnagram() {
		String str="faizan";
		String str1="naziaf";
		char[] charArray = str.toCharArray();
		char[] charArray2 = str1.toCharArray();
		boolean isAnagram=false;
		Arrays.sort(charArray);
		Arrays.sort(charArray2);
		if(str.length()!=str1.length()) {
			isAnagram=false;
		}
		for(int i=0;i<charArray.length;i++) {
			if(charArray[i]==charArray2[i]) {
				isAnagram=true;
				
			}else {
				isAnagram=false;
				break;
			}
		}
		
		System.out.println(isAnagram);
	}

}
