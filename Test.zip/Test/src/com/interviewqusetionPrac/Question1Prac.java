package com.interviewqusetionPrac;

public class Question1Prac {
	
	static int  i =4;
	
	 static
	    {
	        i = i-- - --i;
	        System.out.println("static1 :"+i);
	    }
	 
	    {
	        i = i++ + ++i;
	        System.out.println("normal 1 :"+i);
	    }
	    
	    
	    
	    public static void main(String[] args) {
			new Question1Prac(); // when it creates default block will excecute otherwise will not
		}
	    
}

class Question1PracChild extends Question1Prac{
	 static
	    {
	        i = --i - i--;
	        System.out.println("static2 :"+i);
	    }
	 
	    {
	        i = ++i + i++;
	        System.out.println("normal2 :"+i);
	    }
	   
}


