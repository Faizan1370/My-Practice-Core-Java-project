package com.interviewqusetionPrac;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import test.Employee;

public class QuestionPrac {
	private static int $; // we put return type string,double,long etc.
	static String computerMove; 
	static int y=7;  
	static  
	{  
	y=++y - y++ -y++;
	System.out.println("static :"+y);
	}  
	 
	
	 public void print(Integer i) {
	        System.out.println("Integer");
	    }

	    public void print(int i) {
	        System.out.println("int");
	    }

	    public void print(long i) {
	        System.out.println("long");
	    }
	    
	    
	    public static void foo(Integer i) {
	        System.out.println("foo(Integer)");
	    }

	    public static void foo(short i) {
	        System.out.println("foo(short)");
	    }

	    public static void foo(long i) {
	        System.out.println("foo(long)");
	    }

	    public static void foo(int... i) {
	        System.out.println("foo(int ...)");
	    }
	
	
	public static void main(String[] args) {
		{  
			y=y++ + ++y; 
			System.out.println("normal :"+y);
			} 
		//\u000d System.out.println("Hello");
		int i=20+ +9- -12+ +4- -13+ +19; 
		System.out.println(i);
		
		
		String s1 = "Java";  
		String s2 = "Java";  
		StringBuilder sb1 = new StringBuilder(); 
		StringBuffer sf= new StringBuffer();
		sf.append("Ja").append("va");
		String str= new String("Java");
		sb1.append("Ja").append("va"); 
		System.out.println("sb af ******:"+(sb1.toString()==sf.toString()));
		System.out.println("555");
		System.out.println(sb1.hashCode() +" "+str.hashCode());
		System.out.println("*"+sb1.equals(str));
		System.out.println(s1 == s2);  
		System.out.println(s1.equals(s2));  
		System.out.println(sb1.toString() == s1);  
		System.out.println(s1.equals(sb1.toString())); 
		System.out.println("***************");
		Employee emp = new Employee("Java");
		System.out.println(s1.equals(emp.getName())); 
		System.out.println(s1==emp.toString());
		
		
			System.out.print("a");  
			try   
			{  
			System.out.print("b");  
			throw new IllegalArgumentException();  // abcde with throw without throw will be abde
			}   
			catch (RuntimeException e)   
			{  
			System.out.print("c");  
			}   
			finally   
			{  
			System.out.print("d");  
			}  
			System.out.print("e");  
			
			String a_b = null;  
			System.out.println($);  
			System.out.println(a_b); 
			
			int[] array = {6,9,8};  
			List<Integer> list = new ArrayList<>();  
			list.add(array[0]);  
			list.add(array[2]);  
			list.set(1, array[1]);  
			list.remove(0);  
			System.out.println(list);  
			
			
			char[] ca ={0x4e, '\u004e', 78};  //without single qoute compile time error
			System.out.println((ca[0] == ca[1]) + " "+ (ca[0] == ca[2]));  
			
			int x=20;
			switch(x)    
			{    
			case 20:    // x>20 error
			System.out.println("True");    
			break;    
			case 2:    
			System.out.println("False");    
			break;    
			} 
			
			String st="ONE"+1+2+"TWO"+"THREE"+3+4+"FOUR"+"FIVE"+5;  
			System.out.println(st);
			
			System.out.println(Math.min(Double.MIN_VALUE, 0.000d));
			
			long longWithL = 1000*60*60*24*365L;  
			double longWithoutL = 1000*60*60*24*365;  
			
			System.out.println(longWithL +" "+longWithoutL);
			
			System.out.println(" **"+y);
			
			int z=9;
			
			
			int k=--z -z- z--;
			k=z;
			System.out.println(z);
			System.out.println("Z :"+k);
			
			
			
			//String computerMove =null;  
			switch ( (int)(3*Math.random()) )   
			{  
			case 0:  
			computerMove = "Rock";  
			break;  
			case 1:  
			computerMove = "Scissors";  
			break;  
			case 2:  
			computerMove = "Paper";  
			break;  
			}  
			System.out.println("Computer's move is " + computerMove);  
			
			
			  HashMap<String,String> map = new HashMap<String,String>(){  
			        {  
			            put("1", "ONE");  
			        }{  
			            put("2", "TWO");  
			        }{  
			            put("3", "THREE");  
			        }
			        {  
			            put("4", "THREE");  
			        }
			        };  
			        Set<String> keySet = map.keySet();  
			        for (String string : keySet) {  
			            System.out.println(string+" ->"+map.get(string));  
			        } 
			        
			        map.entrySet().stream().forEach(obj->System.out.println(obj.getKey() + " "+obj.getValue()));
			        
			        //for(;;) { // infinite loop
			        	//for(;true;) { // infinite loop
			        //for(;false;) { compile time error or syntax error
			        //for(;2==2;) { // infinite loop
			        //for(int i1=1;i1>=1;i1++) { // infinite loop
			        	//System.out.println("hello");
			       // }
			        
			        String str3="Java|Python|Hadoop";  
			        String[] ar = str3.split("\\|");  
			        System.out.println(Arrays.toString(ar)); 
			        
			       // Object t[] = new String[3];  
			        // t[0] = new Integer(0);  //ArrayStoreException
			         
			         QuestionPrac prac = new QuestionPrac();
			         System.out.println("new conetent question");
			         prac.print((Integer)10);
			         
			         String s6 = "hello";
			         String s7 = new String("hello");

			         s7 = s7.intern();
			         System.out.println(s6 == s7);
			         
			         foo(10,7,8);
			         
			        
			
			

	}

}
