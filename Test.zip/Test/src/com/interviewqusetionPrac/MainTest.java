package com.interviewqusetionPrac;

public class MainTest {
	
	 void methodOfA(int a)
	    {
		 System.out.println("sdg");
	        
	    }
	
	public static void main(String[] args) {
		
		 
		Integer s = new Integer("667");
		//String str=null;
		//String g = new String(str);
        
		Integer i1 = 127;
		 
        Integer i2 = 127;
 
        System.out.println(i1 == i2);
 
        Integer i3 = 128;
 
        Integer i4 = 128;
 
        System.out.println(i3 == i4);
		
	}

	//In Java, the Integer class maintains a cache of integer objects for values in the range -128 to 127
	//Both i1 and i2 are assigned the value 127. Due to integer caching, they reference the same object in memory. Therefore, i1 == i2 evaluates to true
}
