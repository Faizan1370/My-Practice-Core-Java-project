package com.solid.principle.lsp;

public interface GroupCallManager {
	
	void groupVideoCall();

}
