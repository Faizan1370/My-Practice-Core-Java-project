package com.solid.principle.lsp;

public class Instagram  implements SocailMediaConnectivity,PublishPostManager{

	@Override
	public void publishPost() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void chatWithFriend() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void sendPhotosVideo() {
		// TODO Auto-generated method stub
		
	}

}
