package com.solid.principle.lsp;

public interface PublishPostManager {
	
	void publishPost();

}
