package com.solid.principle.lsp;

public abstract class SocialMedia {
	
	public abstract void chatWithFried();
	public abstract void publishPost();
	public abstract void sendPhotosVideo();
	public abstract void groupVideoCall();
	
	//if we create facebook class and extends this class and all these features supported by Facebook so called substitue of this class.
	// if we create watspp class and extends with tis class then watsapp does not support the publish post so it is not substitue fo this class.we can use as empty metod but that is not good practice.
	// same way for instagram ,does not support groupVideo call.

	

}
