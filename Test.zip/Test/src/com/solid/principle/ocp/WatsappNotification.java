package com.solid.principle.ocp;

public class WatsappNotification implements SendNotification {

	@Override
	public void sendOtp(String medium) {
		// using watssap
		
	}

	@Override
	public void sendTransactionReport(String medium) {
		// using watssapp
		
	}

}
