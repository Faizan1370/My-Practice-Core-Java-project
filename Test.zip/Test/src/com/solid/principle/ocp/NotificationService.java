package com.solid.principle.ocp;

public class NotificationService {
	
	public void sendOtp(String medium) {
		if(medium.equals("Mobile")) {
			
		}
		if(medium.equals("Email")) {
			
		}
	}
	
	//here if we want to add watsapp notification service need to change the implemention 
	// it is also same as Stratgy desing pattern

}
