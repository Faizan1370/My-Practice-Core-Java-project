package com.solid.principle.ocp;

public interface SendNotification {
	
	public void sendOtp( String medium);
	
	public void sendTransactionReport(String medium);
	

}
