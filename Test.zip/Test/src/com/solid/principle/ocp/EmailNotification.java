package com.solid.principle.ocp;

public class EmailNotification  implements SendNotification{

	@Override
	public void sendOtp(String medium) {
		// using email
		
	}

	@Override
	public void sendTransactionReport(String medium) {
		// using email
		
	}

}
