package com.solid.principle.srp;

public class LoanService {
	
	public void personalLoan() {
		
	}
	
	public void HomeLoan() {
		
	}

}
