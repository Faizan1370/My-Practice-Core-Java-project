package com.solid.principle.srp;

public class OtpService {
	
	public void sendOtpWatapp() {
		
	}
	
	public void sendOtpEmail() {
		
	}

}
