package com.solid.principle.srp;

public class BankService {
	
	public void printPassBook() {
		System.out.println("Printing passbook");
	}
	
	public void getLoan(String type) {
		if(type.equals("Personale")) {
			System.out.println("Personal loan");
		}else if(type.equals("Home Loan")) {
			System.out.println("Home loan");
		}
	}
	
	public void sendOtp(String type) {
		if(type.equals("watsaap")) {
			
		}else if(type.equals("email")) {
			
		}
	}
	
	//Now if we want to add more loan type or more otp service then need to modify the implementaion code now we can create seprate class for all the service
	//It is same like factory pattern one class is responsible for one task like iphone is responsible for iphone related functionality

}
