package com.solid.principle.dip;

public class CreditCard implements BankCard{

	@Override
	public void doTransaction() {
		System.out.println("Using Credit card");
		
	}

}
