package com.solid.principle.dip;

public interface BankCard {

	
	void doTransaction();
}
