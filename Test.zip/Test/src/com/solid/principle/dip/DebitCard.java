package com.solid.principle.dip;

public class DebitCard implements BankCard{

	@Override
	public void doTransaction() {
		System.out.println("Deabit Card");
		
	}

}
