package com.solid.principle.dip;

public class ShoppingMall {
	
	private BankCard bankCard;
	
	public ShoppingMall(BankCard bankCard) {
		this.bankCard=bankCard;
	}
	
	public void purchaseSomething(double amount) {
		bankCard.doTransaction();
	}
	
	public static void main(String[] args) {
		BankCard bankCard = new DebitCard();
	    ShoppingMall mall = new ShoppingMall(bankCard);
	    mall.purchaseSomething(0);
	}

}
