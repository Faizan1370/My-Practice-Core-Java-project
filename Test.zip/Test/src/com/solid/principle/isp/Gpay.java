package com.solid.principle.isp;

public class Gpay implements UPIPayments,CashBackManager {

	@Override
	public void getCashBack() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void payMoney() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getScracthCard() {
		// TODO Auto-generated method stub
		
	}

}
