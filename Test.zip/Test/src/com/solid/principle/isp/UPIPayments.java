package com.solid.principle.isp;

public interface UPIPayments {
	  void payMoney();
	  void getScracthCard();
	  //void getCashBack();
	  
	  // lets support have classes like Gpay,phonePay ,paytm.
	  //Gpay support all features
	  //paytm does not support getCashBack
	  //phonepe does not support getCashBack

}
