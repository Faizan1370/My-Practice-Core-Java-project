package com.solid.principle.isp;

public class Paytm implements UPIPayments{

	@Override
	public void payMoney() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getScracthCard() {
		// TODO Auto-generated method stub
		
	}

}
