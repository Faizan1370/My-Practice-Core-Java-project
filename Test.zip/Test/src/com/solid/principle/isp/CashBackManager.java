package com.solid.principle.isp;

public interface CashBackManager {
	
	void getCashBack();

}
