package com.collection.concurrentsynchro;

import java.util.Map;

public class MyHelper2 implements Runnable {
    Map<String,Integer> map;
    
    public MyHelper2( Map<String,Integer> map) {
    	this.map=map;
    	new Thread(this,"MyHelper2").start();
	}
	
	@Override
	public void run() {
		map.put("Two", 2);
		try {
			System.out.println("MapHelper2 sleeping");
			Thread.sleep(100);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	

}
