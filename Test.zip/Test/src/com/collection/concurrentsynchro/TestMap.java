package com.collection.concurrentsynchro;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class TestMap {
	public static void main(String[] args) {
		HashMap<String, Integer> map= new HashMap<>();
		//here we will get error because synchronizedMap lock the whole map refrence so thread1 try to put value then thread two so it can not due to the map object ref locked
		// We can use the concurrent hashmap to fix this issue because it locks the segment of map or array of segment or bucket of segment.
		//Map<String, Integer> synchronizedMap = Collections.synchronizedMap(map);
		ConcurrentHashMap<String, Integer> concurrentHashMap = new ConcurrentHashMap<>();
		
		MyHelper1 helper1= new MyHelper1(concurrentHashMap);
		MyHelper2 helper2= new MyHelper2(concurrentHashMap);
		MyHelper3 helper3= new MyHelper3(concurrentHashMap);
		
		for(Map.Entry<String, Integer> e:concurrentHashMap.entrySet()) {
			System.out.println(e.getKey() +" "+e.getValue());
		}
	}

}
