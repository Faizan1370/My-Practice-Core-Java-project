package com.collection.concurrentsynchro;

import java.util.Map;

public class MyHelper1 implements Runnable{
	Map<String,Integer> map;
	
	public MyHelper1(Map<String,Integer> map) {
		this.map= map;
		new Thread(this,"MyHelper").start();
	}

	@Override
	public void run() {
		map.put("One", 1);
		try {
			System.out.println("MapHelper1 sleeping");
			Thread.sleep(100);
		} catch (Exception e) {
			System.out.println(e);
		}
		
	}

}
