package com.collection.util;

import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map.Entry;

public class SortHashMap {
	
	public static void sortHashMap() {
		HashMap<Integer, String> hashMap= new HashMap<>();
		hashMap.put(100, "faizan");
		hashMap.put(200, "arun");
		hashMap.put(76, "aksh");
		hashMap.put(76, "Jeet");
		
		int[] array=new int[hashMap.size()];
		int inr=0;
		for(Entry<Integer, String> m:hashMap.entrySet()) {
			array[inr]=m.getKey();
			inr++;
			
		}
		
		Arrays.sort(array);
		System.out.println(Arrays.toString(array));
		LinkedHashMap<Integer, String> resHashMap = new LinkedHashMap<>();
		for(int i=0;i<array.length;i++) {
			//System.out.println(array[i] +" "+hashMap.get(array[i]));
			resHashMap.put(array[i], hashMap.get(array[i]));
		}
		
		for(Entry<Integer,String> m :resHashMap.entrySet()) {
			System.out.println(m.getKey()+" "+m.getValue());
		}
		
		
	}
	
	public static void main(String[] args) {
		new SortHashMap().sortHashMap();
	}

}
