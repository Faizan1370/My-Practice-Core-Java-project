package com.stack;

import java.util.Arrays;
import java.util.EmptyStackException;
import java.util.Stack;

public class StackImpl {
	
	private ListNode top;
	private int length;
	
	
	public static void main(String[] args) {
		//ListNode first=new ListNode(3);
		StackImpl impl= new StackImpl();
		impl.push(3);
		impl.push(8);
		impl.push(33);
		impl.push(18);
		impl.push(34);
		impl.push(58);
		impl.pop();
		impl.pop();
		impl.pop();
		impl.display();
		System.out.println(impl.peek());
		
		System.out.println(impl.reverseStringByStack());
		
		int arr[] = {1,6,4,8,3,7,2};
		
		int[] nextGreaterElementByStack = impl.nextGreaterElementByStack(arr);
		System.out.println(Arrays.toString(nextGreaterElementByStack));
		
		//System.out.println(impl.length);
	}
	
	public void push(int data) {
		ListNode temp=new ListNode(data);
		temp.next=top;
		top=temp;
		length++;
	}
	
	public void pop() {
		if(length==0) {
			return;
		}
		//ListNode current=top;
		//current.next=top;
		//current=null;
		top=top.next;
		length--;
		
	}
	
	public int peek() {
		if(top== null) {
			throw new EmptyStackException();
		}
		return top.data;
	}
	
	public void display() {
		if(top == null) {
			return;
		}
		ListNode current = top;
		while(current!=null) {
			
			System.out.print(current.data +" ");
			current = current.next;
			
		}
	}
	
	public String reverseStringByStack() {
		String str="abcd";
		Stack<Character> stack = new Stack<>();
		char[] charArray = str.toCharArray();
		for(int i=0;i<charArray.length;i++) {
			stack.push(charArray[i]);
		}
		
		for(int i=0;i<charArray.length;i++) {
			charArray[i]=stack.pop();
		}
		return new String(charArray);
	}
	
	public int[] nextGreaterElementByStack(int arr[]) {
		int ar[] = new int[arr.length];
		Stack<Integer> stack = new Stack<>();
		for(int i=arr.length-1;i>=0;i--) {
			if(!stack.isEmpty()) {
				while(!stack.isEmpty() && stack.peek()<=arr[i]) {
					stack.pop();
				}
			}
			if(stack.isEmpty()) {
				ar[i]=-1;
				
			}else {
				ar[i]=stack.peek();
			}
			stack.push(arr[i]);
		}
		return ar;
	}

}
