package com.string;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map.Entry;


public class StringPrac {
	
	public static void main(String[] args) {
		//countChar1();
		//sortStringArray();
		//countCharWhite();
		checkAnagaram();
	}
	
	public static void countChar() {
		String str="faizanaaaaa";
		HashMap<Character, Integer> hashMap = new HashMap<>();
		 for(int i=0;i<str.length();i++) {
			 char ch = str.charAt(i);
			 if(hashMap.containsKey(ch)) {
				 int count = hashMap.get(ch);
				 hashMap.put(ch, count+1);
			 }else {
				 hashMap.put(ch, 1);
			 }
		 }
		 
		 for(Entry<Character, Integer> map:hashMap.entrySet()) {
			 System.out.println(map.getKey() +" "+map.getValue());
		 }
	}
	
	public static void countChar1() {
	    String str = "faizanaaaaa";
	    int[] charCounts = new int[256]; // Assuming ASCII characters

	    for (int i = 0; i < str.length(); i++) {
	        char ch = str.charAt(i);
	        charCounts[ch]++;
	    }

	    for (int i = 0; i < 256; i++) {
	        if (charCounts[i] > 0) {
	            char ch = (char) i;
	            System.out.println(ch + " " + charCounts[i]);
	        }
	    }
	}
	
	public static void sortStringArray() {
		String[] array= {"Zimbabwe", "South-Africa", "India", "America", "Yugoslavia", " Australia", "Denmark", "France", "Netherlands", "Italy", "Germany"};
		int size=array.length;
		System.out.println(size);
		for(int i=0;i<size-1;i++) {
			for(int j=i+1;j<array.length;j++) {
				if(array[i].compareTo(array[j])>0) {
					String temp=array[i];
					array[i]=array[j];
					array[j]=temp;
					
				}
			}
		}
		
		System.out.println(Arrays.toString(array));
	}
	
	//count character,whitespace and special character
	
	public static void countCharWhite() {
		String str="faizan@ 143 '";
		char[] charArray = str.toCharArray();
		//for(int i=0;i<charArray.length;i++) {
		int digit=0,special=0,whitespace=0,letters=0;
		for(Character ch:charArray) {
			if(Character.isDigit(ch)) {
				digit++;
			}else if(Character.isWhitespace(ch)) {
				whitespace++;
			}else if(Character.isLetter(ch)){
				letters++;
			}else {
				special++;
			}
		}
		System.out.println(digit +" "+whitespace +" "+special +" "+letters);
	}
	
	public static void checkAnagaram() {
		String str="faizan";
		char[] charArray = str.toCharArray();
		String str1="naziaf";
		char[] charArray1 = str1.toCharArray();
		boolean isAnagram=false;
		Arrays.sort(charArray);
		Arrays.sort(charArray1);
		
		System.out.println(Arrays.toString(charArray));
		System.out.println(Arrays.toString(charArray1));
		if(str.length()!=str.length()) {
			isAnagram=false;
		}
		
		for(int i=0;i<charArray.length;i++) {
			if(charArray[i]==charArray1[i]) {
				isAnagram=true;
			}else {
				isAnagram=false;
				break;
			}
		}
		System.out.println(isAnagram);
		
		//second apporoach
		for(int i=0;i<charArray.length;i++) {
		// System.out.printf("index %d ", str.indexOf(charArray1[i]));
		 if(str.indexOf(charArray1[i])==-1) {
			 isAnagram=false;
			 break;
		 }
		}
		System.out.println(isAnagram);
	}
	
	
	
	


}
