package com.circularlist;

import com.dsa.singlyLinkedlit.ListNode;

public class CircularList {
	private ListNode head;
	  
	
	public static void main(String[] args) {
		CircularList circularList = new CircularList();
		
		  ListNode first = new ListNode(4); 
		  ListNode second = new ListNode(66);
		  ListNode third = new ListNode(55);
		  ListNode fourth = new ListNode(76);
		  ListNode fifth = new ListNode(80);
		  
		  circularList.head=first; 
		  first.next=second; 
		  second.next=third;
		  third.next=fourth; 
		  fourth.next=fifth;
		  fifth.next=first;
		 
		
		//circularList.add(26);
		 // circularList.insertAtlast(34);
		 // circularList.deleteFirstNode();
		  circularList.display();
		  circularList.deleteLastNode();
		
		circularList.display();
		//System.out.println();
		//System.out.println(circularList.length()); 
		
	}
	
	public void display() {
		if(head==null) {
			return;
		}
		ListNode current =head;
		//while(current.next!=head) {
			//System.out.print(current.data +" ");
			//current=current.next;
		//}
		//here last element will be left so we can print here
		//System.out.print(current.data);
		
		//second way and better aproach to use do.. while loop
		
		if (head != null) {
            do {
                System.out.print(current.data + " ");
                current = current.next;
            } while (current != head);
        }
		
		
	}
	
	public int length(){
        int length = 0;
        ListNode current = head;
        if (head != null) {
            do {
                length++;
                current = current.next;
            } while (current != head);
        }
        return length;
    }
	public void add(int data) {
        ListNode newNode = new ListNode(data);
        if (head == null) {
            head = newNode;
            newNode.next = head;
        } else {
        	ListNode current = head;
            while (current.next != head) {
                current = current.next;
            }
            current.next = newNode;
            newNode.next = head;
        }
    }
	
	public void insertAtlast(int data) {
		ListNode newNode= new ListNode(data);
		if(head== null) {
			head=newNode;
			newNode.next=head;
		}else {
			
			ListNode current=head;
			while(current.next!=head) {
				current=current.next;
			}
			
			current.next=newNode;
			newNode.next=head;
		}
	}
	
	public void deleteFirstNode() {
		if(head==null) {
			return;
		}
			ListNode current=head;
			while(current !=head) {
				current=current.next;
			}
			current.next=head.next;
			head=head.next;
		
	}
	
	public void deleteLastNode() {
		if(head == null) {
			return;
			
		}
      if(head.next==head) {
		head.next=null;
		head=null;
		}else {
			ListNode current=head;
			ListNode prev=null;
			while(current.next!=head) {
				prev=current;
				current=current.next;
			}
			
		    current.next=null;
		    prev.next=head;
			//temp.next=nxt;
		}
	}

}
