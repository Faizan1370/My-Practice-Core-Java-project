package com.array;

public class Pattern {
	
	public static void main(String[] args) {
		//rightAngle();
		//reverseRightAngle();
		//pyramidShape();
		//singleLine();
		//reverseSingleLine();
		//drawVShape();
		reversePyramid();
	}
	
	public static void rightAngle() {
		for(int i=0;i<=4;i++) {
			for(int j=0;j<=i;j++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}
	
	public static void reverseRightAngle() {
		for(int i=0;i<=4;i++) {
			for(int j=3;j>=i;j--) {
				System.out.print(" ");
			}
			for(int k=0;k<=i;k++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}
	
	public static void oppsiteRightAngle() {
		for(int i=0;i<=4;i++) {
			for(int j=3;j>=i;j--) {
				System.out.print("*");
			}
			System.out.println();
		}
	}
	
	public static void pyramidShape() {
		
		// new code
		   for (int i = 0; i < 4; i++) {
	           // Print spaces for the left side of the pyramid
	          // for (int j = 3; j < 4 - i - 1; j--) {
			   for (int j = 3; j >=i; j--) {
	               System.out.print(" ");
	           }

	           // Print stars for the pyramid
	           for (int k = 0; k < 2 * i + 1; k++) {
	               System.out.print("*");
	           }

	           // Move to the next line for the next row
	           System.out.println();
	       }

	}
	
	public static void reversePyramid() {
		int n=4;
		for(int i=0;i<n;i++) {
			for(int j=2;j<=i+1;j++) {
				System.out.print(" ");	
			}
			
			for(int k=0;k<2*(n-1-i)-1;k++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}
	
	public static void singleLine() {
		for(int i=0;i<=4;i++) {
			for(int j=1;j<=i;j++) {
				System.out.print(" ");
			}
			System.out.print("*");
			System.out.println();
		}
	}
	
	public static void reverseSingleLine() {
		for(int i=0;i<=4;i++) {
			for(int j=3;j>=i;j--) {
				System.out.print(" ");
			}
			System.out.print("*");
			System.out.println();
			
		}
	}
	 public static void drawVShape() {
	        for (int i = 0; i < 4; i++) {
	            // Print spaces for the left side of the V
	            for (int j = 0; j < i; j++) {
	                System.out.print(" ");
	            }

	            // Print a star at the tip of the V
	            System.out.print("*");

	            // Print spaces for the right side of the V
	            for (int k = 0; k < 2 * (4 - i - 1); k++) {
	                System.out.print(" ");
	            }

	            // Print a star at the other tip of the V
	            if (i != 0) {
	                System.out.print("*");
	            }

	            // Move to the next line for the next row
	            System.out.println();
	        }
	    }
	
	
}
