package com.array;

import java.util.Arrays;

public class Practice {

	public static void main(String[] args) {
		test();
		

	}
	
	public static void test()
	{
		int[] a= {5,6,2,5,6,7};
		int[] b=new int[a.length];
		int j=0;
		int delete=2;
		for(int i=0;i<a.length;i++) {
			if(a[i]!=delete) {
				b[j]=a[i];
				j++;
			}
		}
		System.out.println(Arrays.toString(b));
	}
}
