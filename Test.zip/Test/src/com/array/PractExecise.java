package com.array;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class PractExecise {

	public static void main(String[] args) {
		findSecondLargest();
		fineMissingNumber();
		removeDuplicates();
		moveAllZeroRight();
		moveAllZeroleft();
		deleteValueArray();
		deleteValueArray1();
		insertValueInArray();
		insertValueInArray1();
		removeDuplicatesUnsortedArray();
		shuffleArray();
		findTwoNumbersSumOfNunber();
		fibonaciSeries();
		reArrangePosNegValues();
		reArrangePosNegValues1();
		reArrangePosNegValues12();
		rightRotateByOneIndex();
		findMin();
		maxValue();
		reverseArray();
		sortAscDesc();
		rightAngle();
		rightAngle1();
		singleLine();
		singleVshape();
		reverseSingleVshape();
		rightAngle2();
		pyramidShape();
		reversePyramidShape();

	}
	
	public static void findSecondLargest() {
		int[] arr = {2,4,6,2,7};
		int largest =0;
		int secondLargest =0;
		for(int i=0;i<arr.length;i++) {
			if(arr[i]>largest) {
				secondLargest=largest;
				largest=arr[i];
			}else if(arr[i]>secondLargest) {
				secondLargest=arr[i];
			}
		}
		System.out.println(secondLargest);
	}
	
	public static void fineMissingNumber() {
		int[] arr = {1,3,4,2,6};
		int n= arr.length+1;
		int sum = n*(n+1)/2;
		
		for(int i=0;i<arr.length;i++) {
			sum =sum-arr[i];
		}
		
		System.out.println(sum);
	}
	
	public static void removeDuplicates() {
		int[] arr = {1,1,2,2,3,3,4,6};
		int[] resultArray = new int[arr.length];
		int j=0;
		for(int i=0;i<arr.length-1;i++) {
			if(arr[i]!=arr[i+1]) {
				resultArray[j]=arr[i];
				j++;
			}
		}
		resultArray[j]=arr[arr.length-1];
		
		for(int k=0;k<=j;k++) {
			System.out.print(resultArray[k]+" ");
		}
		System.out.println();
	}
	
	public static void moveAllZeroRight() {
		int[] arr= {1,4,0,5,0,4,7,0,23,45};
		int[] resultArr = new int[arr.length];
		int j=0;
		for(int i=0;i<arr.length;i++) {
			if(arr[i]!=0) {
				resultArr[j]=arr[i];
				j++;
			}
		}
		
		System.out.println(Arrays.toString(resultArr));
	}
	
	public static void moveAllZeroleft() {
		int[] arr= {1,4,0,5,0,4,7,0,23,45};
		int[] resultArr = new int[arr.length];
		int countZero=0;
		int j=0;
		for(int i=0;i<arr.length;i++) {
			if(arr[i]==0) {
				countZero++;
			}
		}
		for(int k=0;k<resultArr.length;k++) {
			if(arr[k]!=0) {
				resultArr[countZero]=arr[k];
			    countZero++;
			}
		}
		
		System.out.println(Arrays.toString(resultArr));
	}
	
	public static void deleteValueArray() {
		int[] arr= {1,4,66,10,25,78};
		int delete =10;
		int j=0;
		int[] resultArray= new int[arr.length];
		for(int i=0;i<arr.length;i++) {
			if(arr[i]!=delete) {
				resultArray[j]=arr[i];
				j++;
			}
		}
		
		System.out.println(Arrays.toString(resultArray));
	}
	
	public static void deleteValueArray1() {
		int[] arr= {1,4,66,10,25,78};
		int delete =10;
		for(int i=0;i<arr.length;i++) {
			if(arr[i]==delete) {
				for(int k=i;k<arr.length-1;k++) {
					arr[k]=arr[k+1];
				}
			}
		}
		
		System.out.println(Arrays.toString(arr));
	}
	
	public static void insertValueInArray() {
		int[] arr= {1,4,66,10,25,78};
		int position=3;
		int element=12;
		int[] resultArray = new int[arr.length+1];
		int j=0;
		for(int i=0;i<arr.length;i++) {
			if(i==position) {
				resultArray[j]=element;
				j++;
			}
	        resultArray[j] = arr[i];
			j++;
			
			
		}
		System.out.println(Arrays.toString(resultArray));
	}
	
	public static void insertValueInArray1() {
		int[] arr= {1,4,66,10,25,78};
		int position=3;
		int element=12;
		
		for(int i=0;i<arr.length;i++) {
			if(i==position) {
				for(int k=arr.length;k<i;k++) {
					arr[k]=arr[k-1];
				}
				arr[i]=element;
			}
			
		}
		System.out.println(Arrays.toString(arr));
	}
	
	public static void removeDuplicatesUnsortedArray() {
		int[] a = {1,5,4,78,23,1,4,78,5};
		int[] b = new int[a.length];
		int k=0;
		for(int i=0;i<a.length;i++) {
			boolean isdupl=false;
			for(int j=0;j<k;j++) {
				if(a[i]==b[j]) {
					isdupl=true;
					break;
				}
			}
			if(!isdupl) {
				b[k]=a[i];
				k++;
			}
		}
		System.out.println(Arrays.toString(b));
	}
	
	public static void shuffleArray() {
		Integer[] a = {1,5,4,78,23,1,4,78,5};
		List<Integer> list = Arrays.asList(a);
		int len = list.size();
		/*
		 * Collections.shuffle(list); list.toArray(a);
		 * System.out.println(Arrays.toString(a));
		 */
		
		for(int i=0;i<a.length;i++) {
			int index = new Random().nextInt(len);
			Integer integer = list.get(index);
			System.out.print(integer+" ");
		}
	}
	
	public static void findTwoNumbersSumOfNunber() {
		int number=7;
		int[] array= {4,6,1,3,6,8,2};
		
		for(int i=0;i<array.length-1;i++) {
			for(int j=i+1;j<array.length;j++) {
			  if(array[i]+array[j]==number) {
				  System.out.println(array[i] +"->"+array[j] +"->"+number);
			  }
			}
		}
	}
	
	public static void fibonaciSeries() {
		int a=0,b=1;
		for(int i=0;i<10;i++) {
			System.out.print(a +" ");
			int c=a+b;
			a=b;
			b=c;
		}
		System.out.println();
	}
	
	public static void reArrangePosNegValues() {
		int[] arr= {4,6,-1,3,-6,8,-2};
		
		int j = 0; 
		 for(int i=0;i<arr.length;i++) {
			 if(arr[i]<0) {
				
				 int temp =arr[i];
				 arr[i]=arr[j];
				 arr[j]=temp;
			
				 j++;
			 }
			
		 }
		 System.out.println(Arrays.toString(arr));
	}
	
	public static void reArrangePosNegValues1() {
		int[] arr= {4,6,-1,3,-6,8,-2};
		int[] resultArray= new int[arr.length];
		int counter =0;
		for(int i=0;i<arr.length;i++) {
			if(arr[i]<0) {
				resultArray[counter]=arr[i];
				counter++;
			}
		}
		for(int j=0;j<arr.length;j++) {
			if(arr[j]>0) {
				resultArray[counter]=arr[j];
				counter++;
			}
		}
		
		System.out.println(Arrays.toString(resultArray));
	}
	
	public static void reArrangePosNegValues12() {
		int[] arr= {4,6,-1,3,-6,8,-2};
		int[] resultArray= new int[arr.length];
		int start=0;
		int end=arr.length-1;
		for(int i=0;i<arr.length;i++) {
			if(arr[i]<0) {
				resultArray[start]=arr[i];
				start++;
			}else {
				resultArray[end]=arr[i];
				end--;
			}
		}
		System.out.println(Arrays.toString(resultArray));
	}
	public static void rightRotateByOneIndex() {
		int[] array= {4,6,1,3,6,8,2};
		int elementRotate=array[array.length-1];;
		for(int i=array.length-1;i>0;i--) {
			array[i] =array[i-1];
	}
		array[0]=elementRotate;
		System.out.println(Arrays.toString(array));
	}
	
	public static void findMin() {
		int[] array= {4,6,1,3,6,8,2};
		int min = Integer.MAX_VALUE;
		for(int i=0;i<array.length;i++) {
			if(array[i]<min) {
				min=array[i];
			}
		}
		System.out.println("Min value :"+min);
	}
	
	public static void maxValue() {
		int[] array= {4,6,1,3,6,8,2};
		int max = Integer.MIN_VALUE;
		for(int i=0;i<array.length;i++) {
			if(array[i]>max) {
				max=array[i];
			}
		}
		System.out.println("max :"+max);
	}
	
	public static void reverseArray() {
		int[] array= {4,6,1,3,6,8,2};
		int start=0;
		int end=array.length-1;
		while(start<end) {
			int temp =array[start];
			array[start]=array[end];
			array[end] =temp;
			end--;
			start++;
		}
		System.out.println(Arrays.toString(array));
	}
	
	public static void sortAscDesc() {
		int[] array= {4,6,1,3,6,8,2};
		for(int i=0;i<array.length;i++) {
			for(int j=i+1;j<array.length;j++) {
				if(array[i]>array[j]) {
					int temp=array[i];
					array[i]=array[j];
					array[j]=temp;
				}
			}
		}
		System.out.println(Arrays.toString(array));
	}
	
	public static void rightAngle() {
		for(int i=0;i<5;i++) {
			for(int j=0;j<=i;j++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}
	public static void rightAngle1() {
		for(int i=0;i<5;i++) {
			for(int j=0;j<5-i;j++) {
				System.out.print(" ");
			}
			for(int k=0;k<=i;k++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}
	
	public static void rightAngle2() {
		for(int i=0;i<5;i++) {
			for(int j=i;j<5;j++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}
	
	public static void singleLine() {
		for(int i=0;i<5;i++) {
			for(int j=0;j<5;j++) {
				System.out.print(" ");
			}
			System.out.print("*");
			System.out.println();
		}
	}
	public static void singleVshape() {
		for(int i=0;i<5;i++) {
			for(int j=i;j<5;j++) {
				System.out.print(" ");
			}
			System.out.println("*");
		}
	}
	public static void reverseSingleVshape() {
		for(int i=0;i<5;i++) {
			for(int j=0;j<=i;j++) {
				System.out.print(" ");
			}
			System.out.println("*");
		}
	}
	
	public static void pyramidShape() {
		for(int i=0;i<5;i++) {
			for(int j=i;j<5;j++) {
				System.out.print(" ");
			}
			
			for(int k=0;k<2*i+1;k++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}
	
	public static void reversePyramidShape() {
		for(int i=0;i<5;i++) {
			for(int j=0;j<i;j++) {
				System.out.print(" ");
			}
			for(int k=0;k<2*(5-i-1)-1;k++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}

}
