package com.array;

import java.util.Arrays;

public class ArrayMinMax {
	public static void main(String[] args) {
		int[] arr= {4,6,8,5,9,2};
		//findMin(arr);
		/*
		 * int[] reverseArray = reverseArray(arr); for(int
		 * i=0;i<reverseArray.length;i++) { System.out.print(reverseArray[i] +" "); }
		 */
		//findMax(arr);
		int[] sortArray = sortAscAndDscArray(arr);
		System.out.println(Arrays.toString(sortArray));
		
	}
	

	
	public static void findMin(int[] arr) {
		
		int min=arr[0];
		//int min=Integer.MAX_VALUE;
		 for(int i=1;i<arr.length;i++) {
			 if(arr[i]<min) {
				 min=arr[i];
			 }
			 
			 
		 }
		 System.out.println(min);
		
		
	}
	
	public static int[] reverseArray(int[] arr) {
		
		int temp=0;
		int len=arr.length;
		
		
		
		
		
		  for(int i=0;i<len/2;i++) {
		  
		  temp=arr[i]; 
		  arr[i]=arr[len-(i+1)]; 
		  arr[len-(i+1)]=temp;
		  
		  }
		 
		
		/*
		 * int[] reverseArray = new int[len]; int j=len; for(int i=0;i<arr.length;i++) {
		 * reverseArray[j-1]=arr[i]; j--; }
		 */
		int start=0;
		int end= len-1;
		while(start<end) {
			temp=arr[start];
			arr[start] =arr[end];
			arr[end]=temp;
			start++;
			end--;
			
		}
		
		
		
		return arr;
	}
	
	public static void findMax(int[] arr) {
		int max=Integer.MIN_VALUE;
		for(int i=0;i<arr.length;i++) {
			if(arr[i]>max) {
				max=arr[i];
			}
		}
		System.out.println(max);
	}
	
	public static int[] sortAscAndDscArray(int[] arr) {
		int temp=0;
		for(int i=0;i<arr.length;i++) {
			for(int j=i+1;j<arr.length;j++) {
				//if(arr[i]>arr[j]) { // sort asc
					if(arr[i]<arr[j]) { //reverse sort or dsc
					temp=arr[i];
					arr[i]=arr[j];
					arr[j]=temp;
				}
			}
			//System.out.print(arr[i]+" ");
		}
		
		return arr;
		
	}
}
