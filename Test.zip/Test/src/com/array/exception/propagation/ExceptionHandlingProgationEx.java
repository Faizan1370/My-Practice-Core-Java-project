package com.array.exception.propagation;

import java.io.IOException;
import java.util.HashSet;
import java.util.Random;

public class ExceptionHandlingProgationEx {
	private static HashSet<String> set = new HashSet<String>();
	
	public static void checkName(String name) {
		set.add("suhail");
		if(set.contains(name)) {
			throw new DuplicateNameException("This is invalid name :"+name);
		}else {
			System.out.println("This is Valid Name :"+name);
		}
		
	}
	
	public static void information(String name) {
		//try {
			ExceptionHandlingProgationEx.checkName(name);
	/*	}catch (DuplicateNameException e) {
			System.out.println("haldeded in prvioud methid ");
		}catch(RuntimeException e) {
			System.out.println("haldeded using parent exception ");	
		}catch(Exception ex) {
			
		}catch (Throwable e) {
			// TODO: handle exception
		}*/
		
		
	}
	
	public static void handleDuplicateException(String name) {
		try {
			ExceptionHandlingProgationEx.information(name);
		}catch(DuplicateNameException ex) {
			System.out.println("duplicate name");
			Random random = new Random();
			ExceptionHandlingProgationEx.checkName("faizan"+random.nextInt());
		}
			
	}
	public static void main(String[] args) {
		ExceptionHandlingProgationEx.handleDuplicateException("suhail");
	}

}
