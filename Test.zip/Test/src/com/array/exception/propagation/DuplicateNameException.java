package com.array.exception.propagation;

public class DuplicateNameException extends RuntimeException{
	
	public DuplicateNameException(String msg) {
		super(msg);
	}

}
