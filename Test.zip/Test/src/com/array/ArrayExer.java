package com.array;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class ArrayExer {
	
	public static void main(String[] args) {
		int[] arr= {2,4,-5,90,34,65,78,-45,77,87,66};
		
		//System.out.println(arr.length);
		//findSeconLargestNum(arr);
		//findMissingNumber();
		//removeDuplicates();
		//moveAllZero1();
		//deleteValueArray1();
		//insertElementArray1();
		 //removeDuplicatesUnsortedArray();
		//shuffleArray();
		//fibonaciSeries();
		//findTwoNumbersSumOfNunber1();
		//reArrangePosNegValues();
		//rightRotateByOneIndex();
		
		//System.out.println(checkPlaindrome()); ;
		//System.out.println(checkAmostronge());
		testLargest();
		testMissing();
		
	}
	
	public static void findSeconLargestNum(int[] arr) {
		int largest =0;
		int secondLargestNumber=0;
		System.out.println(arr.length);
		for(int i=0;i<arr.length;i++) {
			if(arr[i] >largest) {
				secondLargestNumber=largest;
				largest=arr[i];
			}else if(arr[i]>secondLargestNumber) {
				secondLargestNumber=arr[i];
			}
			
		}
		
		System.out.println("Second largest number is :"+secondLargestNumber);
		
	}
	
	
	public static void findMissingNumber() {
		int[] arr= {1,2,5,6,7,4};
		//Arrays.sort(arr);
		int n= arr.length+1;
		int sum=n *(n+1)/2;
		
		
		for(int num :arr) {
				
				sum=sum-num;
			}
		System.out.println(sum);
		}
	
	
	public static void removeDuplicates() {
		//int[] arr= {1,4,1,5,4,4,7,7,23,45};
		//Arrays.sort(arr);
		int arr[] = {1,1,2,2,3,3,4,6};
		/*
		 * int[] arrAns= new int[arr.length]; int flag = 0, k = 0; for (int i = 0; i <
		 * arr.length; i++) { for (int j = 0; j < arrAns.length; j++) { if (arr[i] ==
		 * arrAns[j]) { flag = 0; break; } flag=1; } if (flag == 1) { arrAns[k] =
		 * arr[i]; k++; } flag = 0; }
		 * 
		 * System.out.println(Arrays.toString(arrAns));
		 */
		
		int[] arr1 =new int[arr.length];
		//Arrays.sort(arr);
		int j=0;
		for(int i=0;i<arr.length-1;i++)
		{
			 if (arr[i] != arr[i+1]){  
	                arr1[j] = arr[i];  
	                j++;
	            }  
		}
		
		  arr1[j] = arr[arr.length-1]; 
		  j++;
		 
		for(int k=0;k<j;k++) {
			System.out.print(arr1[k] +" ");
		}
		
		
	}
	
	public static  void moveAllZero() {
		int[] arr= {1,4,0,5,0,4,7,0,23,45};
		int[] resultArr = new int[arr.length];
		int j =resultArr.length-1;
		int k=0;
		for(int i=0;i<arr.length;i++) {
			if(arr[i] ==0) {
				
				resultArr[j]=arr[i];
				j--;
				
			}else {
				resultArr[k]=arr[i];
				k++;
			}
		}
		
		
		int count=0;
		 for (int i = 0; i < arr.length; i++)
	            if (arr[i] != 0)
	                arr[count++] = arr[i]; // here count is
	                                       // incremented
	 
	        // Now all non-zero elements have been shifted to
	        // front and 'count' is set as index of first 0.
	        // Make all elements 0 from count to end.
	        while (count < arr.length)
	            arr[count++] = 0;
	        
	        System.out.println(Arrays.toString(arr));
		
		
	}
	
	public static  void moveAllZero1() {
		int[] arr= {1,4,0,5,0,4,7,0,23,45};
		int[] a= new int[arr.length];
		int inr =0;
		for(int i=0;i<arr.length;i++) {
			if(arr[i] !=0) {
				a[inr]=arr[i];
				inr++;
			}
		}
		
		System.out.println(inr);
		//System.out.println(Arrays.toString(a));
		for(int j=inr;j<arr.length;j++) {
			a[j]=0;
		}
		System.out.println(Arrays.toString(a));
		/*
		 * for(int k=0;k<arr.length;k++) { System.out.println(a[k]+" "); }
		 */
	}
	
	public static void deleteValueArray() {
		int[] arr= {1,4,66,10,25,78};
		int delete=10;
		
		for(int i=0;i<arr.length;i++) {
			if(arr[i]==delete) {
				for(int j=i;j<arr.length-1;j++) {
					arr[j]=arr[j+1];	
				}
				break;
				
			}
		}
		for(int i=0;i<arr.length-1;i++) {
		System.out.print(arr[i]+" ");
		}
	}
	
	public static void deleteValueArray1() { 
		int[] arr= {1,4,66,10,25,78};
		int delete=10;
		int[] a=new int[arr.length];
		int j=0;
		for(int i=0;i<arr.length;i++) {
			if(arr[i]!=delete) {
			 a[j]=arr[i];	
			 j++;
			}
		}
		
		System.out.println(Arrays.toString(a));
		
		
	}
	
	public static void insertElementArray() {
		int[] arr= {1,4,66,10,25,78};
		int position=3;
		int element=22;
		
		for(int i=arr.length-1;i>position-1;i--) {
			arr[i]=arr[i-1];
		}
		arr[position-1]=element;
		
		System.out.println(Arrays.toString(arr));
		
		
	}
	
	public static void insertElementArray1() {
		int[] arr= {1,4,66,10,25,78};
		int position=3;
		int element=22;
		int[] a=new int[arr.length+1];
		int j=0;
		
		for(int i=0;i<arr.length;i++) {
			if(i==position-1) {
				a[j]=element;
				a[position]=arr[i];
				j++;
				j++;
			}else {
				a[j]=arr[i];
				j++;
			}
		}
		System.out.println(Arrays.toString(a));
	}
	
	
	public static void removeDuplicatesUnsortedArray() {
		int[] a = {1,5,4,78,23,1,4,78,5};
		int[] b = new int[a.length];
		int k=0;
		 for (int i = 0; i < a.length; i++) {
		        boolean isDuplicate = false;

		        for (int j = 0; j < k; j++) {
		            if (a[i] == b[j]) {
		                isDuplicate = true;
		                break;
		            }
		        }

		        if (!isDuplicate) {
		            b[k] = a[i];
		            k++;
		        }
		    }
		System.out.println(Arrays.toString(b));
	}

	public static void shuffleArray() {
		Integer[] a = {1,5,4,78,23,1,4,78,5};
		List<Integer> asList = Arrays.asList(a);
		/*
		 * Collections.shuffle(asList); asList.toArray(a);
		 * System.out.println(Arrays.toString(a));
		 */
		
		int len=asList.size();
		
		for(int i=0;i<a.length;i++) {
			int index = new Random().nextInt(len);
			Integer integer = asList.get(index);
			System.out.println(integer);
		}
		
		
	}
	
	public static void fibonaciSeries() {
		int a=0,b=1;
		for(int i=0;i<10;i++) {
			System.out.print(a +" ");
			int c=a+b;
			a=b;
			b=c;
		}
	}
	
	//Find Two Numbers that Add up to n
	public static void findTwoNumbersSumOfNunber() {
		int number=7;
		int[] array= {4,6,1,3,6,8,2};
		
		for(int i=0;i<array.length-1;i++) {
			for(int j=i+1;j<array.length;j++) {
				if((array[i]+array[j])==number) {
					System.out.println(array[i] +"->"+array[j] +"->"+number);
				}
			}
		}
	}
	
	//Find Two Numbers that Add up to n
	public static void findTwoNumbersSumOfNunber1() { //not working
		int number=7;
		int[] array= {4,6,1,3,6,8,2};
		Arrays.sort(array);
		
		int start=0;
		int end=array.length-1;
		int sum=0;
		while(start!=end) {
			sum=array[start]+array[end];
			if(sum<number) {
				start++;
			}else if(sum>number) {
				end--;
			}else {
				System.out.println(start +"-> "+end);
			}
		}
	}
	
	//Rearrange Positive & Negative Values
	//we can do by sortig but here we need to maintain the position of the element
	//[-1, -6, -2, 3, 6, 8, 4]
	public static void reArrangePosNegValues() {
		int[] arr= {4,6,-1,3,-6,8,-2};
		    int j = 0; 
		    for (int i = 0; i < arr.length; i++) { 
		      if (arr[i] < 0) {   // if negative number found
		        if (i != j) { // we can remove this condition
		          int temp = arr[i];
		          arr[i] = arr[j]; // swapping with leftmost positive
		          arr[j] = temp;
		       }
		        j++; 
		      } 
		    } 
		    
		    System.out.println(Arrays.toString(arr));
		  } 
		
	//Right Rotate the Array by One Index
	//int[] array= {2,4,6,1,3,6,8};
	public static void rightRotateByOneIndex() {
		int[] array= {4,6,1,3,6,8,2};
		int rotatedElement=array[array.length-1];
		for(int i=array.length-1;i>0;i--) {
			array[i]=array[i-1];
		}
		array[0]=rotatedElement;
		System.out.println(Arrays.toString(array));
	}
	
	public static boolean checkPlaindrome() {
		int num=127;
		boolean flag=false;
		int sum=0;
		int temp=num;
		while(num>0) {
			int r=num%10;
			sum=sum*10+r;
			num=num/10;
		}
		if(sum==temp) {
			flag=true;
		}
		return flag;
		
		
	}
	
	public static boolean checkAmostronge() {
		int num=153;
		int sum=0;
		int temp=num;
		int digits=0;
		while(num>0) {
			num=num/10;
			digits++;
		}
		num=temp;
		System.out.println(digits);
		while(num>0) {
			int r=num%10;
			//sum=(int) (sum+Math.pow(r, digits));
			sum=sum+r*r*r;
			num=num/10;
		}
		if(temp==sum) {
			return true;
		}
		return false;
		
	}
	
	public static void testLargest() {
		int[] arr = {4,6,1,4,9,15};
		int largest=0;
		int secondlargest=0;
		for(int i=0;i<arr.length;i++) {
			if(arr[i]>largest) {
			secondlargest=largest;
			largest=arr[i];
			}else if(arr[i]>secondlargest) {
				secondlargest=arr[i];
			}
		}
		System.out.println("second largets :"+secondlargest);
	}
	public static void testMissing() {
		int[] arr= {1,2,3,6,7,4};
		int n =arr.length+1;
		int sum=n*(n+1)/2;
		
		for(int num :arr) {
			sum=sum-num;
		}
		System.out.println(sum);
		
	}
	

}
