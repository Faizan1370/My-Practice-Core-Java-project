package com.queue;

public class ImplementQueue<T> {
	
	private ListNode<T> head;
	private ListNode<T> tail;
	
	
	public static void main(String[] args) {
		ImplementQueue<Integer> implementQueue = new ImplementQueue<Integer>();
		implementQueue.enqueue(5);
		implementQueue.enqueue(56);
		implementQueue.enqueue(34);
		
		System.out.println(implementQueue.dequeue());
		System.out.println(implementQueue.size());
	}
	
	public void enqueue(T data) {
		ListNode<T> newNode = new ListNode<T>(data);
		
		if(tail!=null) {
			tail.next=newNode;
		}
		
	   tail=newNode;
	   if(head==null) {
		   head=newNode;
	   }
	}
	
	public T dequeue() {
		if(head== null) { 
		   return null;
		}
		T dataElement=head.data;
		head=head.next;
		if(head== null) {
			tail=null;
		}
		return dataElement;
	}
	
	 public int size() {
	        int size = 0;
	        ListNode<T> current = head;
	        while (current != null) {
	        	System.out.print(current.data +" ");
	            size++;
	            current = current.next;
	        }
	        System.out.println();
	        return size;
	    }

}
