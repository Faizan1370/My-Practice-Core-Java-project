package com.treedsa;

import java.util.Comparator;
import java.util.Queue;
import java.util.Stack;
import java.util.concurrent.ConcurrentLinkedQueue;

public class BinaryTree<T> {
	
	private TreeNode<T> root;
	/*
	 * private Comparator<T> comparator; public BinaryTree(Comparator<T> comparator)
	 * { this.comparator = comparator; }
	 */
	
	public static void main(String[] args) {
		
	
	/*	BinaryTree<Integer> bt = new BinaryTree<>(new Comparator<Integer>() {
		    @Override
		    public int compare(Integer data1, Integer data2) {
		        return data1 - data2;
		    }
		});*/
		
		//bt.preOrderTraversal(null);
	  BinaryTree<Integer> bt = new BinaryTree<>();
	  bt.insertIterative(13);
	  bt.insertIterative(12);
	  bt.insertIterative(15);
	  bt.insertIterative(6);
	  bt.insertIterative(8);
	  bt.insertIterative(43);
	  bt.insertIterative(56);
	  
	  //bt.preOrderTraversal();
	 // bt.itreativeInOrderTraversal();
	  bt.recPostOrdr();
		
	}
	
	/*
	 * public void createBinaryTree() { BinaryTree<Integer> bt = new
	 * BinaryTree<>(new Comparator<Integer>() {
	 * 
	 * @Override public int compare(Integer data1, Integer data2) { return data1 -
	 * data2; } });
	 * 
	 * bt.add(6); bt.add(8); bt.add(9); bt.add(90); bt.add(2);
	 * bt.preOrderTraversal((TreeNode<Integer>) root);;
	 * bt.iterativePreorderTranversal();
	 * 
	 * 
	 * }
	 */
	
	/*
	 * public void add(T data) { TreeNode<T> newNode= new TreeNode<>(data);
	 * if(root==null) { root=newNode; }else { TreeNode<T> current=root; while(true)
	 * { if (comparator.compare(data,current.data)<0) { if(current.left==null) {
	 * current.left=newNode; break; }else { current=current.left; }
	 * 
	 * }else { if(current.right==null) { current.right=newNode; break; }else {
	 * current=current.right; } } } } }
	 */
	
	public void insert(T data) {
		root=insert(root,data);
	}
	
	
	//It is approach to add in BST but we need to check the value less or greater
	//Here insertIterative and insert work in differently
	public TreeNode<T> insert(TreeNode<T> root, T data){
		if(root == null) {
			return new TreeNode<>(data);
		}
		//here we have to put the condition to retrun null like -1
		//if it put null on left side then will move to right
		if(data.equals("-1")) {
			return null;
		}
		if(root.left==null) {
			root.left=insert(root.left, data);
		}else {
			root.right=insert(root.right, data);
		}
		
		return root;
	}
	


    // Method to insert a value into the binary tree iteratively
	//This is using level order insertion mean first root then left and in right.
    public void insertIterative(T value) {
        TreeNode<T> newNode = new TreeNode<>(value);

        if (root == null) {
            root = newNode;
            return;
        }

        Queue<TreeNode<T>> queue = new ConcurrentLinkedQueue<>();
        queue.add(root);

        while (!queue.isEmpty()) {
            TreeNode<T> currentNode = queue.poll();

            if (currentNode.left == null) {
                currentNode.left = newNode;
                return; // this return make the completed or fullfilled the subtree and return back to normal flow
            } else if (currentNode.right == null) {
                currentNode.right = newNode;
                return; // this return make the completed or fullfilled the subtree and return back to normal flow
            }

            queue.add(currentNode.left);
            queue.add(currentNode.right);
        }
    }
	
	public void preOrderTraversal() {
		preOrderTraversal(root);
	}
	
	public void preOrderTraversal(TreeNode<T> current) {
        if (current != null) {
            System.out.print(current.data + " ");
            preOrderTraversal(current.left);
            preOrderTraversal(current.right);
        }
    }
	
	
	public void iterativePreorderTranversal() {
		if(root ==null) {
			System.out.println("Tree is empty");
			return;
		}
		
		Stack<TreeNode<T>> stack = new Stack<>();
		stack.push(root);
		
		while(!stack.empty()) {
			TreeNode<T> current = stack.pop();
			
			System.out.print(current.data+ " ");
			
			if(current.right!=null) {
				stack.push(current.right);
			}
			
			if(current.left!=null) {
				stack.push(current.left);
			}
		}
	}
	
	public void recursiveInOrderTraversal(TreeNode<T> root) {
		if(root==null) {
			return;
		}
		
		recursiveInOrderTraversal(root.left);
		System.out.print(root.data + " ");
		recursiveInOrderTraversal(root.right);
	}
	
	public void itreativeInOrderTraversal() {
		if(root==null) {
			System.out.println("Tree has no node");
			return;
		}
		
		Stack<TreeNode<T>> stack = new Stack<>();
		TreeNode<T> temp = root;
		
		while(!stack.isEmpty() || temp !=null) {
			if(temp !=null) {
			    stack.push(temp);
				temp=temp.left;
			}else {
				temp=stack.pop();
				System.out.print(temp.data + " ");
				temp=temp.right;
			}
		}
	}
	public void recPostOrdr() {
		recursivePostorderTranversal(root);
	}
	
	public void recursivePostorderTranversal(TreeNode<T> root) {
		if(root== null) {
			return;
		}
		
		recursivePostorderTranversal(root.left);
		recursivePostorderTranversal(root.right);
		System.out.print(root.data +" ");
	}
	
	public void iterativePostorderTraversal() {
		if(root == null) {
			System.out.println("Tree has no node");
			return;
		}
	}
	
	
	/*
	 * public void preOrderTraversal() { TreeNode<T> current = root; while (current
	 * != null) { System.out.print(current.data + " "); if (current.left != null) {
	 * current = current.left; } else { if (current.right != null) { current =
	 * current.right; } else { while (current != null) { if (current.right != null)
	 * { current = current.right; break; } current = current.right; } } } } }
	 */






}
