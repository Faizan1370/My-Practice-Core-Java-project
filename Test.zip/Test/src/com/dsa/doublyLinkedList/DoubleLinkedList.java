package com.dsa.doublyLinkedList;


public class DoubleLinkedList {
	
	private ListNode head;
	
	public static void main(String[] args) {
		DoubleLinkedList doubleLinkedList = new DoubleLinkedList();
		doubleLinkedList.insertNodeLast(2);
		doubleLinkedList.insertNodeLast(17);
		doubleLinkedList.insertNodeLast(4);
		doubleLinkedList.insertNodeLast(14);
		doubleLinkedList.insertNodeLast(12);
		doubleLinkedList.insertNodeLast(9);
		
		//doubleLinkedList.insertNodePosition(6, 7);
		//doubleLinkedList.deleteNodePosition(1);
		//doubleLinkedList.deleteByVlaue(4);
		System.out.println(doubleLinkedList.findNodePositionByValue(100)); 
		
		doubleLinkedList.display();
		//doubleLinkedList.deleteLastNode();
		//doubleLinkedList.display();
		//System.out.println();
		//System.out.println(doubleLinkedList.length());
		
		
	}
	
	public void insertNodeStart(int data) {
		ListNode newNode = new ListNode(data);
		newNode.next=head;
		newNode.previous=null;
		if(head !=null) {
			head.previous=newNode;
		}
		head=newNode;
	}
	
	
	public void insertNodeLast(int data) {
		ListNode newNode = new ListNode(data);
		ListNode current=head;
		newNode.next = null;
		 if (head == null) {
	            newNode.previous = null;
	            head = newNode;
	            return;
	        }
		while(current.next !=null) {
			current=current.next;
		}
		  current.next=newNode;
		  newNode.previous=current;
	}
	
	public void display() {
		ListNode current=head;
		ListNode prev =null;
		//Forward direction traverse
		while(current !=null) {
			System.out.print(current.data +" ");
			prev=current;
			current=current.next;
		}
		System.out.print("null");
		System.out.println();
		
		/*
		 * //reverse direction traverse while(prev !=null) { System.out.print(prev.data
		 * +" "); prev =prev.previous; } System.out.print("null");
		 */
	}
	
	public int length() {
		int count=0;
		ListNode current=head;
		while(current !=null) {
			count++;
			current=current.next;
			
		}
		return count;
	}
	
	public void deleteFirstNode() {
		if(head==null) {
			return;
		}
		if(head.next ==null) {
			head=null;
		}else {
		
		//ListNode current=head;
		//ListNode temp=null;
		//temp=current;
		//current=current.next;
		//current.previous=null;
		//temp.next=null;
		//head=current;
		
		//second way
		ListNode temp=null;
		temp=head;
		head=head.next;
		head.previous=null;
		temp.next=null;
		}
		
	}
	
	public void deleteLastNode() {
		ListNode current=head;
		ListNode temp=null;
		if(head==null) {
			return;
		}
		
		if(head.next==null) {
			head=null;
		}else {
			while(current.next !=null) {
				temp=current;
				current=current.next;
			}
			current.previous=null;
			temp.next=null;
			
		}
	}
	
	public void insertNodePosition(int position,int data) {
		ListNode newNode= new ListNode(data);
		if(head==null) {
			return;
		}
		if(position==1) {
			newNode.next=head;
			newNode.previous=null;
			head=newNode;
		}else {
			int count=0;
			ListNode current=head;
			ListNode prev =null;
			while(count<position-1) {
				prev=current;
				current=current.next;
				count++;
			}
			prev.next=newNode;
			newNode.previous=prev;
		    newNode.next=current;
		    current.previous=newNode;
		}
		
		
	}
	
	public void deleteNodePosition(int position) {
		if(head==null) {
			return;
		}
		if(position==1) {
			ListNode temp=null;
			temp=head;
			head=head.next;
			head.previous=null;
			temp.next=null;
		}else {
			ListNode current=head;
			int count =0;
			while(count<position-1) {
				current=current.next;
				count++;
			}
			ListNode temp=current.next;
			ListNode pre=current.previous;
			if(temp !=null) {
				temp.previous=pre;
				pre.next=temp;
			}else {
				System.out.println("is this");
				pre.next=null;
				current.previous=null;
			}
			
			
			//temp.previous=current;
		}
	}
	
	public void deleteByVlaue(int data) {
		if(head==null) {
			return;
		}
	   ListNode current=head;
		if(current.data==data) {
			head=current.next;
			head.previous=null;
			current.next=null;
			
		}
		while(current !=null && current.data != data) {
			current=current.next;
			
		}
		ListNode nxt=current.next;
		ListNode prev=current.previous;
		if(nxt!=null) {
			System.out.println("not last");
			nxt.previous=prev;
			prev.next=nxt;
		}else {
			System.out.println("last");
			current.previous=null;
			prev.next=null;
		}
	}
	
	public int findNodePositionByValue(int data) {
		if(head==null) {
			return Integer.parseInt("List is Empty");
		}
		
		ListNode current=head;
		int count=1;
		while(current!=null && current.data!=data) {
			current=current.next;
			count++;
		}
		if(current!=null && current.data==data) {
			return count;
		}else {
		return -1;
		}
		
	}
	
	
	

}
