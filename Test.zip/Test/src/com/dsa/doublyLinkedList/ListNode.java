package com.dsa.doublyLinkedList;

public class ListNode {
	
	public int data;
	public ListNode next;
	public ListNode previous;
	
	ListNode(int data){
		this.data=data;
	}

}
