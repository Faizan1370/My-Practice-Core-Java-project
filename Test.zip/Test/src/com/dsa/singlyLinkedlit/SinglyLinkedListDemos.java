package com.dsa.singlyLinkedlit;

public class SinglyLinkedListDemos {
	
	private ListNode head;
	
	public static void main(String[] args) {
		SinglyLinkedListDemos demos = new SinglyLinkedListDemos();
		demos.head = new ListNode(11);
		ListNode second = new ListNode(16);
		ListNode third = new ListNode(12);
		ListNode fourth = new ListNode(12);
		ListNode fifth = new ListNode(9);
		ListNode sixth = new ListNode(16);
		
		demos.head.next = second;
		second.next=third;
		third.next=fourth;
		fourth.next=fifth;
		fifth.next=sixth;
		
		
		/*
		 * SinglyLinkedListDemos demos1 = new SinglyLinkedListDemos(); demos1.head = new
		 * ListNode(1); ListNode second1 = new ListNode(3); ListNode third1 = new
		 * ListNode(11); ListNode fourth1 = new ListNode(16);
		 * 
		 * 
		 * demos1.head.next = second1; second1.next=third1; third1.next=fourth1;
		 */
		
		
		/*
		 * SinglyLinkedListDemos result= new SinglyLinkedListDemos(); result.head =
		 * merge(demos.head, demos1.head); result.display();
		 */
		
		
		
		//demos.inserFirstPosition(99);
		//demos.insertLastPosition(100);
		//demos.insertNodeGivenPosition(44, 3);
		//ListNode deleteFirstNode = demos.deleteFirstNode();
		//System.out.println(deleteFirstNode.data);
		//System.out.println(demos.deleteLastNode().data);
		//System.out.println(demos.deleteNodeGivenPosition(3).data);
		
		//System.out.println(demos.searchElementByValue(88));
		
		//System.out.println(demos.findMiddleNode().data);
		//demos.display();
		//demos.removeDuplicateElementInSortedList();
		/*
		 * demos.addNewNodeSortedList(3); demos.addNewNodeSortedList(9);
		 * demos.addNewNodeSortedList(1);
		 */
		//demos.deleteNodeByValue(7);
		//demos.deleteNodeByValue(0);
		//System.out.println(demos.containsLoopInLinkedList());
		//demos.removeLoopLinkedList();
		//System.out.println(demos.containsLoopInLinkedList());
		
		//demos.display();
		
		
		//demos.reverseLinkedList();
		//System.out.println(demos.findNthElement(2).data);
		demos.display();
		//demos.sortLinkedList();
		demos.removeDuplicateUnsortedList();
		demos.display();
		
		
		/*
		 * int length = demos.length(); System.out.println("length "+length);
		 */
		
	}
	
	public void display() {
		ListNode current = head;
		while (current!=null) {
			System.out.print(current.data +" ");
			current=current.next;
		}
		System.out.println("null");
	}
	
	public int length() {
		ListNode current =head;
		int count =0;
		if(current== null) {
			return 0;
		} 
			
		while (current!=null) {
			count++;
			current=current.next;
		}
		return count;	
		
	}
	
	public void inserFirstPosition(int value) {
		//no need to check whether head is null or not
		ListNode newNode = new ListNode(value);
			newNode.next=head;
			head=newNode;
		
	}
	
	public void insertLastPosition(int value) {
		ListNode newNode = new ListNode(value);
		if(head ==null) {
			head=newNode;
			return;
		}
		ListNode current=head;
	  while(current.next !=null) {
			current =current.next;
			
		}
		current.next=newNode;
		
	}
	
	public void insertNodeGivenPosition(int value ,int position) {
		ListNode newNode = new ListNode(value);
		if(position ==1) {
			newNode.next=head;
			head =newNode;
		}else {
		int count=1;
		ListNode previous=head;
		while(count<position-1) {
			previous=previous.next;
			count++;
		}
		ListNode current=previous.next;
		previous.next=newNode;
		newNode.next=current;
		
		}
		
	}
	
	public ListNode deleteFirstNode() {
		if(head ==null) {
			return null;
		}
		ListNode temp=head;
		head=head.next;
		temp.next=null;
		
		return temp;
		
	}
	
	public ListNode deleteLastNode() {
		if(head ==null || head.next == null) {
			return head;
		}
		ListNode current=head;
		ListNode previous=null;
		while(current.next !=null) {
			previous =current;
			current=current.next;
		}
		previous.next=null; //break the chain
		
		return current;
		
	}
	
	public ListNode deleteNodeGivenPosition(int position) {
		if(position ==1) {
			 head =head.next;
		}
		ListNode previous=head;
		int count=1;
		while(count<position-1) {
			previous=previous.next;
			count++;
		}
		ListNode current=previous.next;
		previous.next=current.next;
		
		return current;
	}
	
	public boolean searchElementByValue(int searchkey) {
		 ListNode current=head;
		  while(current !=null) {
			  if(current.data == searchkey) {
				  return true;
			  }
			  current=current.next;
			  
		  }
		return false;
		
	}
	
	public ListNode findMiddleNode() {
		if(head==null) {
			return null;
		}
		ListNode slowPtr=head;
		ListNode fastPtr=head;
		while(fastPtr!=null && fastPtr.next!=null) {
			slowPtr=slowPtr.next;
			fastPtr=fastPtr.next.next;
		}
		
		return slowPtr;
		
	}
	
	public void reverseLinkedList() {
		if(head==null && head.next==null) {
			return;
		}
		ListNode current=head;
		ListNode next=null;
		ListNode previous=null;
		while(current!=null) {
			next=current.next;
			current.next=previous;
			previous=current;
			current=next;
		}
	  head=previous;
	}
	
	public ListNode findNthElement(int n) {
		int counter =0;
		ListNode current=head;
		while(current !=null) {
			current=current.next;
			counter++;
		}
		int position=counter-n;
		current=head;
		for(int i=0;i<position ;i++) {
			current=current.next;
		}
		
		return current;
		
	}
	
	public void removeDuplicateElementInSortedList() {
		if(head==null) {
			return;
		}
		ListNode current=head;
		
		
		while(current !=null && current.next!=null) {
			if(current.data == current.next.data) {
				current.next=current.next.next;
			}else {
				current=current.next;
			}
		}
	}
	
	  public void addNewNodeSortedList(int data) {
		    ListNode newNode = new ListNode(data);

		    if (head == null || head.data >= newNode.data) {
		      newNode.next = head;
		      head = newNode;
		    } else {
		    	ListNode current = head;
		      while (current.next != null && current.next.data < newNode.data) {
		        current = current.next;
		      }
		      newNode.next = current.next;
		      current.next = newNode;
		    }
		  }
	  
	  public void deleteNodeByValue(int value) {
		  if(head==null) {
			  return;
		  }
		  
		  if(head.data==value) {
			  head=head.next;
			  return;
		  }
		  
		  ListNode current=head;
		  while(current.next!=null && current.next.data!=value) {
			  current=current.next;
		  }
		  if(current.next !=null) {
			  current.next=current.next.next;
		  }
		  
		  
	  }
	  
	  public boolean containsLoopInLinkedList() {
		  ListNode fastPtr = head;
		  ListNode slowPtr=head;
		  
		  while(fastPtr!=null && fastPtr.next!=null) {
			  fastPtr = fastPtr.next.next;
			  slowPtr=slowPtr.next;
			  if(fastPtr == slowPtr) {
				  return true;
			  }
		  }
		return false;
		  
	  }
	  
	  public ListNode findStartingLoopNode() {
		  ListNode fastPtr = head;
		  ListNode slowPtr=head;
		  
		  while(fastPtr!=null && fastPtr.next!=null) {
			  fastPtr = fastPtr.next.next;
			  slowPtr=slowPtr.next;
			  if(fastPtr == slowPtr) {
				  return getStartingPoint(slowPtr);
			  }
		  }
		return null;
		  
	  }
	  
	  private ListNode getStartingPoint(ListNode slowPtr) {
		  ListNode temp=head;
		  while(temp!=slowPtr) {
			  temp=temp.next;
			  slowPtr=slowPtr.next;
		  }
		return temp;
	  }
	  
	  
	  public void removeLoopLinkedList() {
		  ListNode fastPtr = head;
		  ListNode slowPtr=head;
		  
		  while(fastPtr!=null && fastPtr.next!=null) {
			  fastPtr = fastPtr.next.next;
			  slowPtr=slowPtr.next;
			  if(fastPtr == slowPtr) {
				  removeLoop(slowPtr);
			  }
		  }
		  
	  }
	  
	  private void removeLoop(ListNode slowPtr) {
		  ListNode temp=head;
		  while(temp.next!=slowPtr.next) {
			  temp=temp.next;
			  slowPtr=slowPtr.next;
		  }
		  slowPtr.next=null;
	  }
	  
	  public static ListNode merge(ListNode a,ListNode b) {
		  ListNode dummy =new ListNode(0);
		  ListNode tail=dummy;
		  
		  while(a!=null && b!=null) {
			  if(a.data<=b.data) {
				  tail.next=a;
				  a=a.next;
			  }else {
				  tail.next=b;
				  b=b.next;
			  }
			  tail=tail.next;
		  }
		  
		  if(a==null) {
			  tail.next=b;
			  
		  }else {
			  tail.next=a;
		  }
		return dummy.next;
		  
	  }
	  
	  public void sortLinkedList() {
		  if(head==null || head.next ==null) {
			  return;
		  }
		  ListNode current=head;
		  ListNode nxt=current.next;
		  int temp=0;
		  while(current!=null) {
			  nxt=current.next;
			  while(nxt!=null) {
				  if(current.data>nxt.data) {
					temp=current.data;
					current.data=nxt.data;
					nxt.data=temp;
					
				  }
				  nxt=nxt.next;
			  }
			  current=current.next;
		  }
	  }
	  
	  public void removeDuplicateUnsortedList() {
		  if(head==null) {
			  return;
		  }
		  ListNode current=head;
		  //ListNode nxt=current.next;
		 // ListNode previous=null;
		  while(current!=null) {
			  ListNode temp=current;
			  while(temp.next!=null) {
				  if(current.data==temp.next.data) {
					  temp.next=temp.next.next;
				  }else {
				  temp=temp.next;
				  }
				  //previous=nxt;
			  }
			 current= current.next;
			  
		  }
		  
	  }
	
	

}
