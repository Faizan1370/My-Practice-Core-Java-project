package com.dsa.singlyLinkedlit.generic;


public class LinkedList<T> {
	
	private Node<T> head;
	
	
	public void add(T data) {
		Node<T> newNode = new Node<>(data);
		if(head== null) {
			head=newNode;
		}else {
			Node<T> current= head;
			while(current.next!=null) {
				current=current.next;
			}
			current.next=newNode;
		}
	}
	
	public void display() {
		int size=0;
		if(head==null) {
			return;
	}else {
		Node<T> current=head;
		while(current !=null) {
			System.out.print(current.data +" ");
			size++;
			current=current.next;
		}
		System.out.println();
		System.out.println("size :"+size);
	}
		
}
	
	public void reverseLinkedList() {
		Node<T> current=head;
		Node<T> next= null;
		Node<T> previous=null;
		
		while(current !=null) {
			next=current.next;
			current.next=previous;
			previous=current;
			current=next;
		}
		head=previous;
	}
	
	public void addNodeStarting(T data) {
		Node<T> newNode= new Node<>(data);
		newNode.next=head;
		head=newNode;
	}
	
	public void addNodePosition(T data,int position) {
		Node<T> newNode= new Node<>(data);
		if(head==null) {
			return;
		}else if(position==1){
			newNode.next=head;
			head=newNode;
			
		}else {
			int count=1;
			Node<T> current=head;
			while(count<position-1) {
				current=current.next;
				count++;
			}
			Node<T> next=current.next;
			current.next=newNode;
			newNode.next=next;
		}
	}
	
	public Node<T> findNthNNode(int n){
		if(n==1) {
			return head;
		}
		int length=0;
		Node<T> current= head;
		while(current!=null) {
			current=current.next;
			length++;
		}
		if(length>n) {
		int pos=length-n;
		current=head;
		for(int i=0;i<pos;i++) {
			current=current.next;
		}
		return current;
		}
		return null;
		
	}
	
	public void removeDuplicatesSortedList() {
		if(head==null) {
			return;
		}
		
		Node<T> current=head;
		
		while(current !=null && current.next !=null) {
			if(current.data == current.next.data) {
				current.next=current.next.next;
			}else {
				current=current.next;
			}
		}
			
	}
	
	public void deleteNodeByValue(T value) {
		if(head== null) {
			return;
		}
		if(head.data== value) {
			head=head.next;
			return;
		}
		Node<T> current=head;
		while(current.next!=null && current.next.data !=value) {
			current=current.next;
		}
		
		if(current.next!=null) {
			current.next=current.next.next;
			
		}
	}
	
	public boolean checkLoopInList() {
		Node<T> slowPtr=head;
		Node<T> fastPtr=head;
		
		while(slowPtr !=null && fastPtr.next!=null) {
			slowPtr=slowPtr.next;
			fastPtr=fastPtr.next.next;
			if(slowPtr == fastPtr) {
				return true;
			}
		}
		return false;
	}
	
	public Node<T> findStartingNodeLoop(){
		Node<T> slowPtr=head;
		Node<T> fastPtr=head;
		
		while(slowPtr !=null && fastPtr.next!=null) {
			slowPtr=slowPtr.next;
			fastPtr=fastPtr.next.next;
			if(slowPtr == fastPtr) {
				return getStartingNode(slowPtr);
			}
		}
		
		return null;
	}
	
	public Node<T> getStartingNode(Node<T> slowPtr){
		Node<T> current=head;
		while(current!=slowPtr) {
			current=current.next;
			slowPtr=slowPtr.next;
			
		}
		return current;
		
	}
	
	
public static void main(String[] args) {
		LinkedList<Integer> list = new LinkedList<>();
		list.add(12);
		list.add(13);
		list.add(34);
		list.addNodePosition(17, 2);
		/*
		 * Node<Integer> findNthNNode = list.findNthNNode(1);
		 * System.out.println(findNthNNode.data);
		 */
		//list.addNodeStarting(55);
		//list.reverseLinkedList();
		//list.removeDuplicatesSortedList();
		list.deleteNodeByValue(13);
		list.display();
	}

}