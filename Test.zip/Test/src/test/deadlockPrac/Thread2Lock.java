package test.deadlockPrac;

public class Thread2Lock extends Thread{
	
private SharedResource resource;

public Thread2Lock(SharedResource resource) {
	this.resource=resource;
}
	
	@Override
	public void run() {
		resource.method2();
	}


}
