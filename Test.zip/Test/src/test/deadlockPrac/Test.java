package test.deadlockPrac;

public class Test {
	
	public static void main(String[] args) {
		SharedResource resource = new SharedResource();
		Thread1Lock t1=new Thread1Lock(resource);
		Thread2Lock t2= new Thread2Lock(resource);
		t1.start();
		t2.start();
	}

}
