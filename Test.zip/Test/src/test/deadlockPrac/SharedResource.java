package test.deadlockPrac;

public class SharedResource {
	
	private final String lock1="my lock";
	private final String lock2="your lock";
	
	public void method1() {
		synchronized (lock1) {
			System.out.println("Method1 lock1 :"+lock1);
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			synchronized (lock2) {
				System.out.println("Method1 lock2 :"+lock2);
			}
		}
		
		
	}
	
	public void method2() {
		synchronized (lock2) {
			System.out.println("Method2 lock1 :"+lock1);
			
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			synchronized (lock1) {
				System.out.println("Method2 lock2 :"+lock2);
			}
		}
		
		
	}
	
	

}
