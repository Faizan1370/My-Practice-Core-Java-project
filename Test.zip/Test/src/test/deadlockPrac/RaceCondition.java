package test.deadlockPrac;

public class RaceCondition  implements Runnable{
	
	int inr=0;
	
	public void increament() {
	  inr++;	
	}
	
	public void decreament() {
		inr--;
	}

	@Override
	public void run() {
		synchronized (this) {
			
		
		this.increament();
		System.out.println("after increament :"+this.inr);
		
		this.decreament();
		
		System.out.println("after decrement :"+this.inr);
		
	}
	}
	
	public static void main(String[] args) {
		RaceCondition condition = new RaceCondition();
		Thread t1= new Thread(condition);
		Thread t2= new Thread(condition);
		Thread t3= new Thread(condition);
		t1.start();
		t2.start();
		t3.start();
	}

}
