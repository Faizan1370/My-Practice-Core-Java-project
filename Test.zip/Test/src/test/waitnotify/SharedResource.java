package test.waitnotify;


public class SharedResource {
	private boolean reourceAvailable=false;
	
	 public synchronized void produce() {
		System.out.println("Produsing the resuorce ");
		reourceAvailable=true;
		notify();
	}
	
	 public synchronized void consume() {
		while(!reourceAvailable) {
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("consuming the resouse");
		reourceAvailable=false;
	}
	
	public static void main(String[] args) {
		SharedResource sharedResource = new SharedResource();
		
		Thread produceThread = new Thread(()->{
			for(int i=0;i<5;i++) {
				sharedResource.produce();
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
		});
		
		  // Create a consumer thread
        Thread consumerThread = new Thread(() -> {
            for (int i = 0; i < 5; i++) {
                sharedResource.consume();
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
        });
        
        produceThread.start();
        consumerThread.start();
        
        // Wait for the threads to finish
        try {
            produceThread.join();
            consumerThread.join();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        System.out.println("Main thread exiting.");
	}

}
