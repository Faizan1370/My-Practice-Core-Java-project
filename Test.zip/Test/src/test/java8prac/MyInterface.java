package test.java8prac;

@FunctionalInterface
public interface MyInterface {
	
	void print(int t);

}
