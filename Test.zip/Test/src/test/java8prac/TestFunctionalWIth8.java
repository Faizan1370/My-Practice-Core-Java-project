package test.java8prac;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.Callable;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.stream.Collectors;

public class TestFunctionalWIth8 {
	public static void main(String[] args) {
		MyInterface interf =t->{
			System.out.println(t);
		};
		 interf.print(7);
		 Consumer<Integer> dem=t->System.out.println(t);
		 dem.accept(7);
		 
		 Predicate<Integer> pr= t->t%2==0;
		System.out.println(pr.test(6)); 
			
			Supplier supp=()->{
				
				return "Hello";
				
			};
			System.out.println(supp.get());
			ArrayList<Integer>  list =new ArrayList<>(Arrays.asList(2,5));
			
			
			
			List<Integer> collect = list.stream().map(e->e*e*e).filter(e->e>50).collect(Collectors.toList());
			System.out.println(collect);
			
			//sum of all even numbers
			
			List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
			
			int sum = numbers.stream().filter(e->e%2==0).mapToInt(Integer::intValue).sum();
			int sum2 = numbers.stream().filter(e->e%2==0).mapToInt(num->num).sum();
			System.out.println(sum +" "+sum2);
			
			//How can you use Java 8 Streams to find the maximum element in a list of integers?
			 List<Integer> numberList = Arrays.asList(1, 3, 7, 2, 9, 5);
			 Optional<Integer> max = numberList.stream().max(Comparator.comparingInt(num->num));
			// Optional<Integer> max = numbers.stream().max(Integer::compare);
			 if(max.isPresent()) {
			 System.out.println(max.get());
			 }else {
				 System.out.println("Empty");
			 }
			 
			// How can you use Java 8 Streams to transform a list of strings to uppercase and store the results in a new list?
			 List<String> strings = Arrays.asList("apple", "banana", "cherry");
			// List<String> collect2 = strings.stream().map(String::toUpperCase).collect(Collectors.toList());
			 List<String> collect2 = strings.stream().map(str->str.toUpperCase()).collect(Collectors.toList());
			 System.out.println(collect2);
			 
			 //How can you use Java 8 Streams to check if all elements in a list of integers are even?
			 List<Integer> listNum = Arrays.asList(2, 4, 6, 8, 10);
			 System.out.println(listNum.stream().allMatch(num->num%2==0));// even
			 System.out.println(listNum.stream().allMatch(num->num%2!=0));// odd
			  
			// How can you use Java 8 Streams to find the average of a list of double values?
			 List<Double> values = Arrays.asList(1.0, 2.0, 3.0, 4.0, 5.0);
			 
			System.out.println(values.stream().mapToDouble(num->num).average());
			System.out.println(values.stream().mapToDouble(Double::doubleValue).average());
			
			//How can you use Java 8 Streams to find the longest string in a list of strings?
			List<String> stringList = Arrays.asList("apple", "banana", "cherry", "date");
			//Optional<String> longest = stringList.stream().max((str1,str2)->str1.length()-str2.length());
			Optional<String> longest = stringList.stream().max((Comparator.comparing(String::length)));
			System.out.println(longest);
			
	}
	
	
	
	
	
	

}
