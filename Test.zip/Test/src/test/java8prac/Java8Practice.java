package test.java8prac;

import java.security.KeyStore.Entry;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.BinaryOperator;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import com.java8.concept.streamApi.Customer;

import test.producesconsumers.Employee;

public class Java8Practice {
	public static List<Employee> getEmployee(){
		ArrayList<Employee> list = new ArrayList<>();
		Employee emp1= new Employee(100, "Ajay", "developer");
		Employee emp2= new Employee(101, "Arun", "developer");
		Employee emp3= new Employee(102, "Qasim", "Hr");
		Employee emp4= new Employee(103, "Ehsan", "Hr");
		list.add(emp1);
		list.add(emp2);
		list.add(emp3);
		list.add(emp4);
		return list;
	}
	
	public static List<Customer> getCustomer(){
		 return Stream.of(
				 new Customer(54, "abc@abc.com", "abc", Arrays.asList(916123456,896745230)),
				 new Customer(87, "harsih@abc.com", "harish", Arrays.asList(916123690,89645230)),
				 new Customer(77, "jameel@abc.com", "jameel", Arrays.asList(875123456,763745654))).collect(Collectors.toList());
	}
	
	public static Map<Employee,Integer> getEmpMap(){
		Map<Employee, Integer> map= new HashMap<>();
		map.put(new Employee(100, "Ajay", "developer"), 400000);
		map.put(new Employee(101, "Arun", "Support"), 4600000);
		map.put(new Employee(102, "Qasim", ".Net Dev"), 1000000);
		map.put( new Employee(103, "Ehsan", "Hr"), 7600000);
		return map;
		
	}
	
	public static void main(String[] args) {
	List<Employee> employees = getEmployee();
	Collections.sort(employees,(o1,o2)->(o1.getName().compareTo(o2.getName())));
	
	//System.out.println(employees);
	//employees.stream().sorted((o1,o2)->o1.getName().compareTo(o2.getName())).forEach(t->System.out.println(t));
	//employees.stream().sorted(Comparator.comparing(Employee::getName)).forEach(System.out::println);
	//employees.stream().sorted(Comparator.comparing(emp ->emp.getId())).forEach(System.out::println);
	
	Map<Employee, Integer> empMap = getEmpMap();
	//empMap.forEach((k,v)->System.out.println(k + " "+v));
	empMap.entrySet().stream().sorted(Map.Entry.comparingByValue()).forEach(t->System.out.println(t));
	//empMap.entrySet().stream().forEach(entry ->System.out.println(entry.getKey() +" "+entry.getValue()));
	
	//List<Entry<Employee, Integer>> list = new ArrayList<>(empMap.entrySet());
	HashMap<String , Integer> map = new HashMap<>();
	List<java.util.Map.Entry<Employee, Integer>> list = new ArrayList<>(empMap.entrySet());
	Collections.sort(list,(o1,o2)->o1.getValue().compareTo(o2.getValue()));
	
	//employees.stream().map(Employee::getName).forEach(t->System.out.println(t));
	employees.stream().map(emp->emp.getName()).forEach(System.out::println);
	empMap.entrySet().stream().map(emp->emp.getKey().getRole()).forEach(t->System.out.println(t));
	
	List<Integer> number= getCustomer().stream().flatMap(c->c.getNumbers().stream()).collect(Collectors.toList());
	number.forEach(System.out::println);
	
	//count chararecter frequency in String;
	String str="faizan";
	Map<String, Long> collect = Arrays.stream(str.split("")).collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
	
	collect.entrySet().stream().forEach(obj->System.out.println(obj.getKey() +" "+obj.getValue()));
	
	Comparator<Employee> comparingBy = Comparator.comparing(Employee::getName);
	//Map<String, List<Employee>> collect2 = employees.stream().collect(Collectors.groupingBy(emp->emp.getRole()));
	Map<String, Optional<Employee>> collect2 = employees.stream().collect(Collectors.groupingBy(emp->emp.getRole(),Collectors.reducing(BinaryOperator.minBy(comparingBy))));
	System.out.println(collect2);
	
	IntStream.range(1, 10).forEach(t->System.out.println(Thread.currentThread().getName() +":"+t));
	System.out.println("*****************************");
	IntStream.range(1, 10).parallel().forEach(t->System.out.println(Thread.currentThread().getName() +":"+t));
	
	}
}
