package test;

import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Map;
import java.util.Map.Entry;

public class Test {
	
	public static void palin() {
		String str="madam";
		String reverseStr="";
		//char[] charArray = str.toCharArray();
		for(int i=str.length()-1;i>=0;i--) {
			reverseStr=reverseStr+	str.charAt(i);
			
		}
		if(str.equals(reverseStr)) {
			System.out.println("true");
		}else {
			System.out.println("false");
		}
			
	}
	
	public static void checkPalin() {
		String str="madamr";
		int i=0;
		int j=str.length()-1; 
		
		boolean check =false;
		
		while(i<j) {
			if(str.charAt(i) == str.charAt(j)) {
				check = true;
				i++;
				j--;
			}else {
				check =false;
				break;
			}
		}
		System.out.println("char chec cv "+check);
	}

	public static void main(String[] args) {
		palin();
		checkPalin();
      String str="faizan";
      
      
      HashMap<Character, Integer> map = new HashMap<>();
      
      for(int i=0;i<str.length();i++){
    	  if(map.containsKey(str.charAt(i))){
    		 map.put(str.charAt(i), map.get(str.charAt(i))+1); 
    		  
    	  }else
    	  {
    		  map.put(str.charAt(i),1);
    	  }
    	  
      }
      
      for(Entry<Character, Integer> obj : map.entrySet()) {
    	  System.out.println(obj.getKey() +"  "+obj.getValue());
    	  
      }
      
      map.forEach((k,v)->System.out.println(k+" "+v));
   // map.forEach((key,value)->System.out.println(key +" "+value));
   	map.entrySet().stream().forEach(obj->System.out.println(obj));
   		// map.entrySet().stream().filter(k->k.getKey()%2==0).forEach(obj->System.out.println(obj));
   	LinkedList<Integer> ll = new LinkedList<>();

   	ll.add(1);
   	ll.add(2);
   	ll.add(3);

   	System.out.println(ll);

   	LinkedList<Integer> ll1 = new LinkedList<>();

   	ll.descendingIterator().forEachRemaining(ll1::add);

   	System.out.println(ll1);
	}

}
