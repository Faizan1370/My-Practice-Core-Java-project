package test;

public class ProThread extends Thread {
	 private ShProCon pro;
	 
	 public ProThread(ShProCon pro) {
		 this.pro=pro;
	}

	@Override
	public void run() {
		int i=0;
		while(true) {
			pro.produce(i);
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			i++;
		}
		
	}
	
	

}
