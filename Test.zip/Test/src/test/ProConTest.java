package test;

public class ProConTest {
	
	
	public static void main(String[] args) {
		//ShProCon proCon = new ShProCon();
		//ProThread t1= new ProThread(proCon);
		//ConThread t2= new ConThread(proCon);
		//t1.start();
		//t2.start();
		
		final String resource1="res1";
		final String resource2="res2";
		
		Thread th1= new Thread() {
			
			
			public void run() {
				synchronized (resource1) {
					System.out.println("Lock on resource1 by :"+Thread.currentThread().getName());
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					synchronized (resource2) {
						System.out.println("Lock on resource2 by :"+Thread.currentThread().getName());
					}
				}
			}
			
		};
		
		
  Thread th2= new Thread() {
			
			
			public void run() {
				synchronized (resource2) {
					System.out.println("Lock on resource2 by :"+Thread.currentThread().getName());
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					synchronized (resource1) {
						System.out.println("Lock on resource1 by :"+Thread.currentThread().getName());
					}
				}
			}
			
		};
		
		th1.start();
		th2.start();
		
		
	}

}
