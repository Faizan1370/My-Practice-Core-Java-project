package test.dsaprac;

import java.util.EmptyStackException;

public class StackPrac {
	private ListNode head;
	private int length;
	
	public void push(int data) {
		ListNode newNode= new ListNode(data);
		newNode.next=head;
		head=newNode;
		length++;
		
		
	}
	public void pop() {
		if(length== 0) {
			return;
		}
		head=head.next;
		length--;
	}
	
	public void display() {
		if(head==null) {
			return;
		}
		
		ListNode current=head;
		while(current !=null) {
			System.out.println(current.data +" ");
			current=current.next;
		}
	}
	
	public int peek() {
		if(head==null) {
			 throw new EmptyStackException();
		}
		return head.data;
	}
	
	public static void main(String[] args) {
		StackPrac stackPrac = new StackPrac();
		stackPrac.push(34);
		stackPrac.push(70);
		stackPrac.push(12);
		stackPrac.push(44);
		stackPrac.push(66);
		stackPrac.pop();
		
		stackPrac.display();
		int length2 = stackPrac.length;
		System.out.println(length2);
		System.out.println("Peek :"+stackPrac.peek());
	}

}
