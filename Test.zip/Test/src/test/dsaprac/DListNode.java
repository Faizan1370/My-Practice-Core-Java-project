package test.dsaprac;

public class DListNode {
	int data;
	DListNode next;
	DListNode previous;
	public DListNode(int data) {
		this.data=data;
	}

}
