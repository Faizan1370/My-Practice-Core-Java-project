package test.dsaprac;

import com.dsa.doublyLinkedList.ListNode;

public class DoubleLinkedListPrac {
	private DListNode head;
	
	
	public void insertNodeFirst(int data) {
		DListNode newNode= new DListNode(data);
		newNode.next=head;
		newNode.previous=null;
		if(head!=null) {
			head.previous=newNode;
		}
		head=newNode;
		
	}
	
	public void insertNodeLast(int data) {
		DListNode newNode= new DListNode(data);
		DListNode current=head;
		//newNode.next=null; // no need to write this if we wriet there will be no error because by default it will null
		if(head==null) {
			//newNode.previous=null;//// no need to write this if we wriet there will be no error because by default it will null
			head=newNode;
			return;
		}
		while(current.next!=null) {
			current=current.next;
		}
		current.next=newNode;
		newNode.previous=current;
	}
	
	public void display() {
		if(head==null) {
			return;
		}
		DListNode current=head;
		while(current!=null) {
			System.out.println(current.data +" ");
			current=current.next;
		}
	}
	
	public int length() {
		if(head==null) {
			return 0;
		}
		DListNode current=head;
		int length=0;
		while(current!=null) {
			current=current.next;
			length++;
		}
		return length;
	}
	public void deleteFirstNode() {
		if(head==null) {
			return;
		}
		if(head.next==null) {
			head=null;
		}
		DListNode current=head;
		head=head.next;
		current.next=null;
		head.previous=null;
	}
	
	public void deleteLastNode() {
		if(head==null) {
			return;
		}
		if(head.next==null) {
			head=null;
		}
		DListNode current=head;
		while(current.next!=null) {
			current=current.next;
		}
		DListNode pre=current.previous;
		pre.next=null;
		current.previous=null;
	}
	
	public void deleteNodePosition(int position) {
		if(head==null) {
			return;
		}
		if(position==1) {
			DListNode current=head;
			head=head.next;
			current.next=null;
			head.previous=null;
		}else {
			
			DListNode current=head;
			//first way
			//int count=1;
			//while(count<position-1) {
				//current=current.next;
				//count++;
			//}
			//DListNode temp=current.next;
			//current.next=temp.next;
			//temp.previous=null;
			//temp.next.previous=null;
			
			//secound way
			int count=0;
			while(count<position-1) {
				current=current.next;
				count++;
			}
			DListNode temp=current.next;
			DListNode pre=current.previous;
			if(temp !=null) {
				temp.previous=pre;
				pre.next=temp;
			}else {
				System.out.println("is this");
				pre.next=null;
				current.previous=null;
			}
		}
	}
	
	public void deleteByVlaue(int data) {
		if(head==null) {
			return;
		}
		DListNode current=head;
		if(current.data==data) {
		 head=current.next;
		 head.previous=null;
		 current.next=null;
		}
		while(current !=null && current.data!=data) {
			current=current.next;
		}
		if(current!=null) {
		DListNode nxt=current.next;
		DListNode pre = current.previous;
		if(nxt!=null) {
			pre.next=nxt;
			nxt.previous=pre;
			current.next=null;
			current.previous=null;
		}else {
			pre.next=null;
			current.previous=null;
		}
		
		}else {
			System.out.println("value not found in the list");
		}
	}
	public int findNodePositionByValue(int data) {
		if(head==null) {
			return Integer.parseInt("List is empty");
		}
		DListNode current=head;
		//int count=0;// it will get the index
		int count=1; // it will give the position
		while(current!=null && current.data!=data) {
			current=current.next;
			count++;
			
		}
		if(current!=null && current.data==data) {
			return count;
		}else {
			return Integer.parseInt("No such type of value in list");
		}
	}
	
	public static void main(String[] args) {
		DoubleLinkedListPrac doubleLinkedListPrac= new DoubleLinkedListPrac();
		doubleLinkedListPrac.insertNodeLast(34);
		doubleLinkedListPrac.insertNodeLast(565);
		doubleLinkedListPrac.insertNodeLast(45);
		doubleLinkedListPrac.insertNodeLast(67);
		doubleLinkedListPrac.insertNodeLast(56);
		doubleLinkedListPrac.insertNodeLast(90);
		//DListNode previous = doubleLinkedListPrac.head.previous;
		//System.out.println(previous);
		
		//doubleLinkedListPrac.deleteFirstNode();
		//doubleLinkedListPrac.deleteLastNode();
		//doubleLinkedListPrac.deleteNodePosition(3);
		//doubleLinkedListPrac.deleteByVlaue(0);
		int findNodePositionByValue = doubleLinkedListPrac.findNodePositionByValue(34);
		System.out.println("postion :"+findNodePositionByValue);
		doubleLinkedListPrac.display();
		System.out.println("********* length :"+doubleLinkedListPrac.length());
		
	}

}
