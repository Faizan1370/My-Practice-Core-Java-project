package test.dsaprac;

import com.queue.ListNode;

public class ListNodeGeneric<T> {
	public T data;
	public ListNode<T> next;
	
	public ListNodeGeneric(T data){
		this.data=data;
		this.next=null;
	}


}
