package test.dsaprac;

public class ListNode {
	int data;
	ListNode next;
	public ListNode(int data) {
		this.data=data;
		this.next=null;
	}

}
