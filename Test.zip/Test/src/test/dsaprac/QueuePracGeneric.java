package test.dsaprac;

import com.queue.ListNode;

public class QueuePracGeneric<T> {
	
	private ListNode<T> head;
	private ListNode<T> tail;
	
	public void enque(T data) {
		ListNode<T> newNode= new ListNode<T>(data);
		if(tail!=null) {
			tail.next=newNode;
		}
		tail=newNode;
		if(head==null) {
			head=newNode;
		}
	}
	
	public T dequeue() {
		if(head== null) { 
		   return null;
		}
		T dataElement=head.data;
		head=head.next;
		if(head== null) {
			tail=null;
		}
		return dataElement;
	}
	

}
