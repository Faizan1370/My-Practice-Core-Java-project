package test.dsaprac;

public class QueuePrac {
	private ListNode head;
	
	public void add(int data) {
		ListNode newNode= new ListNode(data);
		if(head==null) {
			head=newNode;
			return;
		}
		ListNode current=head;
		while(current.next!=null) {
			current=current.next;
		}
		current.next=newNode;
	}
	
	public void display() {
		if(head==null) {
			return;
		}
		
		ListNode current=head;
		while(current !=null) {
			System.out.println(current.data +" ");
			current=current.next;
		}
	}
	
	public ListNode deque() {
		if(head==null) {
			return null;
		}
		ListNode current=head;
		head=head.next;
		return current;
	}
	public int size() {
		if(head==null) {
			return 0;
		}
		int size=0;
		ListNode current=head;
		while(current!=null) {
			current=current.next;
			size++;
		}
		return size;
		
	}
	
	public static void main(String[] args) {
		QueuePrac prac= new QueuePrac();
		prac.add(6);
		prac.add(9);
		prac.add(7);
		prac.add(2);
		prac.add(5);
		
		
		
		System.out.println("deleted data :"+prac.deque().data);;
		System.out.println();
		prac.display();
		System.out.println("Size :"+prac.size());;
		
		
	}

}
