package test.dsaprac;

import java.util.List;

import com.dsa.singlyLinkedlit.ListNode;

public class SingleLinkedList {
	private ListNode head;
	
	public  void addAtFirstNode(int data) {
		ListNode newNode= new ListNode(data);
		/* 
		 * if(head== null) { head=newNode; head.next=null; } // no need to check
		 */
		newNode.next=head;
		head=newNode;
		
	}
	
	public void addAtLast(int data) {
		ListNode newNode= new ListNode(data);
		if(head==null) {
			head=newNode;
			return;
		}
		//ListNode current=head;
		//while(current.next!=null) { //first Approach
			//current=current.next;
		//}
		ListNode current=head; // second approach
		ListNode previous=null;
		while(current!=null) {
			previous=current;
			current=current.next;
		}
		
		previous.next=newNode;
	}
	
	public void display() {
		if(head== null) {
			return;
		}
		ListNode current=head;
		while(current!=null) {
			System.out.println(current.data +" ");
			current= current.next;
		}
				
	}
	
	public int length() {
		if(head==null) {
			return 0;
		}
		ListNode current=head;
		int count=0;
		while(current!=null) {
			current= current.next;
			count++;
		}
		return count;
	}
	
	public void insertNodeGivenPosition(int data ,int position) {
		ListNode newNode= new ListNode(data);
		if(position==1) {
			head=newNode;
			return;
		}
		int count=1; // if you want to make by index use zero
		ListNode current=head;
		//ListNode next=null;
		while(count<position-1) {
			current= current.next;
			count++;
		}
		newNode.next=current.next;
		current.next=newNode;
		
	}
	
	public ListNode deleteFirsNode() {
		if(head==null) {
			return null;
		}
		ListNode current=head;
		head=current.next;
		current.next=null;
		return head;
	}
	
	public ListNode deleteLastNode() {
		if(head==null || head.next == null) {
			return head;
		}
		ListNode current=head;
		ListNode previous= null;
		while(current.next !=null) {
			previous=current;
			current=current.next;
			
		}
		previous.next=null;
		return previous;
	}
	
	public ListNode deleteNodeGivenPosition(int position) {
		if(head==null) {
			return null;
		}
		if(position==1) {
			head=head.next;
		}
		int count=1;
		ListNode current=head;
		while(count<position-1) {
			current=current.next;
			count++;
		}
		current.next=current.next.next;
		return current.next;
	}
	
	public boolean searchElementByValue(int data) {
		if(head==null) {
			return false;
		}
		ListNode current=head;
		while(current!=null) {
			if(current.data==data) {
				return true;
			}
			
			current=current.next;
		}
		return false;
		
	}
	
	public ListNode findMiddleNode() {
		if(head==null) {
			return null;
		}
		ListNode fastPtr=head;
		ListNode slowPtr=head;
		while(fastPtr!=null && fastPtr.next!=null) {
			 slowPtr = slowPtr.next;
			 fastPtr=fastPtr.next.next;
		}
		return slowPtr;
	}
	public void reverseLinkedList() {
		if(head==null && head.next==null) {
			return;
		}
		ListNode current=head;
		ListNode next=null;
		ListNode previous= null;
		while(current !=null) {
			next=current.next;
			current.next=previous;
			previous=current;
			current=next;
		}
		head=previous;
		
	}
	public ListNode findNthElement(int n) {
		if(head==null) {
			return null;
		}
		int counter=0;
		ListNode current= head;
		while(current!=null) {
			current=current.next;
			counter++;
		}
		int position= counter-n;
		current=head;
		for(int i=0;i<position;i++) {
			current=current.next;
		}
		return current;
		
	}
	
	public void removeUplicatesSortedList() {
		if(head==null) {
			return;
		}
		
		ListNode current=head;
		while(current!=null && current.next!=null) {
			if(current.data==current.next.data) {
				current.next=current.next.next;
			}else {
				current=current.next;
			}
		}
	}
	
	 public void addNewNodeSortedList(int data) {
		 ListNode newNode=new ListNode(data);
		 if(head == null || head.data >= newNode.data) {
			newNode.next=head;
			head=newNode; 
		 }else {
			 ListNode current = head;
			 while(current.next!=null && current.next.data <newNode.data) {
				 current=current.next;
			 }
			 newNode.next=current.next;
			 current.next=newNode;
		 }
		 
	 }
	 
	 public void deleteNodeByValue(int data) {
		 if(head==null) {
			 return;
		 }
		 if(head.data==data) {
			 head=head.next;
			 return;
		 }
		 ListNode current=head;
		 while(current.next!=null && current.next.data!=data) {
			 current=current.next;
		 }
		 if(current.next!=null) {
			 current.next=current.next.next;
		 }
	 }
	 
	 public boolean checkListContainsLoop() {
		 ListNode fstprt=head;
		 ListNode slowPtr=head;
		 while(fstprt!=null && fstprt.next!=null) {
			 fstprt=fstprt.next.next;
			 slowPtr=slowPtr.next;
			 if(slowPtr==fstprt) {
				 return true;
			 }
		 }
		return false;
	 }
	 
	 public ListNode findStartingLoopNode() {
		 ListNode fstprt=head;
		 ListNode slowPtr=head;
		 while(fstprt!=null && fstprt.next!=null) {
			 fstprt=fstprt.next.next;
			 slowPtr=slowPtr.next;
			 if(slowPtr==fstprt) {
				 return getStartingNode(slowPtr);
			 }
		 }
		return null;
		 
	 }
    
    private ListNode getStartingNode(ListNode slowPtr) {
    	ListNode temp=head;
    	while(temp!=slowPtr) {
    		temp=temp.next;
    		slowPtr=slowPtr.next;
    	}
		return temp;
    	
    }
    
    public void removeLoopLinkedList() {
		  ListNode fastPtr = head;
		  ListNode slowPtr=head;
		  
		  while(fastPtr!=null && fastPtr.next!=null) {
			  fastPtr = fastPtr.next.next;
			  slowPtr=slowPtr.next;
			  if(fastPtr == slowPtr) {
				  removeLoop(slowPtr);
			  }
		  }
		  
	  }
    private void removeLoop(ListNode slowptr) {
    	ListNode temp=head;
    	while(temp.next!=slowptr.next) {
    		temp=temp.next;
    		slowptr=slowptr.next;
    	}
    	slowptr.next=null;
    }
	public static void main(String[] args) {
		SingleLinkedList list = new SingleLinkedList();
		list.addAtFirstNode(25);
		list.addAtFirstNode(19);
		list.addAtFirstNode(17);
		list.addAtFirstNode(15);
		list.addAtFirstNode(13);
		
		list.addAtFirstNode(12);
		list.addAtFirstNode(9);
		
		//list.insertNodeGivenPosition(44, 5);
		//list.deleteFirsNode();
		//list.deleteLastNode();
		//list.deleteNodeGivenPosition(3);
		//System.out.println(list.searchElementByValue(0));
		/*
		 * System.out.println("***********");
		 * 
		 * list.addAtLast(99); list.addAtLast(66); list.addAtLast(88);
		 */
		//System.out.println(list.findMiddleNode().data);
		//list.reverseLinkedList();
		//System.out.println(list.findNthElement(4).data);;
		
		//list.display();
		//list.removeUplicatesSortedList();
		//System.out.println();
		//list.addNewNodeSortedList(11);
		//list.deleteNodeByValue(12);
		System.out.println(list.findStartingLoopNode());;
		list.display();
		//System.out.println(list.length());;
		
	}

}
