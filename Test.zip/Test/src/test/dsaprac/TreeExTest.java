package test.dsaprac;

import java.util.Queue;
import java.util.Stack;
import java.util.concurrent.ConcurrentLinkedQueue;

import com.treedsa.TreeNode;

public class TreeExTest<T> {
	TreeNode<T> root;
	
	
	public static void main(String[] args) {
		TreeExTest<Integer> exTest = new TreeExTest<>();
		exTest.insertInterativeOrder(1);
		exTest.insertInterativeOrder(2);
		exTest.insertInterativeOrder(3);
		exTest.insertInterativeOrder(4);
		exTest.insertInterativeOrder(5);
		exTest.insertInterativeOrder(6);
		
		//exTest.preOrderTraversal();
		//exTest.iterativePreOrderTranversal();
		//exTest.recursiveInorderTraversal();
		//exTest.recursivePostorder();
		//exTest.itreativeInOrderTraversal();
		//exTest.iterativePostOrder();
		exTest.iterativeLevelOrderTraversal();
		
	}
	
	 // Method to insert a value into the binary tree iteratively
	//This is using level order insertion mean first root then left and in right.
	
	public void insertInterativeOrder(T data){
		TreeNode<T> newNode= new TreeNode<>(data);
		if(root==null) {
			root=newNode;
			return;
		}
		Queue<TreeNode<T>> queue= new ConcurrentLinkedQueue<>();
		queue.add(root);
		while(!queue.isEmpty()) {
			TreeNode<T> currentNode = queue.poll();
			if(currentNode.left==null) {
				currentNode.left=newNode;
				return;
			}else if(currentNode.right==null){
				currentNode.right=newNode;
				return;
			}
		
		  queue.add(currentNode.left);
		  queue.add(currentNode.right);
		}
	}
	
	public void preOrderTraversal() {
		recursivePreOrderTraversal(root);
	}
	
	public void recursivePreOrderTraversal(TreeNode<T> current) {
        if (current != null) {
            System.out.print(current.data + " ");
            recursivePreOrderTraversal(current.left);
            recursivePreOrderTraversal(current.right);
        }
        
    }
	
	public void recursiveInorderTraversal() {
		InorderTraversalRecru(root);
	}
	
	private void InorderTraversalRecru(TreeNode<T> current) {
		if(current!=null) {
			InorderTraversalRecru(current.left);
			System.out.print(current.data +" ");
			InorderTraversalRecru(current.right);
		}
		
	}
	
	public void recursivePostorder() {
		postOrderRecur(root);
	}

	private void postOrderRecur(TreeNode<T> current) {
		if(current!=null) {
			postOrderRecur(current.left);
			postOrderRecur(current.right);
			System.out.print(current.data +" ");
		}
	}

	public void iterativePreOrderTranversal() {
		if(root==null) {
			System.out.println("Tree is Empty");
			return;
		}
		Stack<TreeNode<T>> stack= new Stack<>();
		stack.add(root);
		
		while(!stack.isEmpty()) {
			TreeNode<T> current = stack.pop();
			System.out.print(current.data +" ");
			
			if(current.right!=null) {
				stack.add(current.right);
			}
			
			if(current.left!=null) {
				stack.add(current.left);
			}
		}
	}
	
	public void itreativeInOrderTraversal() {
		if(root==null) {
			System.out.println("This tree has no node");
			return;
		}
		Stack<TreeNode<T>> stack = new Stack<>();
		TreeNode<T> temp=root;
		
		while(!stack.isEmpty() || temp!=null) {
			if(temp!=null) {
				stack.push(temp);
				temp=temp.left;
			}else {
				temp=stack.pop();
				System.out.print(temp.data +" ");
				temp=temp.right;
				
			}
		}
	}
	
	public void iterativePostOrder() {
		if(root==null) {
			System.out.println("No node in the Tree");
		}
		Stack<TreeNode<T>> stack1 = new Stack<>();
		Stack<TreeNode<T>> stack2 = new Stack<>();
		stack1.push(root);
		
		while(!stack1.isEmpty()) {
			TreeNode<T> current = stack1.pop();
			stack2.push(current);
			if(current.left!=null) {
				stack1.push(current.left);
			}
			if(current.right!=null) {
				stack1.push(current.right);
			}
		}
		while(!stack2.isEmpty()) {
			TreeNode<T> pop = stack2.pop();
			System.out.println(pop.data +" ");
		}
	}
	
	public void iterativeLevelOrderTraversal() {
		if(root==null) {
			System.out.println("No such nodes in the Tree");
			return;
		}
		Queue<TreeNode<T>> queue = new ConcurrentLinkedQueue<>();
		queue.add(root);
		
		while(!queue.isEmpty()) {
			TreeNode<T> current=queue.poll();
			System.out.print(current.data +" ");
			
			
			if(current.left!=null) {
				queue.add(current.left);
			}
			if(current.right!=null) {
				queue.add(current.right);
			}
		}
	}
	
	//bst
	public void insert(int data) {
		//insertInBst(root, data); //this should be com.bst.TreeNode<T> root
	}
	
	public com.bst.TreeNode<T> insertInBst(com.bst.TreeNode<T> root,int data) {
		if(root==null) {
			return new com.bst.TreeNode<T>(data);
		}
		if(data<root.data) {
			 root.left = insertInBst(root.left, data);
		}else {
			root.right=insertInBst(root.right, data);
		}
		return root;
	}
	
	//public com.bst.TreeNode<T> serach(int key){
		//if(root==null || root.data==key) {
			//return root;
		//}
		//if(key<root.data) {
			//return search(root.left, key);
		//}else {
			//return search(root.right, key);
		//}
	//}
	
	

	

}
