package test;

public class ShallowAndDeepCopy {
	private int a=30;
	
	public static void main(String[] args) {
		ShallowAndDeepCopy andDeepCopy= new ShallowAndDeepCopy();
		//ShallowAndDeepCopy obj2=andDeepCopy;//shallow coopy
		//ShallowAndDeepCopy obj3=obj2;//shallow copy
		ShallowAndDeepCopy obj1= new ShallowAndDeepCopy();
		ShallowAndDeepCopy obj2 = new ShallowAndDeepCopy();
		obj1.a=6;
		obj2.a=20;
		System.out.println(andDeepCopy.a +" "+obj1.a +" "+obj2.a);
		
		Employee emp1= new Employee(101, "faiz", "cv");
		Employee emp2= new Employee(101, "faiz", "cv");
		
		System.out.println(emp1.hashCode() +" "+emp2.hashCode());
		System.out.println(emp1.equals(emp2)); 
		System.out.println(emp1.toString().equals(emp2.toString()));
	}
	

}
