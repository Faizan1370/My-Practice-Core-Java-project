package test;

import java.util.Arrays;

public class Demo {
	public static void main(String[] args) {
		int[] a= {2,5,7,2,6,4,6};
		int[] res= new int[a.length];
		int k=0;
		for(int i=0;i<a.length;i++) {
			boolean isDuplicate=false;
			for(int j=0;j<k;j++) {
				if(a[i]==a[j]) {
					isDuplicate=true;
					break;
				}
				
			}
			if(!isDuplicate) {
				res[k]=a[i];
				k++;
			}
		}
		System.out.println(Arrays.toString(res));
		
		String lock1="lock1";
		String lock2="lock2";
		
		Thread t1= new Thread() {
			
			@Override
			public void run() {
			 	synchronized (lock1) {
					System.out.println(" Thread 1 locked lock1");
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					synchronized (lock2) {
						System.out.println("Thread 1 locked lock2");
					}
				}
			}
			
		};
		
	 Thread t2= new Thread() {
			
			@Override
			public void run() {
			 	synchronized (lock2) {
					System.out.println("Thread 2 locked lock2");
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					synchronized (lock1) {
						System.out.println("Thread 2 locked lock1");
					}
				}
			}
			
		};
		
		t1.start();
		t2.start();
	}
	

	
	public static void secondWay() {
		int[] a= {2,5,7,2,6,4,6};
		int[] res= new int[a.length];
		int k=0;
		for(int i=0;i<a.length;i++) {
			boolean isDuplicate=false;
			for(int j=0;j<k;j++) {
				if(a[i]==a[j]) {
					isDuplicate=true;
					break;
				}
			}
			if(!isDuplicate) {
				res[k]=a[i];
				k++;
			}
		}
	}

}
