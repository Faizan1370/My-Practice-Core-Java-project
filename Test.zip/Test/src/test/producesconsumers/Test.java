package test.producesconsumers;

import java.util.ArrayList;
import java.util.List;

public class Test {
	
	
	public static void main(String[] args) throws InterruptedException {
		ProducesrsConsumers producesrsConsumers = new ProducesrsConsumers();
		
		ProducerThread producerThread = new ProducerThread(producesrsConsumers);
		ConsumerThread consumerThread = new ConsumerThread(producesrsConsumers);
		producerThread.start();
		Thread.sleep(100);
		consumerThread.start();
	}

}
