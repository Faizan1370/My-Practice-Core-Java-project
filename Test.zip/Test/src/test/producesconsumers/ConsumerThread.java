package test.producesconsumers;

public class ConsumerThread extends Thread{
   private ProducesrsConsumers producesrsConsumers;
   
   public ConsumerThread(ProducesrsConsumers producesrsConsumers) {
	   this.producesrsConsumers=producesrsConsumers;
   }
   
   @Override
   public void run() {
	   for(Employee emp :ProducerThread.getEmployee()){
	   this.producesrsConsumers.consumer();
	   try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	   }
   }
}
