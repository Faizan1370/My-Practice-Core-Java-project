package test.producesconsumers;

import java.util.ArrayList;
import java.util.List;

public class ProducerThread extends Thread{
	
	
	
	private ProducesrsConsumers producesrsConsumers;
	
	public ProducerThread(ProducesrsConsumers producesrsConsumers) {
		this.producesrsConsumers=producesrsConsumers;
	}
	
	public static List<Employee> getEmployee(){
		ArrayList<Employee> list = new ArrayList<>();
		Employee emp1= new Employee(100, "ajay", "developer");
		Employee emp2= new Employee(101, "Arun", "Support");
		Employee emp3= new Employee(102, "Qasim", ".Net Dev");
		Employee emp4= new Employee(103, "Ehsan", "Hr");
		list.add(emp1);
		list.add(emp2);
		list.add(emp3);
		list.add(emp4);
		return list;
	}
	
	@Override
	public void run() {
		//int i=1;
		for(Employee emp :getEmployee()) {
			//System.out.println(emp.getId());
			//System.out.println("Produces Thread :"+Thread.currentThread().getName());
			this.producesrsConsumers.producer(emp);
		//	i++;
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}

}
