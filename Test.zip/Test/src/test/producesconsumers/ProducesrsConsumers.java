package test.producesconsumers;

public class ProducesrsConsumers {
	
	//private Employee employee;
	
	private Employee employee;
	
	 synchronized void producer(Employee employee) {
		this.employee=employee;
		System.out.println("Producer :"+this.employee);
	}
	
	synchronized void consumer() {
		System.out.println("Consumer :"+this.employee);
	}

}
