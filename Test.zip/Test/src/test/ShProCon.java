package test;

public class ShProCon {
	
	private static int i=0;
	
	public synchronized void produce(int i) {
		this.i=i;
		System.out.println("Produce :"+this.i);
		
	}
	
	public synchronized void consume() {
		System.out.println("Consume :"+this.i);
	}

}
