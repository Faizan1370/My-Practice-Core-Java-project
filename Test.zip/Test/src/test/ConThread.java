package test;

public class ConThread extends Thread{
 private ShProCon pro;
	 
	 public ConThread(ShProCon pro) {
		 this.pro=pro;
	}

	@Override
	public void run() {
      while(true) {
    	  pro.consume();
    	  try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
      }
	}

}
