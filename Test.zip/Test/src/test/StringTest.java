package test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.java8.concept.streamApi.sortList.Employee;

public class StringTest {

	public static void main(String[] args) {
		
		checkString();
     String str="hello";
     
     Map<Employee,Integer> employeeMap = new TreeMap<>();
 	//Map<Employee,Integer> employeeMap = new TreeMap<>();
 	employeeMap.put(new Employee(12, "Arun", "IT desk", 7000000), 60);
 	employeeMap.put(new Employee(65, "Akhil", "Support", 800000), 67);
 	employeeMap.put(new Employee(77, "Sahil", "Developer", 9000000), 88);
 	employeeMap.put(new Employee(44, "Nasir", "Support", 6000000), 90);
 	
 	List<Entry<Employee, Integer>> entrySet = new ArrayList<>(employeeMap.entrySet());
 	
 	Collections.sort(entrySet,(o1,o2)->o1.getValue().compareTo(o2.getValue()));
 	
 	employeeMap.entrySet().stream().sorted(Map.Entry.comparingByValue()).forEach(System.out::println);
 	employeeMap.entrySet().stream().sorted(Map.Entry.comparingByKey(Comparator.comparing(Employee::getName))).forEach(e->System.out.println(e));
 	
 	String str1="faizan";
 	Map<String, Long> collect = Arrays.stream(str1.split("")).map(c->c.toLowerCase()).collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
 	
 	int[] array = new int[256];
 	for(int i=0;i<str.length();i++) {
 		array[str.charAt(i)]++;
 	}
 	
 	for(int j=0;j<256;j++) {
 		if(array[j]!=0 && !Character.isWhitespace((char)j)) {
 			System.out.println((char)j +" "+array[j]);
 		}
 	}
 	
 	
		/*
		 * // System.out.println(str.length()); for(int i=str.length();i>=0;i--) {
		 * System.out.print(i); } char[] charArray = str.toCharArray();
		 * //System.out.println(charArray.length); for(int i=0;i<=charArray.length;i++)
		 * { System.out.print(i); }
		 */
	}
	
	
	public static void checkString() {
		String s1="test";
		String s4 ="Test";
		String s2= new String("test");
		String s3= new String("test");
		if(s2==s3) {
			System.out.println(true);
		}else {
			System.out.println(false);
		}
		if(s1 == s4) {
			System.out.println(true);
		}
	}

}
