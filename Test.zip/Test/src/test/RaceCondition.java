package test;

public class RaceCondition  implements Runnable{
	int counter=0;
	
	public void increament() {
		counter++;
	}
	
	public void decrement() {
		counter--;
	}

	@Override
	public void run() {
		synchronized (this) {
			
		
		this.increament();
		System.out.println("after inr :"+this.counter);
		
		this.decrement();
		System.out.println("after dcr :"+this.counter);
		}
	}
	
	public static void main(String[] args) {
		RaceCondition r= new RaceCondition();
		Thread t1= new Thread(r);
		Thread t2= new Thread(r);
		Thread t3= new Thread(r);
		t1.start();
		t1.interrupt();
		t2.start();
		t3.start();
		
	}

}
